'use strict';
// SLIM 交易所：挂牌上市 / 三方治理 / 竹排换血（自治模块，db 由调用方注入，不依赖 server/db.js）
// 对应需求差距分析 B6(挂牌)、B11(三方9席)、B12(宪法/61.8%/前e%)、B13(竹排年度换血·守恒·6.18%)

function ensureSchema(db) {
  db.exec(`CREATE TABLE IF NOT EXISTS slim_listings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    asset_type TEXT NOT NULL,
    entity_code TEXT NOT NULL,
    entity_name TEXT DEFAULT '',
    group_code TEXT DEFAULT '',
    status TEXT DEFAULT 'pending',
    submitted_by INTEGER,
    note TEXT DEFAULT '',
    created_at TEXT DEFAULT (datetime('now','localtime')),
    reviewed_at TEXT
  );`);
  db.exec(`CREATE TABLE IF NOT EXISTS slim_proposals (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    kind TEXT DEFAULT 'constitution',
    yea INTEGER DEFAULT 0,
    nay INTEGER DEFAULT 0,
    threshold REAL DEFAULT 0.618,
    status TEXT DEFAULT 'open',
    created_by INTEGER,
    created_at TEXT DEFAULT (datetime('now','localtime')),
    resolved_at TEXT
  );`);
  db.exec(`CREATE TABLE IF NOT EXISTS slim_votes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    proposal_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL,
    approve INTEGER NOT NULL,
    created_at TEXT DEFAULT (datetime('now','localtime')),
    UNIQUE(proposal_id, user_id)
  );`);
  db.exec(`CREATE TABLE IF NOT EXISTS slim_committee (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    side TEXT NOT NULL,
    seat_no INTEGER NOT NULL,
    name TEXT NOT NULL,
    role TEXT DEFAULT '代表'
  );`);
  db.exec(`CREATE TABLE IF NOT EXISTS slim_announcements (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    kind TEXT NOT NULL,
    title TEXT NOT NULL,
    body TEXT DEFAULT '',
    created_at TEXT DEFAULT (datetime('now','localtime'))
  );`);
  const cnt = db.prepare('SELECT COUNT(*) c FROM slim_committee').get().c;
  if (cnt === 0) {
    const ins = db.prepare('INSERT INTO slim_committee (side, seat_no, name, role) VALUES (?,?,?,?)');
    const supply = ['劳动力代表', '品牌方代表', '竹排组合代表'];
    const demand = ['采购方代表', '用工方代表', '投资者代表'];
    const plat = ['平台运营', '技术中立', '合规监督'];
    supply.forEach((n, i) => ins.run('supply', i + 1, n, '供应侧'));
    demand.forEach((n, i) => ins.run('demand', i + 1, n, '需求侧'));
    plat.forEach((n, i) => ins.run('platform', i + 1, n, '平台侧'));
  }
}

// ---- 挂牌上市 ----
// 2026-11-01 修复两处硬伤（发行侧样板前置条件）：
//   ① 不校验标的是否真实存在 —— 生产上因此出现 "TEST-L01" 这种凭空标的；
//   ② 不防重复挂牌 —— 同一标的可被反复提交，导致同一资产多个在架状态。
const ASSET_TABLES = { labor: 'slim_laborers', product: 'slim_products', entity: 'slim_entities' };

function submitListing(db, p) {
  ensureSchema(db);
  const type = String(p.asset_type || '').trim();
  const code = String(p.entity_code || '').trim();
  if (!ASSET_TABLES[type]) return { ok: false, code: 4201, error: 'asset_type 只能是 labor / product / entity' };
  if (!code) return { ok: false, code: 4202, error: '缺少 entity_code' };
  const table = ASSET_TABLES[type];
  const target = db.prepare('SELECT code, name FROM ' + table + ' WHERE code = ?').get(code);
  if (!target) return { ok: false, code: 4203, error: '标的不存在：' + table + ' 里没有 ' + code };
  const dup = db.prepare("SELECT id, status FROM slim_listings WHERE asset_type = ? AND entity_code = ? AND status IN ('pending','listed')").get(type, code);
  if (dup) return { ok: false, code: 4204, error: '该标的已在挂牌流程中（listing #' + dup.id + '，状态 ' + dup.status + '）' };
  const r = db.prepare('INSERT INTO slim_listings (asset_type, entity_code, entity_name, group_code, submitted_by, note) VALUES (?,?,?,?,?,?)')
    .run(type, code, p.entity_name || target.name || '', p.group_code || '', p.user_id || null, p.note || '');
  return db.prepare('SELECT * FROM slim_listings WHERE id = ?').get(r.lastInsertRowid);
}
function listListings(db, status) {
  ensureSchema(db);
  if (status) return db.prepare('SELECT * FROM slim_listings WHERE status = ? ORDER BY id DESC LIMIT 200').all(status);
  return db.prepare('SELECT * FROM slim_listings ORDER BY id DESC LIMIT 200').all();
}
function reviewListing(db, id, approved) {
  ensureSchema(db);
  const row = db.prepare('SELECT * FROM slim_listings WHERE id = ?').get(id);
  if (!row) return { ok: false, code: 4205, error: '挂牌记录不存在' };
  if (row.status !== 'pending') return { ok: false, code: 4206, error: '当前状态不是待审核（' + row.status + '）' };
  const st = approved ? 'listed' : 'suspended';
  db.prepare("UPDATE slim_listings SET status = ?, reviewed_at = datetime('now','localtime') WHERE id = ?").run(st, id);
  return db.prepare('SELECT * FROM slim_listings WHERE id = ?').get(id);
}

// ---- 治理：委员会 + 提案投票（61.8% 超级多数）----
function getCommittee(db) { ensureSchema(db); return db.prepare('SELECT * FROM slim_committee ORDER BY side, seat_no').all(); }
function submitProposal(db, p) {
  ensureSchema(db);
  const r = db.prepare('INSERT INTO slim_proposals (title, kind, threshold, created_by) VALUES (?,?,?,?)')
    .run(p.title, p.kind || 'constitution', Number(p.threshold) || 0.618, p.user_id || null);
  return db.prepare('SELECT * FROM slim_proposals WHERE id = ?').get(r.lastInsertRowid);
}
function listProposals(db) { ensureSchema(db); return db.prepare('SELECT * FROM slim_proposals ORDER BY id DESC LIMIT 50').all(); }
function voteProposal(db, id, userId, approve) {
  ensureSchema(db);
  const prop = db.prepare('SELECT * FROM slim_proposals WHERE id = ?').get(id);
  if (!prop) return { success: false, error: '提案不存在' };
  if (prop.status !== 'open') return { success: false, error: '提案已结束' };
  try {
    db.prepare('INSERT INTO slim_votes (proposal_id, user_id, approve) VALUES (?,?,?)').run(id, userId, approve ? 1 : 0);
  } catch (e) { return { success: false, error: '已投过票' }; }
  const v = db.prepare('SELECT COUNT(*) c FROM slim_votes WHERE proposal_id = ? AND approve = 1').get(id).c;
  const total = db.prepare('SELECT COUNT(*) c FROM slim_votes WHERE proposal_id = ?').get(id).c;
  const yea = v, nay = total - v;
  db.prepare('UPDATE slim_proposals SET yea = ?, nay = ? WHERE id = ?').run(yea, nay, id);
  let status = 'open';
  if (total > 0 && yea / total >= prop.threshold) {
    status = 'passed';
    db.prepare("UPDATE slim_proposals SET status = 'passed', resolved_at = datetime('now','localtime') WHERE id = ?").run(id);
    announce(db, 'governance', '治理提案通过', `「${prop.title}」以 ${(yea / total * 100).toFixed(1)}% 赞成（阈值 ${(prop.threshold * 100).toFixed(1)}%）通过。`);
  }
  return { success: true, yea, nay, total, status };
}

// ---- 竹排换血（B13）：总数守恒 · 年换血 6.18% · 按信用分末位淘汰失能/失信 · 补入新主体 ----
function runBambooRefresh(db, opts) {
  ensureSchema(db);
  const o = opts || {};
  let total;
  try { total = db.prepare("SELECT COUNT(*) c FROM slim_entities").get().c; } catch (e) { return { success: false, error: 'slim_entities 不存在，请先跑种子' }; }
  if (!total) return { success: false, error: '法人池为空' };
  const replaceN = Math.max(1, Math.round(total * 0.0618));
  // 末位（信用分最低）失能/失信主体退市
  const out = db.prepare("SELECT id, code, name, credit_score FROM slim_entities WHERE status != 'delisted' ORDER BY credit_score ASC LIMIT ?").all(replaceN);
  const del = db.prepare("UPDATE slim_entities SET status = 'delisted' WHERE id = ?");
  out.forEach(r => del.run(r.id));
  // 补入新主体，守恒
  const maxId = db.prepare('SELECT MAX(id) m FROM slim_entities').get().m || 0;
  const regions = ['深圳', '重庆', '杭州', '苏州', '宁波', '广州', '成都', '武汉'];
  const inds = ['智能制造', '文旅服务', '数字内容', '现代农业', '绿色能源'];
  const ins = db.prepare("INSERT INTO slim_entities (code, name, entity_type, industry, region, scale, credit_score, status) VALUES (?,?,?,?,?,?,?, 'listed')");
  const added = [];
  for (let i = 0; i < out.length; i++) {
    const nid = maxId + i + 1;
    const code = 'SE-' + String(1000 + nid).slice(-4);
    const row = { code, name: '新纳入竹排法人' + nid, entity_type: 'enterprise', industry: inds[nid % inds.length], region: regions[nid % regions.length], scale: 'S', credit_score: 70 + (nid % 25) };
    ins.run(row.code, row.name, row.entity_type, row.industry, row.region, row.scale, row.credit_score);
    added.push(row);
  }
  const after = db.prepare("SELECT COUNT(*) c FROM slim_entities WHERE status != 'delisted'").get().c;
  announce(db, 'bamboo', `竹排年度换血（${new Date().getFullYear()}）`,
    `按 6.18% 止损止盈线淘汰末位 ${out.length} 家失能/失信主体，补入 ${added.length} 家新主体，在册总数保持 ${after}（守恒）。退市样本：${out.slice(0, 3).map(x => x.name + '(' + x.credit_score + ')').join('、')}`);
  return { success: true, total_before: total, delisted: out.length, added: added.length, total_after: after, conserved: after, sample_out: out.slice(0, 5), sample_in: added.slice(0, 5) };
}

function announce(db, kind, title, body) {
  try { db.prepare('INSERT INTO slim_announcements (kind, title, body) VALUES (?,?,?)').run(kind, title, body); } catch (e) { /* 非阻断 */ }
}
function listAnnouncements(db, limit) { ensureSchema(db); return db.prepare('SELECT * FROM slim_announcements ORDER BY id DESC LIMIT ?').all(limit || 20); }

function overview(db) {
  ensureSchema(db);
  const counts = {};
  ['pending', 'listed', 'suspended'].forEach(s => {
    try { counts[s] = db.prepare('SELECT COUNT(*) c FROM slim_listings WHERE status = ?').get(s).c; } catch (e) { counts[s] = 0; }
  });
  let entities = 0, delisted = 0;
  try { entities = db.prepare("SELECT COUNT(*) c FROM slim_entities WHERE status != 'delisted'").get().c; } catch (e) {}
  try { delisted = db.prepare("SELECT COUNT(*) c FROM slim_entities WHERE status = 'delisted'").get().c; } catch (e) {}
  return {
    committee: getCommittee(db),
    listings: counts,
    proposals: listProposals(db).slice(0, 5),
    bamboo: { total: entities, delisted, replace_rate: 0.0618 },
    announcements: listAnnouncements(db, 10)
  };
}

module.exports = { ensureSchema, submitListing, listListings, reviewListing, getCommittee, submitProposal, listProposals, voteProposal, runBambooRefresh, listAnnouncements, overview };
