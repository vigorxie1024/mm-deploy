'use strict';
// 档案域 DDL：19 张 archive_* 表（纯增量，不碰现有 52 表；已清 8 张死表）
const { db } = require('./db');

function initArchiveSchema() {
  db.exec(`
  -- ===== 类目层 L1-L5（产品/频谱/频段/频道/频率）===== 
  CREATE TABLE IF NOT EXISTS archive_products (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    slug TEXT NOT NULL UNIQUE,
    name TEXT NOT NULL,
    description TEXT DEFAULT '',
    status TEXT NOT NULL DEFAULT 'active',
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    updated_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
  );
  CREATE TABLE IF NOT EXISTS archive_spectra (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    product_id INTEGER NOT NULL REFERENCES archive_products(id),
    code TEXT NOT NULL UNIQUE,
    name TEXT NOT NULL,
    description TEXT DEFAULT '',
    sort_order INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
  );
  CREATE TABLE IF NOT EXISTS archive_bands (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    spectrum_id INTEGER NOT NULL REFERENCES archive_spectra(id),
    code TEXT NOT NULL UNIQUE,
    name TEXT NOT NULL,
    shadow_type TEXT NOT NULL,
    sort_order INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
  );
  CREATE TABLE IF NOT EXISTS archive_channels (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    band_id INTEGER NOT NULL REFERENCES archive_bands(id),
    code TEXT NOT NULL UNIQUE,
    name TEXT NOT NULL,
    layer TEXT NOT NULL,
    sort_order INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
  );
  -- ===== 本体与记录档案层 ===== 
  CREATE TABLE IF NOT EXISTS archive_records (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    owner_type TEXT NOT NULL,
    owner_id INTEGER NOT NULL,
    band_id INTEGER NOT NULL REFERENCES archive_bands(id),
    channel_id INTEGER NOT NULL REFERENCES archive_channels(id),
    frequency_id TEXT NOT NULL,
    content_hash TEXT,
    record_type TEXT NOT NULL,
    meta TEXT DEFAULT '{}',
    content_ref TEXT DEFAULT '',
    size INTEGER NOT NULL DEFAULT 0,
    sensitivity TEXT NOT NULL DEFAULT 'medium',
    captured_at TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
  );
  CREATE TABLE IF NOT EXISTS archive_archives (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    owner_type TEXT NOT NULL,
    owner_id INTEGER NOT NULL,
    band_id INTEGER NOT NULL REFERENCES archive_bands(id),
    channel_id INTEGER NOT NULL REFERENCES archive_channels(id),
    frequency_id TEXT NOT NULL,
    title TEXT NOT NULL DEFAULT '',
    summary TEXT DEFAULT '',
    content TEXT DEFAULT '',
    tags TEXT DEFAULT '[]',
    distill_score REAL NOT NULL DEFAULT 0,
    source_record_ids TEXT DEFAULT '[]',
    is_licensed INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
  );
  -- 多路径归属（书稿硬要求：同一内容单元可被不同路径索引，不是复制——见 63 章挖掘「档案/索引」主题）
  -- 一个档案保持单一主频率(frequency_id)，另外的路径记在这里；查目录时 UNION，内容不重复存。
  CREATE TABLE IF NOT EXISTS archive_filings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    archive_id INTEGER NOT NULL REFERENCES archive_archives(id) ON DELETE CASCADE,
    frequency_id TEXT NOT NULL,
    note TEXT DEFAULT '',
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    UNIQUE(archive_id, frequency_id)
  );
  CREATE INDEX IF NOT EXISTS idx_files_freq ON archive_filings(frequency_id);
  CREATE INDEX IF NOT EXISTS idx_files_arc ON archive_filings(archive_id);
  -- 档案切片授权（P1 修复：licenseArchive 落地真实授权记录，独立于媒体域 slice_licenses）
  CREATE TABLE IF NOT EXISTS archive_licenses (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    archive_id INTEGER NOT NULL REFERENCES archive_archives(id) ON DELETE CASCADE,
    owner_type TEXT NOT NULL,
    owner_id INTEGER NOT NULL,
    licensee_id INTEGER,
    status TEXT NOT NULL DEFAULT 'active',
    note TEXT DEFAULT '',
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    revoked_at TEXT
  );
  CREATE TABLE IF NOT EXISTS archive_s (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    owner_type TEXT NOT NULL,
    owner_id INTEGER NOT NULL,
    s_type TEXT NOT NULL,
    meta TEXT DEFAULT '{}',
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    UNIQUE(owner_type, owner_id, s_type)
  );
  CREATE TABLE IF NOT EXISTS archive_distill_rules (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL DEFAULT 'default',
    theta REAL NOT NULL DEFAULT 0.618,
    w1 REAL NOT NULL DEFAULT 0.4,
    w2 REAL NOT NULL DEFAULT 0.3,
    w3 REAL NOT NULL DEFAULT 0.3,
    rho_0 REAL NOT NULL DEFAULT 0.01,
    rho_inf REAL NOT NULL DEFAULT 0.0001,
    lambda REAL NOT NULL DEFAULT 0.9,
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
  );
  CREATE TABLE IF NOT EXISTS archive_distill_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    owner_type TEXT NOT NULL,
    owner_id INTEGER NOT NULL,
    rule_id INTEGER REFERENCES archive_distill_rules(id),
    records_in INTEGER NOT NULL DEFAULT 0,
    archives_out INTEGER NOT NULL DEFAULT 0,
    rho REAL NOT NULL DEFAULT 0,
    started_at TEXT,
    finished_at TEXT
  );
  -- 已废弃死表（零引用，P2 清理）：archive_specs / archive_chapters / archive_concepts / archive_concept_relations
  -- ===== 授权层 五重门 ===== 
  CREATE TABLE IF NOT EXISTS archive_auth_grants (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    owner_type TEXT NOT NULL,
    owner_id INTEGER NOT NULL,
    gate1_personal INTEGER NOT NULL DEFAULT 0,
    gate2_institution INTEGER NOT NULL DEFAULT 0,
    gate3_legal INTEGER NOT NULL DEFAULT 0,
    gate4_system INTEGER NOT NULL DEFAULT 0,
    gate5_for_self INTEGER NOT NULL DEFAULT 0,
    granted_at TEXT,
    revoked_at TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
  );
  -- 已废弃死表（零引用）：archive_policies
  -- ===== 设备层 三角色 ===== 
  CREATE TABLE IF NOT EXISTS archive_devices (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    owner_type TEXT NOT NULL,
    owner_id INTEGER NOT NULL,
    device_id TEXT NOT NULL UNIQUE,
    device_name TEXT DEFAULT '',
    device_type TEXT NOT NULL,
    schema_version TEXT DEFAULT '1.0',
    agent_version TEXT DEFAULT '0.1.0',
    last_heartbeat TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
  );
  CREATE TABLE IF NOT EXISTS archive_device_roles (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    device_id TEXT NOT NULL REFERENCES archive_devices(device_id),
    role TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    UNIQUE(device_id, role)
  );
  CREATE TABLE IF NOT EXISTS archive_device_links (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    from_device TEXT NOT NULL REFERENCES archive_devices(device_id),
    to_device TEXT NOT NULL REFERENCES archive_devices(device_id),
    link_type TEXT NOT NULL DEFAULT 'sync',
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
  );
  CREATE TABLE IF NOT EXISTS archive_endpoints (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    device_id TEXT NOT NULL REFERENCES archive_devices(device_id),
    path TEXT NOT NULL,
    method TEXT NOT NULL DEFAULT 'POST',
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
  );
  -- ===== 智能体层 ===== 
  CREATE TABLE IF NOT EXISTS archive_agents (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    owner_type TEXT NOT NULL,
    owner_id INTEGER NOT NULL,
    agent_name TEXT DEFAULT '',
    agent_version TEXT DEFAULT '0.1.0',
    status TEXT NOT NULL DEFAULT 'idle',
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
  );
  CREATE TABLE IF NOT EXISTS archive_agent_matrix (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    owner_type TEXT NOT NULL,
    owner_id INTEGER NOT NULL,
    matrix_meta TEXT DEFAULT '{}',
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    UNIQUE(owner_type, owner_id)
  );
  CREATE TABLE IF NOT EXISTS archive_skills (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    agent_id INTEGER REFERENCES archive_agents(id),
    skill_name TEXT NOT NULL,
    skill_meta TEXT DEFAULT '{}',
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
  );
  -- ===== 主体层（五重门主体映射：person/institution/legal/system/for_self）=====
  CREATE TABLE IF NOT EXISTS archive_principals (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    principal_type TEXT NOT NULL,             -- person|institution|legal|system|for_self（五重门）
    user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,  -- 个人主体绑定登录用户（其它类型为 NULL）
    name TEXT NOT NULL DEFAULT '',
    id_no TEXT DEFAULT '',                     -- 证件号/统一社会信用代码
    verified INTEGER NOT NULL DEFAULT 0,
    status TEXT NOT NULL DEFAULT 'active',
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    updated_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    UNIQUE(principal_type, user_id),
    CHECK (principal_type != 'person' OR (user_id IS NOT NULL AND user_id > 0))
  );
  -- 已废弃死表（零引用，P2 清理）：archive_institution_depts / archive_institution_posts / archive_integrations
  `);
}

module.exports = { initArchiveSchema };
