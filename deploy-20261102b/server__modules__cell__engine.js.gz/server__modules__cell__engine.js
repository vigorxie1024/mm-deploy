'use strict';
// 细胞级碳硅联合劳动力引擎（第三谱系 CSchat-Cell）
// 严格实现 docs 契约 CONTRACT v0.1；不含任何 HTTP 细节，由 server.js 接线。
//
// 铁律（写死在这里，不接受调用方覆盖）：
//   1. 任务拆解权唯一归 nucleus；aina 只能复述意图
//   2. 审批超时 → 按拒绝处理（fail-closed），节点判 failed，不放行
//   3. progress 只许单调不减
//   4. 工具调用无 auth_token → 403
const crypto = require('node:crypto');

const CONTRACT_V = '0.1';
const BUDGET = Number(process.env.CELL_BUDGET || 200000);
const APPROVAL_TOKENS = Number(process.env.CELL_APPROVAL_TOKENS || 20000);
const APPROVAL_TTL = Number(process.env.CELL_APPROVAL_TTL || 1800);

function createCell() {
  const S = {
    seq: 0, log: [], idemp: new Map(), tasks: new Map(), approvals: new Map(),
    energy: { used_tokens: 0, budget_tokens: BUDGET },
    subs: new Set(),
  };

  const nowIso = () => new Date().toISOString().replace('Z', '+08:00');
  const rid = (p, n) => p + '-' + crypto.randomBytes(6).toString('hex').slice(0, n || 12);

  function emit(type, payload, opt) {
    const o = opt || {};
    S.seq += 1;
    const env = {
      v: CONTRACT_V, seq: S.seq, msg_id: rid('m'), ts: nowIso(),
      from: o.from || 'nucleus', to: o.to || 'all', type,
      trace_id: o.trace_id || rid('t', 8), payload,
    };
    S.log.push(env);
    if (S.log.length > 5000) S.log.splice(0, 1000);
    for (const res of S.subs) { try { res.write('data: ' + JSON.stringify(env) + '\n\n'); } catch (e) {} }
    return env;
  }
  const fail = (code, message, ref, trace) => emit('system.error', { code, message, ref }, { from: 'system', trace_id: trace });

  function energy() {
    const pct = Math.round((S.energy.used_tokens / Math.max(1, S.energy.budget_tokens)) * 1000) / 10;
    return { used_tokens: S.energy.used_tokens, budget_tokens: S.energy.budget_tokens, pct,
             level: pct >= 90 ? 'exhausted' : (pct >= 70 ? 'low' : 'ok') };
  }

  function requestApproval(taskId, nodeId, reason, cost, trace) {
    const aid = rid('ap', 6);
    S.approvals.set(aid, { status: 'pending', task_id: taskId, node_id: nodeId, reason,
                           cost_estimate: cost, expires_at: Date.now() + APPROVAL_TTL * 1000 });
    const t = S.tasks.get(taskId);
    if (t && t.nodes[nodeId]) t.nodes[nodeId].status = 'blocked';   // 契约 §6：挂起不是 running
    emit('approval.request', { approval_id: aid, task_id: taskId, node_id: nodeId, reason,
                               cost_estimate: cost, expires_at: new Date(Date.now() + APPROVAL_TTL * 1000).toISOString() },
         { from: 'nucleus', to: 'vx', trace_id: trace });
    return aid;
  }

  function markFailed(ap, code, msg) {
    const t = S.tasks.get(ap.task_id);
    if (t && t.nodes[ap.node_id]) { t.nodes[ap.node_id].status = 'failed'; t.nodes[ap.node_id].error = code; }
    fail(code, msg);
  }

  function planTask(text, trace) {
    if (!text || text.trim().length < 2) { fail('E4007', '中枢拆解失败：指令太短', null, trace); return null; }
    const taskId = rid('tk', 6);
    const nodes = {
      n1: { node_id: 'n1', parent_id: null, title: text.trim().slice(0, 40), owner: 'nucleus', status: 'running', progress: 10, depends_on: [] },
      n2: { node_id: 'n2', parent_id: 'n1', title: '抓取与整理数据', owner: 'agent:crawler', status: 'done', progress: 100, depends_on: [], output_ref: 'out-1' },
      n3: { node_id: 'n3', parent_id: 'n1', title: '生成交付物', owner: 'agent:writer', status: 'pending', progress: 0, depends_on: ['n2'] },
    };
    S.tasks.set(taskId, { title: text.trim().slice(0, 40), root_node_id: 'n1', nodes, trace_id: trace });
    emit('task.plan', { task_id: taskId, root_node_id: 'n1', nodes: [nodes.n1, nodes.n2, nodes.n3] }, { trace_id: trace });
    emit('energy.update', energy(), { from: 'system', trace_id: trace });
    const cost = text.length > 8 ? 30000 : 1000;
    if (cost > APPROVAL_TOKENS) requestApproval(taskId, 'n3', '预计消耗 ' + cost + ' tokens，超过单节点阈值 ' + APPROVAL_TOKENS, cost, trace);
    return taskId;
  }

  function nodeUpdate(taskId, nodeId, status, progress, note, trace) {
    const t = S.tasks.get(taskId);
    if (!t) { fail('E4002', '任务不存在', null, trace); return { ok: false, code: 'E4002', http: 404 }; }
    const n = t.nodes[nodeId];
    if (!n) { fail('E4002', '节点不存在', null, trace); return { ok: false, code: 'E4002', http: 404 }; }
    if (progress != null && progress < (n.progress || 0)) {
      fail('E4003', 'progress 不允许回退（' + (n.progress || 0) + ' → ' + progress + '）', null, trace);
      return { ok: false, code: 'E4003', http: 409 };
    }
    if (status) {
      if (!['pending', 'running', 'done', 'failed', 'blocked', 'skipped'].includes(status)) {
        fail('E4003', '非法状态：' + status, null, trace);
        return { ok: false, code: 'E4003', http: 409 };
      }
      n.status = status;
    }
    if (progress != null) n.progress = progress;
    if (note) n.note = note;
    emit('task.node.update', { task_id: taskId, node_id: nodeId, status: n.status, progress: n.progress || 0 }, { trace_id: trace });
    return { ok: true, node: n, http: 200 };
  }

  function decideApproval(aid, approved) {
    const ap = S.approvals.get(aid);
    if (!ap) return { ok: false, code: 'E4002', error: '审批不存在', http: 404 };
    if (ap.status !== 'pending') return { ok: true, already: true, status: ap.status, http: 200 };
    if (Date.now() > ap.expires_at) {
      ap.status = 'expired';
      markFailed(ap, 'E4004', '审批超时，按拒绝处理');
      return { ok: true, status: 'expired', http: 200 };
    }
    ap.status = approved ? 'approved' : 'denied';
    const t = S.tasks.get(ap.task_id);
    if (t && t.nodes[ap.node_id]) {
      if (approved) t.nodes[ap.node_id].status = 'running';
      else markFailed(ap, 'E4004', '碳基主理人拒绝');
    }
    emit('approval.decision', { approval_id: aid, approved: !!approved, by: 'vx', at: nowIso() }, { from: 'vx', to: 'nucleus' });
    return { ok: true, status: ap.status, http: 200 };
  }

  function toolCall(name, args, token) {
    if (!token) { fail('E4001', '工具调用缺少 auth_token', 'tool:' + name); return { ok: false, code: 'E4001', http: 403 }; }
    if (name === 'weather') return { ok: true, tool: 'weather', city: (args && args.city) || '上海', result: '小雨', mock: true, http: 200 };
    if (name === 'notify') { emit('chat.agent', { text: '[通知] ' + String((args && args.text) || '').slice(0, 60) }, { from: 'tool:notify' }); return { ok: true, tool: 'notify', sent: true, mock: true, http: 200 }; }
    fail('E4002', '未知工具：' + name);
    return { ok: false, code: 'E4002', http: 404 };
  }

  function say(text, from) {
    const t = String(text || '').trim();
    if (!t) return { ok: false, error: 'empty', http: 400 };
    emit('chat.user', { text: t }, { from: from || 'vx' });
    // Aina 只复述，不拆解（契约铁律）
    emit('task.proposed', { precheck_id: rid('pc', 6), restatement: '你是要我：' + t.slice(0, 60), intent: t.slice(0, 60) }, { from: 'aina', to: 'vx' });
    const taskId = planTask(t, null);
    return { ok: true, task_id: taskId, http: 200 };
  }

  function msg(env) {
    if (!env || env.v !== CONTRACT_V) { fail('E4006', '契约版本不符：期望 ' + CONTRACT_V + '，收到 ' + (env && env.v)); return { ok: false, code: 'E4006', http: 400 }; }
    if (env.msg_id && S.idemp.has(env.msg_id)) return Object.assign({ http: 200 }, S.idemp.get(env.msg_id));
    let out;
    const p = env.payload || {};
    if (env.type === 'chat.user') out = say(p.text, env.from);
    else if (env.type === 'task.node.update') { const r = nodeUpdate(p.task_id, p.node_id, p.status, p.progress, p.note, env.trace_id); out = { ok: r.ok, code: r.code, http: r.http }; }
    else if (env.type === 'approval.decision') { const r = decideApproval(p.approval_id, !!p.approved); out = { ok: r.ok, status: r.status, http: r.http }; }
    else if (env.type === 'tool.call') { const r = toolCall(p.name, p.args, p.auth_token); out = { ok: r.ok, code: r.code, http: r.http, result: r }; }
    else out = { ok: true, ignored: env.type, http: 200 };   // 未知类型：忽略不崩（契约 §3）
    if (env.msg_id) S.idemp.set(env.msg_id, out);
    return out;
  }

  function pause() {
    for (const t of S.tasks.values()) for (const n of Object.values(t.nodes)) if (n.status === 'running') n.status = 'blocked';
    emit('energy.update', energy(), { from: 'system' });
    return { ok: true, paused: true };
  }

  function state() {
    const tasks = {};
    for (const [id, t] of S.tasks) tasks[id] = { title: t.title, nodes: Object.values(t.nodes) };
    const approvals = {};
    for (const [id, a] of S.approvals) approvals[id] = a;
    return { energy: energy(), seq: S.seq, tasks, approvals };
  }

  function snapshot(q) {
    const trace = (q && q.trace_id) || '';
    const upto = Number((q && q.upto_seq) || 999999999);
    return { readonly: true, messages: S.log.filter(m => m.seq <= upto && (!trace || m.trace_id === trace)) };
  }

  function subscribe(req, res) {
    const since = Number((req && req.query && req.query.since_seq) || 0);
    res.writeHead(200, { 'Content-Type': 'text/event-stream; charset=utf-8', 'Cache-Control': 'no-cache', 'Connection': 'keep-alive', 'X-Accel-Buffering': 'no' });
    for (const m of S.log) if (m.seq > since) res.write('data: ' + JSON.stringify(m) + '\n\n');
    S.subs.add(res);
    const ka = setInterval(() => { try { res.write(': ka\n\n'); } catch (e) {} }, 25000);
    if (ka.unref) ka.unref();
    const drop = () => { clearInterval(ka); S.subs.delete(res); };
    req.on('close', drop); req.on('error', drop);
  }

  // 后台扫过期审批
  const sweeper = setInterval(() => {
    const now = Date.now();
    for (const ap of S.approvals.values()) {
      if (ap.status === 'pending' && now > ap.expires_at) { ap.status = 'expired'; markFailed(ap, 'E4004', '审批超时，按拒绝处理'); }
    }
  }, 1000);
  if (sweeper.unref) sweeper.unref();

  return { CONTRACT_V, emit, say, msg, nodeUpdate, decideApproval, toolCall, pause, state, snapshot, subscribe, energy, _S: S };
}

module.exports = { createCell, CONTRACT_V };
