'use strict';
// 档案域引擎：完整实现（类目/影子/授权/记录/档案/蒸馏/设备/智能体）
const { db } = require('./db');
const { initArchiveSchema } = require('./archive-schema');
initArchiveSchema();

// ===== L5 频率常量（原子级，不可再分，只读）=====
const FREQUENCIES = [
  { code: 'fr-health', name: '健康', channels: ['ch-p-rec', 'ch-p-arc'] },
  { code: 'fr-finance', name: '财务', channels: ['ch-p-rec', 'ch-p-arc'] },
  { code: 'fr-hobby', name: '爱好', channels: ['ch-p-rec', 'ch-p-arc'] },
  { code: 'fr-media', name: '图像视频', channels: ['ch-p-rec', 'ch-p-arc'] },
  { code: 'fr-other', name: '其它', channels: ['ch-p-rec', 'ch-p-arc'] },
  { code: 'fr-kin', name: '亲朋好友', channels: ['ch-f-core'] },
  { code: 'fr-family-other', name: '其它', channels: ['ch-f-core'] },
];

// ===== 设备三件套（采集器·千眼 / 处理器·一体 / 行动器·千手）=====
const DEVICE_ROLES = {
  collector: { label: '采集器·千眼', desc: '采集全量冷记录（手机传感器/输入/位置等）' },
  processor: { label: '处理器·一体', desc: '记录→档案蒸馏、哈希存证、检索' },
  actor:     { label: '行动器·千手', desc: '授权/许可/设备联动/agent 调用等行动' }
};

// ===== 档案开发智能体：默认技能目录 + 协同矩阵 =====
const DEFAULT_SKILLS = [
  { name: 'record.capture',    meta: { label: '记录采集',   desc: '采集全量冷记录（单条/批量，哈希去重）', api: 'POST /api/archive/records' } },
  { name: 'record.hash',       meta: { label: '哈希存证',   desc: '内容 SHA256 存证与去重，防篡改', api: 'createRecordsBatch' } },
  { name: 'distill',           meta: { label: '蒸馏',       desc: 'θ=0.618 记录→档案蒸馏（V·F·U 加权）', api: 'POST /api/archive/distill' } },
  { name: 'archive.search',    meta: { label: '档案检索',   desc: '精华档案关键词检索', api: 'GET /api/archive/search' } },
  { name: 'auth.gate',         meta: { label: '五重门授权', desc: '个人/机构/法律/系统/自用 五重授权门', api: 'POST /api/archive/grants' } },
  { name: 'agent.collaborate', meta: { label: '智能体协同', desc: '多智能体矩阵协同（与审计智能体联动）', api: 'GET /api/archive/agents' } },
];

const DEFAULT_MATRIX = {
  name: '档案开发智能体协同矩阵',
  version: '1.0',
  agent_class: 'archive-developer',
  collaborators: ['audit-agent'],
  skills: DEFAULT_SKILLS.map(s => s.name),
  note: '档案开发智能体负责「记录采集→哈希存证→蒸馏→检索」，审计智能体负责核验其产出并发布审计报告。',
};

// ===== 公共小工具（收敛重复代码：所有权校验 / 分页 / 计数 / 幂等插入）=====
// 所有权校验：行不存在或非本人 → { ok:false, code:4101 }，否则 null（收敛 deleteRecord/updateArchive/licenseArchive/revokeLicense/deleteArchive 五处）
function ownOr4101(row, ownerId) {
  if (!row || row.owner_id !== ownerId) return { ok: false, code: 4101 };
  return null;
}
// 按所有者分页：拼 where → COUNT → 分页 SELECT（table/f.col/orderBy 均为内部硬编码，值走参数，无注入面）
function pagedByOwner(table, ownerType, ownerId, filters, orderBy, limit, offset) {
  const cond = ['owner_type = ?', 'owner_id = ?'];
  const args = [ownerType, ownerId];
  for (const f of filters) { cond.push(f.col + ' = ?'); args.push(f.val); }
  const where = cond.join(' AND ');
  const total = db.prepare(`SELECT COUNT(*) c FROM ${table} WHERE ${where}`).get(...args);
  const rows = db.prepare(`SELECT * FROM ${table} WHERE ${where} ORDER BY ${orderBy} LIMIT ? OFFSET ?`).all(...args, limit, offset);
  return { total: total.c, rows };
}
// 按所有者计数
function countByOwner(table, ownerType, ownerId) {
  return db.prepare(`SELECT COUNT(*) c FROM ${table} WHERE owner_type = ? AND owner_id = ?`).get(ownerType, ownerId).c;
}
// 幂等插入：存在则返回既有 id，否则插入并返回新 id（收敛技能/矩阵补齐链的「查存在→不存在则插」）
function idempotentInsert(table, whereCols, whereVals, insertCols, insertVals) {
  const cond = whereCols.map(function(c) { return c + ' = ?'; }).join(' AND ');
  const ex = db.prepare(`SELECT id FROM ${table} WHERE ${cond}`).get(...whereVals);
  if (ex) return { id: ex.id, created: false };
  const ph = insertCols.map(function() { return '?'; }).join(', ');
  const r = db.prepare(`INSERT INTO ${table} (${insertCols.join(', ')}) VALUES (${ph})`).run(...insertVals);
  return { id: Number(r.lastInsertRowid), created: true };
}

// ===== 类目层（L1-L4 只读）=====
function getCatalogTree() {
  const products = db.prepare(`SELECT * FROM archive_products WHERE status = 'active' ORDER BY id`).all();
  const spectra = db.prepare(`SELECT * FROM archive_spectra ORDER BY sort_order`).all();
  const bands = db.prepare(`SELECT * FROM archive_bands ORDER BY sort_order`).all();
  const channels = db.prepare(`SELECT * FROM archive_channels ORDER BY sort_order`).all();
  return { products, spectra, bands, channels };
}
function getSpectra() { return db.prepare(`SELECT id, code, name, description FROM archive_spectra ORDER BY sort_order`).all(); }
function getBands(spectrumCode) {
  if (spectrumCode) return db.prepare(`SELECT b.id, b.code, b.name, b.shadow_type FROM archive_bands b JOIN archive_spectra s ON b.spectrum_id = s.id WHERE s.code = ? ORDER BY b.sort_order`).all(spectrumCode);
  return db.prepare(`SELECT id, code, name, shadow_type FROM archive_bands ORDER BY sort_order`).all();
}
function getChannels(bandCode) {
  if (bandCode) return db.prepare(`SELECT c.id, c.code, c.name, c.layer FROM archive_channels c JOIN archive_bands b ON c.band_id = b.id WHERE b.code = ? ORDER BY c.sort_order`).all(bandCode);
  return db.prepare(`SELECT id, code, name, layer FROM archive_channels ORDER BY sort_order`).all();
}
function getFrequencies() { return FREQUENCIES; }

// ===== 影子层（S=f(L) 落地：影子=活体在每个频段的记录/档案足迹快照）=====
function computeShadow(ownerType, ownerId) {
  const bands = db.prepare(`SELECT id, code, shadow_type FROM archive_bands ORDER BY sort_order`).all();
  const shadows = [];
  for (const band of bands) {
    const recs = db.prepare(`SELECT COUNT(*) c, COALESCE(SUM(size),0) sz, MAX(captured_at) latest FROM archive_records WHERE owner_type=? AND owner_id=? AND band_id=?`).get(ownerType, ownerId, band.id);
    const arcs = db.prepare(`SELECT COUNT(*) c FROM archive_archives WHERE owner_type=? AND owner_id=? AND band_id=?`).get(ownerType, ownerId, band.id);
    const freqs = db.prepare(`SELECT frequency_id, COUNT(*) c FROM archive_records WHERE owner_type=? AND owner_id=? AND band_id=? GROUP BY frequency_id ORDER BY c DESC LIMIT 5`).all(ownerType, ownerId, band.id);
    const meta = {
      band: band.code,
      records: recs.c,
      archives: arcs.c,
      size: recs.sz || 0,
      latest: recs.latest || null,
      rho: recs.c ? Math.round((arcs.c / recs.c) * 1000) / 1000 : 0,
      top_frequencies: freqs.map(f => ({ code: f.frequency_id, count: f.c }))
    };
    db.prepare(`INSERT INTO archive_s (owner_type, owner_id, s_type, meta) VALUES (?, ?, ?, ?) ON CONFLICT(owner_type, owner_id, s_type) DO UPDATE SET meta = excluded.meta`).run(ownerType, ownerId, band.shadow_type, JSON.stringify(meta));
    shadows.push(Object.assign({ s_type: band.shadow_type }, meta));
  }
  return shadows;
}
function getShadow(ownerType, ownerId) { computeShadow(ownerType, ownerId); return db.prepare(`SELECT * FROM archive_s WHERE owner_type = ? AND owner_id = ? ORDER BY s_type`).all(ownerType, ownerId); }
function getDeviceRoles() { return DEVICE_ROLES; }

function getShadowSummary(ownerType, ownerId) {
  return {
    records: countByOwner('archive_records', ownerType, ownerId),
    archives: countByOwner('archive_archives', ownerType, ownerId),
    devices: countByOwner('archive_devices', ownerType, ownerId),
    shadows: computeShadow(ownerType, ownerId)  // S_p/S_f/S_o 三态影子
  };
}

// ===== 授权层（五重门）=====
function getGrants(ownerType, ownerId) { return db.prepare(`SELECT * FROM archive_auth_grants WHERE owner_type = ? AND owner_id = ? ORDER BY id DESC`).all(ownerType, ownerId); }
function createGrant(ownerType, ownerId, gates) {
  const result = db.prepare(`INSERT INTO archive_auth_grants (owner_type, owner_id, gate1_personal, gate2_institution, gate3_legal, gate4_system, gate5_for_self, granted_at) VALUES (?, ?, ?, ?, ?, ?, ?, datetime('now','localtime'))`).run(
    ownerType, ownerId, gates.personal ? 1 : 0, gates.institution ? 1 : 0, gates.legal ? 1 : 0, gates.system ? 1 : 0, gates.for_self ? 1 : 0
  );
  return { id: result.lastInsertRowid };
}
// 撤销五重门授权。2026-10-31 闭环巡检发现「只能开不能关」——补上，并加归属校验：
// 原先 revokeGrant(id) 不校验所有者，任何人拿到 id 就能撤掉别人的授权。
function revokeGrant(id, ownerType, ownerId) {
  const g = db.prepare('SELECT * FROM archive_auth_grants WHERE id = ?').get(id);
  if (!g) return { ok: false, code: 4101 };
  if (ownerType && (g.owner_type !== ownerType || g.owner_id !== ownerId)) return { ok: false, code: 4101 };
  if (g.revoked_at) return { ok: true, already: true };
  db.prepare(`UPDATE archive_auth_grants SET revoked_at = datetime('now','localtime') WHERE id = ?`).run(id);
  return { ok: true };
}
function checkGates(ownerType, ownerId) {
  const grant = db.prepare(`SELECT * FROM archive_auth_grants WHERE owner_type = ? AND owner_id = ? AND revoked_at IS NULL ORDER BY id DESC LIMIT 1`).get(ownerType, ownerId);
  const gates = { personal: grant ? !!grant.gate1_personal : false, institution: grant ? !!grant.gate2_institution : false, legal: grant ? !!grant.gate3_legal : false, system: grant ? !!grant.gate4_system : false, for_self: grant ? !!grant.gate5_for_self : false };
  let blockedBy = null;
  if (!gates.personal) blockedBy = 'personal'; else if (!gates.institution) blockedBy = 'institution'; else if (!gates.legal) blockedBy = 'legal'; else if (!gates.system) blockedBy = 'system'; else if (!gates.for_self) blockedBy = 'for_self';
  return { allowed: !blockedBy, blockedBy, gates };
}

// ===== 记录层（record 全量·冷）=====
function createRecord(o) {
  const result = db.prepare(`INSERT INTO archive_records (owner_type, owner_id, band_id, channel_id, frequency_id, content_hash, record_type, meta, content_ref, size, sensitivity, captured_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`).run(
    o.ownerType, o.ownerId, o.bandId, o.channelId, o.frequencyId, o.contentHash || null, o.recordType, o.meta ? JSON.stringify(o.meta) : '{}', o.contentRef || '', o.size || 0, o.sensitivity || 'medium', o.capturedAt || null
  );
  return { id: result.lastInsertRowid };
}
function createRecordsBatch(records) {
  let inserted = 0;
  db.exec('BEGIN');
  try {
    for (const r of records) {
      if (r.contentHash) { const ex = db.prepare(`SELECT id FROM archive_records WHERE content_hash = ?`).get(r.contentHash); if (ex) continue; }
      createRecord(r); inserted++;
    }
    db.exec('COMMIT');
  } catch (e) { db.exec('ROLLBACK'); throw e; }
  return { inserted };
}
function getRecords(o) {
  const filters = [];
  if (o.channelId) filters.push({ col: 'channel_id', val: o.channelId });
  if (o.frequencyId) filters.push({ col: 'frequency_id', val: o.frequencyId });
  return pagedByOwner('archive_records', o.ownerType, o.ownerId, filters, 'id DESC', o.limit || 50, o.offset || 0);
}
function getRecord(id) { return db.prepare(`SELECT * FROM archive_records WHERE id = ?`).get(id) || null; }
function deleteRecord(id, ownerId) {
  const rec = db.prepare(`SELECT * FROM archive_records WHERE id = ?`).get(id);
  const err = ownOr4101(rec, ownerId); if (err) return err;
  db.prepare(`DELETE FROM archive_records WHERE id = ?`).run(id);
  return { ok: true };
}

// ===== 档案层（archive 精华·热）=====
function getArchives(o) {
  const filters = [];
  if (o.frequencyId) filters.push({ col: 'frequency_id', val: o.frequencyId });
  return pagedByOwner('archive_archives', o.ownerType, o.ownerId, filters, 'distill_score DESC', o.limit || 50, o.offset || 0);
}
function getArchive(id) { return db.prepare(`SELECT * FROM archive_archives WHERE id = ?`).get(id) || null; }

// ===== 多路径归属（multi-home）=====
// 书稿要求：同一内容单元可被不同路径索引，且不是复制。
// 做法：主路径仍是 archive_archives.frequency_id，额外路径写 archive_filings；内容只存一份。
function getFilings(archiveId) {
  // 频率是引擎内常量表（FREQUENCIES），archive_channels 表里没有 frequency_id 列——
  // 所以这里只查落库字段，频率名在应用层映射，避免拼一个不存在的列。
  const rows = db.prepare('SELECT * FROM archive_filings WHERE archive_id = ? ORDER BY id').all(archiveId);
  return rows.map(function (r) {
    const fr = FREQUENCIES.find(f => f.code === r.frequency_id) || {};
    return Object.assign({}, r, { frequency_name: fr.name || r.frequency_id });
  });
}
function fileArchive(archiveId, ownerId, frequencyId, note) {
  const arc = db.prepare('SELECT * FROM archive_archives WHERE id = ?').get(archiveId);
  const err = ownOr4101(arc, ownerId); if (err) return err;
  if (!frequencyId) return { ok: false, code: 4102 };
  if (arc.frequency_id === frequencyId) return { ok: true, already: true, primary: true };
  // 频率必须是引擎常量表里的合法频率，避免脏路径（archive_channels 无 frequency_id 列）
  const fr = FREQUENCIES.find(f => f.code === frequencyId);
  if (!fr) return { ok: false, code: 4103 };
  const ex = db.prepare('SELECT id FROM archive_filings WHERE archive_id = ? AND frequency_id = ?').get(archiveId, frequencyId);
  if (ex) return { ok: true, already: true, filingId: ex.id };
  const r = db.prepare(`INSERT INTO archive_filings (archive_id, frequency_id, note) VALUES (?, ?, ?)`).run(archiveId, frequencyId, String(note || ''));
  return { ok: true, filingId: Number(r.lastInsertRowid), created: true };
}
function unfileArchive(archiveId, ownerId, frequencyId) {
  const arc = db.prepare('SELECT * FROM archive_archives WHERE id = ?').get(archiveId);
  const err = ownOr4101(arc, ownerId); if (err) return err;
  if (arc.frequency_id === frequencyId) return { ok: false, code: 4104 }; // 主路径不能靠解绑删除
  const r = db.prepare('DELETE FROM archive_filings WHERE archive_id = ? AND frequency_id = ?').run(archiveId, frequencyId);
  return { ok: true, removed: Number(r.changes) };
}
// 查某频率下的全部档案：主路径 + 额外路径，合并去重，并标出是通过哪条路径被索引到的
function getArchivesByFrequency(ownerType, ownerId, frequencyId, limit, offset) {
  const lim = limit || 50, off = offset || 0;
  const total = db.prepare(`SELECT COUNT(*) c FROM archive_archives a
    WHERE a.owner_type = ? AND a.owner_id = ?
      AND (a.frequency_id = ? OR EXISTS (SELECT 1 FROM archive_filings f WHERE f.archive_id = a.id AND f.frequency_id = ?))`)
    .get(ownerType, ownerId, frequencyId, frequencyId).c;
  const rows = db.prepare(`SELECT a.*, CASE WHEN a.frequency_id = ? THEN 'primary' ELSE 'filed' END AS via
    FROM archive_archives a
    WHERE a.owner_type = ? AND a.owner_id = ?
      AND (a.frequency_id = ? OR EXISTS (SELECT 1 FROM archive_filings f WHERE f.archive_id = a.id AND f.frequency_id = ?))
    ORDER BY a.distill_score DESC, a.id DESC LIMIT ? OFFSET ?`)
    .all(frequencyId, ownerType, ownerId, frequencyId, frequencyId, lim, off);
  return { total, rows };
}
function updateArchive(id, ownerId, patch) {
  const arc = db.prepare(`SELECT * FROM archive_archives WHERE id = ?`).get(id);
  const err = ownOr4101(arc, ownerId); if (err) return err;
  db.prepare(`UPDATE archive_archives SET title = ?, summary = ?, content = ?, tags = ? WHERE id = ?`).run(patch.title ?? arc.title, patch.summary ?? arc.summary, patch.content ?? arc.content, patch.tags ? JSON.stringify(patch.tags) : arc.tags, id);
  return { ok: true };
}
function licenseArchive(id, ownerId, licenseeId) {
  const arc = db.prepare(`SELECT * FROM archive_archives WHERE id = ?`).get(id);
  const err = ownOr4101(arc, ownerId); if (err) return err;
  // 幂等：已有同 licensee 的 active 授权则返回已有（防止重复插入）
  const existing = db.prepare(`SELECT id FROM archive_licenses WHERE archive_id = ? AND status = 'active' AND licensee_id IS ?`).get(id, licenseeId || null);
  if (existing) return { ok: true, licenseId: existing.id, already: true };
  db.exec('BEGIN');
  try {
    db.prepare(`UPDATE archive_archives SET is_licensed = 1 WHERE id = ?`).run(id);
    const result = db.prepare(`INSERT INTO archive_licenses (archive_id, owner_type, owner_id, licensee_id, status) VALUES (?, ?, ?, ?, 'active')`).run(id, arc.owner_type, arc.owner_id, licenseeId || null);
    db.exec('COMMIT');
    return { ok: true, licenseId: result.lastInsertRowid };
  } catch (e) { db.exec('ROLLBACK'); throw e; }
}
function getLicenses(ownerType, ownerId) {
  return db.prepare(`SELECT * FROM archive_licenses WHERE owner_type = ? AND owner_id = ?`).all(ownerType, ownerId);
}
function revokeLicense(id, ownerId) {
  const lic = db.prepare(`SELECT * FROM archive_licenses WHERE id = ?`).get(id);
  const err = ownOr4101(lic, ownerId); if (err) return err;
  db.exec('BEGIN');
  try {
    db.prepare(`UPDATE archive_licenses SET status = 'revoked', revoked_at = datetime('now','localtime') WHERE id = ?`).run(id);
    // 回写：若该档案没有其它 active 授权，则 is_licensed=0
    const active = db.prepare(`SELECT COUNT(*) c FROM archive_licenses WHERE archive_id = ? AND status = 'active' AND id != ?`).get(lic.archive_id, id);
    if (active.c === 0) db.prepare(`UPDATE archive_archives SET is_licensed = 0 WHERE id = ?`).run(lic.archive_id);
    db.exec('COMMIT');
  } catch (e) { db.exec('ROLLBACK'); throw e; }
  return { ok: true };
}
function deleteArchive(id, ownerId) {
  const arc = db.prepare(`SELECT * FROM archive_archives WHERE id = ?`).get(id);
  const err = ownOr4101(arc, ownerId); if (err) return err;
  db.prepare(`DELETE FROM archive_archives WHERE id = ?`).run(id);
  return { ok: true };
}
function searchArchives(ownerType, ownerId, keyword, limit) {
  const kw = '%' + (keyword || '') + '%';
  return db.prepare(`SELECT * FROM archive_archives WHERE owner_type = ? AND owner_id = ? AND (title LIKE ? OR summary LIKE ? OR content LIKE ?) ORDER BY distill_score DESC LIMIT ?`).all(ownerType, ownerId, kw, kw, kw, limit || 50);
}

// ===== 蒸馏层（θ=0.618 核心）=====
function sensitivityScore(s) { return { low: 0.2, medium: 0.5, high: 0.8, critical: 1.0 }[s] || 0.5; }
// F = 频率分：取 frequency_id（L5 频率原子 fr-*）；M2 修复：原误用 record_type 导致 F 退化为常数
function frequencyScore(freqId) {
  const weights = {
    'fr-health': 0.8, 'fr-finance': 0.7, 'fr-media': 0.6,
    'fr-hobby': 0.5, 'fr-other': 0.4, 'fr-kin': 0.6, 'fr-family-other': 0.5,
  };
  return weights[freqId] || 0.5;
}
function getDistillRules() { return db.prepare(`SELECT * FROM archive_distill_rules ORDER BY id`).all(); }
function updateDistillRules(id, patch) {
  const rule = db.prepare(`SELECT * FROM archive_distill_rules WHERE id = ?`).get(id);
  if (!rule) return { ok: false };
  db.prepare(`UPDATE archive_distill_rules SET theta = ?, w1 = ?, w2 = ?, w3 = ? WHERE id = ?`).run(patch.theta ?? rule.theta, patch.w1 ?? rule.w1, patch.w2 ?? rule.w2, patch.w3 ?? rule.w3, id);
  return { ok: true };
}
function runDistill(ownerType, ownerId, ruleId) {
  const rule = (ruleId ? db.prepare(`SELECT * FROM archive_distill_rules WHERE id = ?`).get(ruleId) : null) || db.prepare(`SELECT * FROM archive_distill_rules ORDER BY id LIMIT 1`).get() || { id: null, theta: 0.618, w1: 0.4, w2: 0.3, w3: 0.3 };
  const records = db.prepare(`SELECT * FROM archive_records WHERE owner_type = ? AND owner_id = ?`).all(ownerType, ownerId);
  // 去重：已蒸馏的记录跳过（从已有档案的 source_record_ids 收集）
  const existingArchives = db.prepare(`SELECT source_record_ids FROM archive_archives WHERE owner_type = ? AND owner_id = ?`).all(ownerType, ownerId);
  const distilled = new Set();
  for (const a of existingArchives) {
    try { const ids = JSON.parse(a.source_record_ids || '[]'); for (const id of ids) distilled.add(id); } catch (e) {}
  }
  let archivesOut = 0;
  let coldStart = false;
  let bestRec = null, bestS = -1;   // 冷启动保底用：记住最够格的那一条
  const startedAt = new Date().toISOString();
  // U 独特度 = 类型稀有度（IDF）：越稀有的类型越独特
  const typeCount = {};
  for (const rec of records) { typeCount[rec.record_type] = (typeCount[rec.record_type] || 0) + 1; }
  const totalN = records.length || 1;
  db.exec('BEGIN');
  try {
    for (const rec of records) {
      if (distilled.has(rec.id)) continue;
      const V = sensitivityScore(rec.sensitivity);   // V = 价值分（敏感度）
      const F = frequencyScore(rec.frequency_id);    // F = 频率分（L5 频率；M2 修复：不再误用 record_type）
      // U 独特度 = 同类型记录占比的补：typeCount 减 1 避免「单条记录 U=0 永远蒸馏不出」
      const U = totalN <= 1 ? 1 : (1 - ((typeCount[rec.record_type] || 0) - 1) / totalN); // 单条/唯一类型给满独特度
      const S = rule.w1 * V + rule.w2 * F + rule.w3 * U;
      // 记录「最够格的一条」：冷启动保底时用它，避免用户第一次用拿不到档案
      if (S > bestS) { bestS = S; bestRec = rec; }
      if (S >= rule.theta) {
        // P1 修复：填充 title/summary/content，使蒸馏后的档案可被检索（此前三者全空导致 search 恒空）
        const freqName = (FREQUENCIES.find(f => f.code === rec.frequency_id) || {}).name || rec.frequency_id;
        let m = {};
        try { m = JSON.parse(rec.meta || '{}'); } catch (e) {}
        // 正文兜底：meta 没有 detail 时依次退到 title / content_ref / record_type ——
        // 否则蒸馏出的档案正文是空的，检索和导出都拿不到东西（2026-10-31 闭环巡检发现）
        const detail = String(m.detail || m.title || rec.content_ref || rec.record_type || '');
        db.prepare(`INSERT INTO archive_archives (owner_type, owner_id, band_id, channel_id, frequency_id, title, summary, content, distill_score, source_record_ids) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`).run(
          ownerType, ownerId, rec.band_id, rec.channel_id, rec.frequency_id, freqName + '·' + rec.record_type, detail, detail, S, JSON.stringify([rec.id])
        );
        archivesOut++;
      }
    }
    // 冷启动保底（2026-10-31）：θ=0.618 是按「记录多、类型杂」设计的门槛。
    // 真实场景里新用户只有三五条同类记录，U 会被压到 1/N，S 永远够不到 θ ——
    // 于是「第一次用」永远没有任何档案，闭环在起点就断。
    // 保底规则：本次一条都没蒸馏出来、且确实有记录时，取分数最高的那一条建一份档案，
    // 并打 coldStart 标记（可查询、可解释、不修改 θ 口径）。
    if (archivesOut === 0 && bestRec) {
      const freqName0 = (FREQUENCIES.find(f => f.code === bestRec.frequency_id) || {}).name || bestRec.frequency_id;
      let m0 = {};
      try { m0 = JSON.parse(bestRec.meta || '{}'); } catch (e) {}
      const detail0 = String(m0.detail || m0.title || bestRec.content_ref || bestRec.record_type || '');
      db.prepare(`INSERT INTO archive_archives (owner_type, owner_id, band_id, channel_id, frequency_id, title, summary, content, tags, distill_score, source_record_ids) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
        .run(ownerType, ownerId, bestRec.band_id, bestRec.channel_id, bestRec.frequency_id,
          freqName0 + '·' + bestRec.record_type,
          detail0, detail0, JSON.stringify(['cold-start']), bestS, JSON.stringify([bestRec.id]));
      archivesOut = 1;
      coldStart = true;
    }
    db.exec('COMMIT');
  } catch (e) { db.exec('ROLLBACK'); throw e; }
  const recordsIn = records.length;
  const rho = recordsIn ? archivesOut / recordsIn : 0;
  db.prepare(`INSERT INTO archive_distill_logs (owner_type, owner_id, rule_id, records_in, archives_out, rho, started_at, finished_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`).run(ownerType, ownerId, rule.id, recordsIn, archivesOut, rho, startedAt, new Date().toISOString());
  return { recordsIn, archivesOut, rho, coldStart };
}
function frequencySummary(ownerType, ownerId) {
  return FREQUENCIES.map(function(fr) {
    const rec = db.prepare(`SELECT COUNT(*) c FROM archive_records WHERE owner_type = ? AND owner_id = ? AND frequency_id = ?`).get(ownerType, ownerId, fr.code);
    const arc = db.prepare(`SELECT COUNT(*) c FROM archive_archives WHERE owner_type = ? AND owner_id = ? AND frequency_id = ?`).get(ownerType, ownerId, fr.code);
    return { code: fr.code, name: fr.name, channels: fr.channels, records: rec.c, archives: arc.c };
  });
}
function getDistillStats(ownerType, ownerId) {
  const records = countByOwner('archive_records', ownerType, ownerId);
  const archives = countByOwner('archive_archives', ownerType, ownerId);
  const rho = records ? archives / records : 0;
  return { recordsCount: records, archivesCount: archives, rho };
}

// ===== 设备层（三角色）=====
function registerDevice(o) {
  const existing = db.prepare(`SELECT id, owner_id FROM archive_devices WHERE device_id = ?`).get(o.deviceId);
  if (existing && existing.owner_id !== o.ownerId) return { ok: false, code: 409, conflict: true, message: '设备已归属他人' };
  db.prepare(`INSERT INTO archive_devices (owner_type, owner_id, device_id, device_name, device_type, schema_version, agent_version) VALUES (?, ?, ?, ?, ?, ?, ?) ON CONFLICT(device_id) DO UPDATE SET device_name=excluded.device_name, device_type=excluded.device_type, schema_version=excluded.schema_version, agent_version=excluded.agent_version`).run(o.ownerType, o.ownerId, o.deviceId, o.deviceName || '', o.deviceType, o.schemaVersion || '1.0', o.agentVersion || '0.1.0');
  const d = db.prepare(`SELECT id FROM archive_devices WHERE device_id = ?`).get(o.deviceId);
  return { ok: true, id: d.id };
}
function getDevices(ownerType, ownerId) { return db.prepare(`SELECT * FROM archive_devices WHERE owner_type = ? AND owner_id = ?`).all(ownerType, ownerId); }
function getDevice(deviceId) {
  const device = db.prepare(`SELECT * FROM archive_devices WHERE device_id = ?`).get(deviceId);
  if (!device) return null;
  const roles = db.prepare(`SELECT role, created_at FROM archive_device_roles WHERE device_id = ? ORDER BY id`).all(deviceId);
  const linksOut = db.prepare(`SELECT to_device, link_type, created_at FROM archive_device_links WHERE from_device = ? ORDER BY id`).all(deviceId);
  const linksIn = db.prepare(`SELECT from_device, link_type, created_at FROM archive_device_links WHERE to_device = ? ORDER BY id`).all(deviceId);
  const endpoints = db.prepare(`SELECT path, method, created_at FROM archive_endpoints WHERE device_id = ? ORDER BY id`).all(deviceId);
  return { device, roles, linksOut, linksIn, endpoints };
}
function setDeviceRole(deviceId, role) { db.prepare(`INSERT OR IGNORE INTO archive_device_roles (device_id, role) VALUES (?, ?)`).run(deviceId, role); return { ok: true }; }
function linkDevice(fromDevice, toDevice, linkType) { db.prepare(`INSERT OR IGNORE INTO archive_device_links (from_device, to_device, link_type) VALUES (?, ?, ?)`).run(fromDevice, toDevice, linkType || 'sync'); return { ok: true }; }
function heartbeat(deviceId) { db.prepare(`UPDATE archive_devices SET last_heartbeat = datetime('now','localtime') WHERE device_id = ?`).run(deviceId); return { ok: true }; }

// ===== 智能体层 ===== 
function getAgents(ownerType, ownerId) { return db.prepare(`SELECT * FROM archive_agents WHERE owner_type = ? AND owner_id = ?`).all(ownerType, ownerId); }
function getAgent(id) {
  const agent = db.prepare(`SELECT * FROM archive_agents WHERE id = ?`).get(id);
  if (!agent) return null;
  return { agent, skills: getSkills(id), matrix: getMatrix(agent.owner_type, agent.owner_id) };
}
function createAgent(ownerType, ownerId, o) {
  const result = db.prepare(`INSERT INTO archive_agents (owner_type, owner_id, agent_name, agent_version) VALUES (?, ?, ?, ?)`).run(ownerType, ownerId, o.agentName || '', o.agentVersion || '0.1.0');
  const id = Number(result.lastInsertRowid);
  assignDefaultSkills(id);      // 新智能体自动获得默认技能
  ensureMatrix(ownerType, ownerId); // 并纳入协同矩阵
  return { id };
}
function getMatrix(ownerType, ownerId) { return db.prepare(`SELECT * FROM archive_agent_matrix WHERE owner_type = ? AND owner_id = ?`).get(ownerType, ownerId) || null; }
function getSkills(agentId) { return db.prepare(`SELECT * FROM archive_skills WHERE agent_id = ?`).all(agentId); }
function getDefaultSkills() { return DEFAULT_SKILLS; }

// 给单个智能体补齐默认技能（幂等）
function assignDefaultSkills(agentId) {
  let added = 0;
  for (const s of DEFAULT_SKILLS) {
    const r = idempotentInsert('archive_skills',
      ['agent_id', 'skill_name'], [agentId, s.name],
      ['agent_id', 'skill_name', 'skill_meta'], [agentId, s.name, JSON.stringify(s.meta)]);
    if (r.created) added++;
  }
  return added;
}
// 确保某个所有者存在协同矩阵（幂等）
function ensureMatrix(ownerType, ownerId) {
  return idempotentInsert('archive_agent_matrix',
    ['owner_type', 'owner_id'], [ownerType, ownerId],
    ['owner_type', 'owner_id', 'matrix_meta'], [ownerType, ownerId, JSON.stringify(DEFAULT_MATRIX)]).id;
}
// 给某个所有者的全部智能体补齐技能 + 矩阵
function ensureAgentCapabilities(ownerType, ownerId) {
  const matrixId = ensureMatrix(ownerType, ownerId);
  const agents = db.prepare(`SELECT id FROM archive_agents WHERE owner_type = ? AND owner_id = ?`).all(ownerType, ownerId);
  let skillsAdded = 0;
  for (const a of agents) skillsAdded += assignDefaultSkills(a.id);
  return { agents: agents.length, matrix_id: matrixId, skills_added: skillsAdded };
}
// 给全库所有智能体补齐技能 + 矩阵
function ensureAllAgentCapabilities() {
  const owners = db.prepare(`SELECT DISTINCT owner_type, owner_id FROM archive_agents`).all();
  let agents = 0, skillsAdded = 0;
  for (const o of owners) { const r = ensureAgentCapabilities(o.owner_type, o.owner_id); agents += r.agents; skillsAdded += r.skills_added; }
  return { owners: owners.length, agents, skills_added: skillsAdded };
}

// 调用智能体执行动作（真实派发到档案引擎各能力）
function invokeAgent(agentId, action, payload = {}) {
  const agent = db.prepare(`SELECT * FROM archive_agents WHERE id = ?`).get(agentId);
  if (!agent) return { ok: false, error: '智能体不存在', agentId, action };
  const ot = agent.owner_type, oid = agent.owner_id;
  switch (action) {
    case 'records':  return Object.assign({ ok: true, agentId, action }, getRecords({ ownerType: ot, ownerId: oid, limit: payload.limit || 50, offset: payload.offset || 0 }));
    case 'archives': return Object.assign({ ok: true, agentId, action }, getArchives({ ownerType: ot, ownerId: oid, limit: payload.limit || 50, offset: payload.offset || 0 }));
    case 'distill':  return Object.assign({ ok: true, agentId, action }, runDistill(ot, oid, payload.ruleId));
    case 'search':   return Object.assign({ ok: true, agentId, action }, searchArchives(ot, oid, payload.keyword, payload.limit || 50));
    case 'gates':    return Object.assign({ ok: true, agentId, action }, checkGates(ot, oid));
    case 'status':   return { ok: true, agentId, action, agent, skills: getSkills(agentId), matrix: getMatrix(ot, oid) };
    default:         return { ok: false, error: '未知动作：' + action, agentId };
  }
}

// ===== 主体层（五重门主体映射：person/institution/legal/system/for_self）=====
// 确保用户存在个人主体（幂等），建立 person.owner_id === user_id 不变式
function ensurePersonPrincipal(userId, name) {
  const ex = db.prepare(`SELECT * FROM archive_principals WHERE principal_type = 'person' AND user_id = ?`).get(userId);
  if (ex) return ex;
  const u = db.prepare(`SELECT nickname FROM users WHERE id = ?`).get(userId);
  const nick = name || (u && u.nickname) || ('用户' + userId);
  // ON CONFLICT 兜底：并发/重入时幂等，不抛唯一约束错误
  db.prepare(`INSERT INTO archive_principals (principal_type, user_id, name, status) VALUES ('person', ?, ?, 'active') ON CONFLICT(principal_type, user_id) DO NOTHING`).run(userId, nick);
  return db.prepare(`SELECT * FROM archive_principals WHERE principal_type = 'person' AND user_id = ?`).get(userId);
}
// 证件号脱敏：列表接口不返回完整证件号（PII 保护）
function maskIdNo(idNo) {
  if (!idNo) return '';
  if (idNo.length <= 4) return '****';
  return idNo.slice(0, 3) + '****' + idNo.slice(-2);
}
// 列出主体（可按类型过滤；id_no 脱敏）
function getPrincipals(principalType) {
  const rows = principalType ? db.prepare(`SELECT * FROM archive_principals WHERE principal_type = ? ORDER BY id`).all(principalType) : db.prepare(`SELECT * FROM archive_principals ORDER BY id`).all();
  return rows.map(function(p) { return Object.assign({}, p, { id_no: maskIdNo(p.id_no) }); });
}
// 按用户取个人主体
function getPrincipalByUser(userId) {
  return db.prepare(`SELECT * FROM archive_principals WHERE principal_type = 'person' AND user_id = ?`).get(userId) || null;
}

module.exports = {
  getCatalogTree, getSpectra, getBands, getChannels, getFrequencies,
  getDeviceRoles, getShadow, getShadowSummary,
  getGrants, createGrant, revokeGrant, checkGates,
  createRecord, createRecordsBatch, getRecords, getRecord, deleteRecord,
  getArchives, getArchive, updateArchive, licenseArchive, deleteArchive, searchArchives, getLicenses, revokeLicense,
  getFilings, fileArchive, unfileArchive, getArchivesByFrequency,
  runDistill, getDistillRules, updateDistillRules, getDistillStats, frequencySummary,
  registerDevice, getDevices, getDevice, setDeviceRole, linkDevice, heartbeat,
  getAgents, getAgent, createAgent, getMatrix, getSkills, getDefaultSkills, invokeAgent,
  assignDefaultSkills, ensureMatrix, ensureAgentCapabilities, ensureAllAgentCapabilities,
  ensurePersonPrincipal, getPrincipals, getPrincipalByUser,
};
