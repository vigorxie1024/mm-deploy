'use strict';
// AI 读者（ai-reader）——让大模型自动阅读站内章节，并把读到的结果写回群里
//
// 为什么需要它：VX 问「大模型能不能自动去访问、阅读、参与」。答案是：
//   模型本身不能自己上网——它没有执行体。必须有一个常驻程序（这个模块）去取内容、调模型、写回结果。
//   这就是「AI 员工」模式：模型负责读和想，程序负责跑和记。
//
// 边界（写死）：
//   1. 只读站内章节，不出站抓取；
//   2. 每读一章都记录 token 估算与模型名，便于审计；
//   3. 没有模型 Key 时**不假装读过**，明确标 model='none' 并说明。
function ensureSchema(db) {
  db.exec(`CREATE TABLE IF NOT EXISTS cell_readings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    slug TEXT NOT NULL,
    title TEXT NOT NULL DEFAULT '',
    summary TEXT NOT NULL DEFAULT '',
    questions TEXT NOT NULL DEFAULT '[]',
    excerpt_chars INTEGER NOT NULL DEFAULT 0,
    model TEXT NOT NULL DEFAULT '',
    source TEXT NOT NULL DEFAULT 'model',
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
  );`);
}

function listReadings(db, limit) {
  ensureSchema(db);
  return db.prepare('SELECT * FROM cell_readings ORDER BY id DESC LIMIT ?').all(limit || 20)
    .map(r => Object.assign({}, r, { questions: safeJson(r.questions) }));
}
function safeJson(s) { try { return JSON.parse(s); } catch (e) { return []; } }

// 把章节 HTML 压成适合喂模型的纯文本（保留句子边界）
function plainText(html, maxChars) {
  const t = String(html || '').replace(/<script[\s\S]*?<\/script>/gi, ' ').replace(/<style[\s\S]*?<\/style>/gi, ' ')
    .replace(/<[^>]+>/g, ' ').replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>')
    .replace(/\s+/g, ' ').trim();
  return t.slice(0, maxChars || 6000);
}

async function runOnce(opts) {
  const { db, bookEngine, askModel, slug, emit } = opts;
  ensureSchema(db);
  if (!slug) return { ok: false, code: 'E4002', error: '缺少章节 slug' };
  let book = null;
  try { book = bookEngine.loadBook(slug); } catch (e) { book = null; }
  if (!book || !book.html) return { ok: false, code: 'E4002', error: '章节不存在或无法读取：' + slug };

  const text = plainText(book.html, 6000);
  const title = book.title || slug;
  const sys = '你是站内阅读员。只依据给定正文作答，用中文输出严格 JSON：{"summary":"不超过120字的摘要","questions":["针对本章的3个尖锐问题"],"channels":["这章内容适合挂到哪些档案频道，如 fr-health/fr-finance/fr-media/fr-hobby/fr-other 之一或多个"]}。不要输出解释。';
  let out = null, model = 'none', source = 'none';
  try {
    const reply = await askModel([{ role: 'system', content: sys }, { role: 'user', content: '章节：' + title + '\n\n正文节选：\n' + text }], 600);
    if (reply) {
      const m = reply.match(/\{[\s\S]*\}/);
      if (m) { out = JSON.parse(m[0]); model = (opts.modelName || 'unknown'); source = 'model'; }
    }
  } catch (e) { out = null; }
  if (!out) {
    // 没接模型：不假装读过，只做结构化占位（明确标 source=none）
    out = { summary: '（未接入模型，本次未产生真实阅读结论）章节共 ' + text.length + ' 字', questions: [], channels: [] };
    source = 'none';
  }
  const ins = db.prepare('INSERT INTO cell_readings (slug, title, summary, questions, excerpt_chars, model, source) VALUES (?,?,?,?,?,?,?)')
    .run(slug, title, String(out.summary || ''), JSON.stringify(out.questions || []), text.length, model, source);
  const rec = db.prepare('SELECT * FROM cell_readings WHERE id = ?').get(Number(ins.lastInsertRowid));
  if (typeof emit === 'function') {
    emit('chat.agent', {
      text: '📖 我读完了《' + title + '》：' + String(out.summary || '').slice(0, 120),
      kind: 'llm', member_id: 'reader', reading_id: rec.id, source,
    }, { from: 'reader' });
  }
  return { ok: true, reading: Object.assign({}, rec, { questions: out.questions || [], channels: out.channels || [] }) };
}

module.exports = { ensureSchema, listReadings, runOnce, plainText };
