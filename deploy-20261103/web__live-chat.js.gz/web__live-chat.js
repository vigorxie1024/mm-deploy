// live-chat.js —— 任何页面的「找 asus」按钮：贴问题 → asus 秒级看到 → 回复回到页面
// 为什么每个页面都要有：VX 说的「提高开发迭代效率」= 在哪发现问题就在哪报，不用切工具、不用描述在哪个页面。
// 内测期不鉴权（谁都能发），限频 30 条/分钟/IP；内容不进任何第三方。
(function () {
  if (window.__liveChat) return;
  window.__liveChat = true;
  if (typeof document === 'undefined') return;

  var since = 0, open = false, started = false;

  var CSS = '' +
    '#lc-btn{position:fixed;right:16px;bottom:16px;z-index:9998;padding:10px 14px;border-radius:22px;background:#2d6a4f;color:#fff;font:600 13px/1 -apple-system,"Segoe UI",sans-serif;border:0;cursor:pointer;box-shadow:0 6px 22px rgba(0,0,0,.35)}' +
    '#lc-btn:active{transform:scale(.97)}' +
    '#lc-panel{position:fixed;right:16px;bottom:64px;z-index:9999;width:min(360px,92vw);max-height:min(480px,70vh);display:none;flex-direction:column;background:#14161a;color:#e6e8eb;border:1px solid #2a2f36;border-radius:14px;overflow:hidden;box-shadow:0 12px 40px rgba(0,0,0,.5);font:14px/1.6 -apple-system,"Segoe UI",sans-serif}' +
    '#lc-panel.on{display:flex}' +
    '#lc-head{display:flex;align-items:center;gap:8px;padding:10px 12px;background:#1c1f24;border-bottom:1px solid #2a2f36;font-size:13px}' +
    '#lc-head b{color:#7fd1ae}#lc-head span{color:#8b949e;margin-left:auto;font-size:11.5px}' +
    '#lc-log{flex:1;overflow-y:auto;padding:10px 12px;min-height:120px}' +
    '.lc-m{margin:6px 0;font-size:13px;white-space:pre-wrap;word-break:break-word}' +
    '.lc-m b{color:#7fd1ae}.lc-m.me b{color:#ffd98a}' +
    '.lc-t{color:#5c6670;font-size:11px;margin-left:6px}' +
    '#lc-foot{display:flex;gap:6px;padding:9px 10px;background:#1c1f24;border-top:1px solid #2a2f36}' +
    '#lc-in{flex:1;padding:9px;background:#0b0d10;border:1px solid #2a2f36;color:#e6e8eb;border-radius:8px;font-size:13px;font-family:inherit}' +
    '#lc-send{padding:9px 13px;background:#2d6a4f;color:#fff;border:0;border-radius:8px;font-weight:600;cursor:pointer;font-size:13px}' +
    '@media(max-width:520px){#lc-panel{right:8px;left:8px;width:auto;bottom:58px}}';

  function inject() {
    var s = document.createElement('style'); s.textContent = CSS; document.head.appendChild(s);
    var btn = document.createElement('button'); btn.id = 'lc-btn'; btn.type = 'button';
    btn.textContent = '找 asus';
    var panel = document.createElement('div'); panel.id = 'lc-panel';
    panel.innerHTML = '<div id="lc-head"><b>找 asus（子智能体代传）</b><span id="lc-st">未连接</span></div>' +
      '<div id="lc-log"><div class="lc-m" style="color:#8b949e;font-size:12px">这个窗口只做一件事：把你在这一页遇到的问题直接送到 asus 那里。站内答疑是右下角的 AI 助手，两个不一样。</div></div>' +
      '<div id="lc-foot"><input id="lc-in" placeholder="哪一步卡住了？说一句就行"><button id="lc-send" type="button">发</button></div>';
    document.body.appendChild(btn); document.body.appendChild(panel);

    btn.onclick = function () {
      open = !open;
      panel.classList.toggle('on', open);
      if (open && !started) { started = true; poll(); }
      if (open) document.getElementById('lc-in').focus();
    };
    document.getElementById('lc-send').onclick = send;
    document.getElementById('lc-in').addEventListener('keydown', function (e) { if (e.key === 'Enter') send(); });
  }

  function line(m) {
    var log = document.getElementById('lc-log');
    if (!log) return;
    var d = document.createElement('div');
    d.className = 'lc-m' + (m.from_who === 'asus' ? '' : ' me');
    var who = document.createElement('b');
    who.textContent = (m.from_who === 'asus' ? 'asus' : '你') + ' ';
    var t = document.createElement('span'); t.className = 'lc-t'; t.textContent = String(m.created_at || '').slice(11, 16);
    var body = document.createElement('span'); body.textContent = m.text;
    d.appendChild(who); d.appendChild(t); d.appendChild(document.createElement('br')); d.appendChild(body);
    log.appendChild(d);
    log.scrollTop = log.scrollHeight;
  }

  function poll() {
    fetch('/api/live/thread?since=' + since, { cache: 'no-store' })
      .then(function (r) { return r.json(); })
      .then(function (j) {
        if (!j || !j.messages) return;
        j.messages.forEach(function (m) { since = Math.max(since, m.id); line(m); });
        var st = document.getElementById('lc-st');
        if (st) st.textContent = '在线 · ' + (j.total || 0) + ' 条';
      })
      .catch(function () { var st = document.getElementById('lc-st'); if (st) st.textContent = '断线重试'; })
      .then(function () { setTimeout(poll, 3000); });
  }

  function send() {
    var el = document.getElementById('lc-in');
    var v = (el && el.value || '').trim();
    if (!v) return;
    el.value = '';
    // 子智能体先给回执：用户立刻知道"有人接了"，不用猜有没有发出去
    var log = document.getElementById('lc-log');
    if (log) {
      var ack = document.createElement('div');
      ack.className = 'lc-m';
      ack.innerHTML = '<b>子智能体 </b><span class="lc-t">刚刚</span><br><span>收到，已转给 asus。他那边会实时看到这条，有回复我立刻带回这里。</span>';
      log.appendChild(ack); log.scrollTop = log.scrollHeight;
    }
    fetch('/api/live/send', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text: v, page: location.pathname + location.search, from: 'user' })
    }).then(function () { setTimeout(poll, 600); }).catch(function () {});
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', inject);
  else inject();
})();
