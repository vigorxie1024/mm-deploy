'use strict';
// moonarmor.cn 后端服务：零依赖 Node (node:http + node:sqlite)
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const https = require('node:https');
const { db, initSchema, migrate } = require('./db');
const indexEngine = require('./index-engine');
const matchEngine = require('./match-engine');
const contractEngine = require('./contract-engine');
const creditEngine = require('./credit-engine');
const sseEngine = require('./sse-engine');
const aiReview = require('./ai-review');
const searchEngine = require('./search-engine');
const bookEngine = require('./book-engine');
const bookView = require('./book-view');
const downloadEngine = require('./download-engine');
const docxEngine = require('./docx-engine');
const { hashPassword, verifyPassword, createSession, getUserByToken, destroySession, publicUser } = require('./auth');
const pay = require('./pay');
const td = require('./tencent-docs');
const ao = require('./alipay-oauth');
const wx = require('./wechat');
const wxpay = require('./wechat-pay');

const archiveEngine = require('./archive-engine');
const { seedArchiveCatalog } = require('./seed-archive');
const auditAgent = require('./audit-agent');
const exEngine = require('./exchange-engine');
const exReviewEngine = require('./ex-review-engine'); // 口碑飞轮（#18 任务2）
const cs = require('./code-system');
const renoKB = require('./renovation-kb');
// [SHARED][deco2] 成都装修智能体集群（行业样板：PIRA 模式复制）—— asus 设计，总工手工合并（PR #22 基底过旧，按锚点图并入）
const decoEngine = require('./deco-engine');
const { seedDeco } = require('./seed-deco');
const { ensureWorkerTables, seedWorkerDemo } = require('./seed-deco2');
const decoMatch = require('./deco-match-engine');
const decoGeo = require('./deco-geo');
const decoRanking = require('./deco-ranking-engine');
const decoContract = require('./deco-contract-engine');
const decoSafety = require('./deco-safety-engine');
const decoKB = require('./deco-kb-engine');
const decoLead = require('./deco-lead-engine');
// 报价单智能审查（V0.1681 专题一·功能7）
const decoQuote = require('./deco-quote-engine');
// 装修飞车 V0（#48）：无登录 5 站试乘动线（演示数据，不接真实支付）
const decoFlycar = require('./deco-flycar-engine');
// 档案产品频道·需求建议智能体（多碳基人协同开发；asus feature/feedback 总工手工合并 PR#28，防25条路由回退）
const feedbackEngine = require('./feedback-engine');
const archiveExport = require('./archive-export');
const WEB_ROOT = path.join(__dirname, '..', 'web');
const PORT = Number(process.env.PORT || 8000);
const RATIO = 0.618; // 买方分红池比例

initSchema();
migrate();
seedArchiveCatalog();
// [deco2] 集群表结构与种子（幂等）
decoEngine.ensureDecoTables();
seedDeco();
ensureWorkerTables();
seedWorkerDemo();
decoMatch.ensureMatchTables();
decoRanking.ensureRankingTables();
decoRanking.seedRatingDemo();
decoContract.ensureContractTables();
decoSafety.ensureSafetyTables();
decoKB.ensureKBTables();
decoKB.seedKB();
decoLead.ensureLeadTables();
feedbackEngine.ensureFeedbackTables();
// [deco-flycar] 试乘动线表结构 + 演示种子（幂等）
decoFlycar.ensureFlycarTables();
decoFlycar.seedCandidates();

// ---------- 工具 ----------
function json(res, code, data, extraHeaders) { const h = { 'Content-Type': 'application/json; charset=utf-8' }; if (extraHeaders) Object.assign(h, extraHeaders); res.writeHead(code, h); res.end(JSON.stringify(data)); }
function readBody(req, limit) {
  return new Promise((resolve, reject) => {
    let size = 0; const chunks = [];
    req.on('data', c => { size += c.length; if (size > (limit || 5e6)) { reject(new Error('body too large')); req.destroy(); } chunks.push(c); });
    req.on('end', () => { try { resolve(JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}')); } catch (e) { reject(new Error('invalid json')); } });
    req.on('error', reject);
  });
}
function getSetting(key, def) { const r = db.prepare('SELECT value FROM settings WHERE key = ?').get(key); return r ? JSON.parse(r.value) : def; }
function setSetting(key, val) { db.prepare('INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=datetime(\'now\',\'localtime\')').run(key, JSON.stringify(val)); }

// ---------- 敏感凭据脱敏：明文只留服务器，接口一律不下发 ----------
const SECRET_KEY_RE = /^(privateKey|secret|appSecret|token|apiKey|apiKeys|password|mchKey)$/i;
const SECRET_SET = '__SET__';      // 已配置占位符（原值不下发浏览器）
const SECRET_CLEAR = '__CLEAR__';  // 显式清除指令（仅后台「清除」按钮发送）
function isEmptySecret(v) { return v === '' || v === SECRET_SET || (Array.isArray(v) && (v.length === 0 || v.every(x => x === SECRET_SET))); }
function isClearSecret(v) { return v === SECRET_CLEAR || (Array.isArray(v) && v.length > 0 && v.every(x => x === SECRET_CLEAR)); }
function maskSecrets(v) {
  if (Array.isArray(v)) return v.map(maskSecrets);
  if (v && typeof v === 'object') {
    const out = {};
    for (const [k, val] of Object.entries(v)) {
      if (SECRET_KEY_RE.test(k)) out[k] = Array.isArray(val) ? (val.length ? [SECRET_SET] : []) : (val ? SECRET_SET : '');
      else out[k] = maskSecrets(val);
    }
    return out;
  }
  return v;
}
// 写回时合并：占位符/空值 → 保留已存原值；__CLEAR__ → 清空；其余按新值写入
function mergeSecrets(incoming, existing) {
  if (Array.isArray(incoming) || !incoming || typeof incoming !== 'object') return incoming;
  const out = {};
  for (const [k, val] of Object.entries(incoming)) {
    const cur = (existing && typeof existing === 'object' && !Array.isArray(existing)) ? existing[k] : undefined;
    if (SECRET_KEY_RE.test(k)) {
      if (isClearSecret(val)) { out[k] = Array.isArray(val) ? [] : ''; continue; }
      if (isEmptySecret(val)) { out[k] = cur !== undefined ? cur : (Array.isArray(val) ? [] : ''); continue; }
      out[k] = val; continue;
    }
    out[k] = (val && typeof val === 'object') ? mergeSecrets(val, cur) : val;
  }
  return out;
}
function slugify(s) { return String(s).trim().replace(/\s+/g, '-').replace(/[^\w\u4e00-\u9fa5-]/g, '').slice(0, 80) || 'item-' + Date.now(); }
function orderNo(prefix) { return prefix + Date.now() + Math.floor(Math.random() * 900 + 100); }
function now() { return new Date().toISOString(); }

// ---------- 文章查询 ----------
let REQ_LANG = 'zh'; // 由主分发器按请求 X-Lang 头设置
function articleRow(a, full) {
  const en = REQ_LANG === 'en';
  const base = {
    id: a.id, title: (en && a.title_en) ? a.title_en : a.title, slug: a.slug, summary: (en && a.summary_en) ? a.summary_en : a.summary, author_name: a.author_name,
    cat1_id: a.cat1_id, cat2_id: a.cat2_id, cat3_id: a.cat3_id,
    granularity: a.granularity, app_areas: JSON.parse(a.app_areas || '[]'), tags: JSON.parse(a.tags || '[]'),
    status: a.status, is_paid: a.is_paid, price: a.price,
    view_count: a.view_count, comment_count: a.comment_count, like_count: a.like_count,
    rating_avg: a.rating_count ? Math.round((a.rating_sum / a.rating_count) * 10) / 10 : 0, rating_count: a.rating_count,
    schedule_at: a.schedule_at,
    source_doc: a.source_doc, version: a.version, published_at: a.published_at, created_at: a.created_at, updated_at: a.updated_at
  };
  if (full) base.content = a.content;
  return base;
}

// ---------- 认证中间件 ----------
function authUser(req) {
  const h = req.headers['authorization'] || '';
  let token = h.startsWith('Bearer ') ? h.slice(7) : null;
  if (!token) {
    const cookie = req.headers['cookie'] || '';
    const m = cookie.match(/(?:^|;\s*)ma_token=([^;]+)/);
    if (m) token = m[1];
  }
  return getUserByToken(token);
}

// ---------- 超级管理员（仅 VX 可改全站文案/文档）----------
const SUPER_ADMIN_PHONES = new Set(['13901230861', '18611475369']);
function isSuperAdmin(u) {
  if (!u) return false;
  if (u.role === 'superadmin') return true;
  return SUPER_ADMIN_PHONES.has(String(u.phone || ''));
}

// 档案 owner 推导：登录态优先，生产强制登录，本地演示放行 ownerId=1（P0 修复：不信任客户端 ownerId）
function deriveArchiveOwner(req) {
  const user = authUser(req);
  if (user) { archiveEngine.ensurePersonPrincipal(user.id, user.nickname); return { ownerType: 'person', ownerId: user.id }; }
  // P0-1 修复：默认 fail-closed，无登录态一律拒绝，杜绝线上匿名回退到 ownerId=1。
  // 仅显式开启演示模式（ALLOW_ANON_ARCHIVE=1 且非 production）才放行匿名演示主体。
  if (process.env.ALLOW_ANON_ARCHIVE === '1' && process.env.NODE_ENV !== 'production') {
    try { const u = db.prepare('SELECT id, nickname FROM users WHERE id = 1').get(); if (u) archiveEngine.ensurePersonPrincipal(u.id, u.nickname); } catch (e) {}
    return { ownerType: 'person', ownerId: 1 };
  }
  return null;
}
// ---------- 支付（模拟/支付宝） ----------
function payOrder(orderNo) {
  const o = db.prepare('SELECT * FROM orders WHERE order_no = ?').get(orderNo);
  if (!o || o.status === 'paid') return o;
  db.prepare('UPDATE orders SET status = \'paid\', paid_at = datetime(\'now\',\'localtime\') WHERE order_no = ?').run(orderNo);
  // 分红池入账
  db.prepare('INSERT INTO dividend_ledger (entry_type, ref_id, amount, ratio, pool_amount, note) VALUES (?, ?, ?, ?, ?, ?)')
    .run('order', o.id, o.amount, RATIO, Math.round(o.amount * RATIO * 100) / 100, '订单 ' + orderNo);
  return db.prepare('SELECT * FROM orders WHERE order_no = ?').get(orderNo);
}
function payTip(orderNo) {
  const t = db.prepare('SELECT * FROM tips WHERE order_no = ?').get(orderNo);
  if (!t || t.status === 'paid') return t;
  db.prepare('UPDATE tips SET status = \'paid\', paid_at = datetime(\'now\',\'localtime\') WHERE order_no = ?').run(orderNo);
  db.prepare('INSERT INTO dividend_ledger (entry_type, ref_id, amount, ratio, pool_amount, note) VALUES (?, ?, ?, ?, ?, ?)')
    .run('tip', t.id, t.amount, RATIO, Math.round(t.amount * RATIO * 100) / 100, '打赏 ' + orderNo);
  return db.prepare('SELECT * FROM tips WHERE order_no = ?').get(orderNo);
}

// ---------- 智能体派生（真实/模拟） ----------
function runAgentTask(taskId) {
  const t = db.prepare('SELECT * FROM agent_tasks WHERE id = ?').get(taskId);
  if (!t) return;
  db.prepare('UPDATE agent_tasks SET status = \'running\' WHERE id = ?').run(taskId);
  const provider = getSetting('ai_providers', {});
  const cfg = provider[t.provider] || {};
  const keys = Array.isArray(cfg.apiKeys) ? cfg.apiKeys : (cfg.apiKey ? [cfg.apiKey] : []);
  const key = keys.length ? keys[t.id % keys.length] : '';
  try {
    let output = '';
    if (key && cfg.baseUrl) {
      // 真实调用 OpenAI 兼容接口
      const body = JSON.stringify({
        model: cfg.model || 'deepseek-chat',
        messages: [
          { role: 'system', content: '你是月亮盔甲理论平台的AI派生智能体。请根据给定的原文，生成符合要求的派生内容，语言为中文。' },
          { role: 'user', content: t.params }
        ],
        max_tokens: 2000
      });
      const httpMod = cfg.baseUrl.indexOf('https://') === 0 ? https : http;
      const req = httpMod.request(cfg.baseUrl.replace(/\/$/, ''), {
        method: 'POST', timeout: 60000,
        headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + key, 'Content-Length': Buffer.byteLength(body) }
      }, res => { let d = ''; res.on('data', c => d += c); res.on('end', () => { try { const j = JSON.parse(d); output = j.choices && j.choices[0] ? j.choices[0].message.content : '[AI返回空]'; db.prepare('UPDATE agent_tasks SET status = \'draft\', output = ?, finished_at = datetime(\'now\',\'localtime\') WHERE id = ?').run(output, taskId); } catch (e) { db.prepare('UPDATE agent_tasks SET status = \'failed\', error = ?, finished_at = datetime(\'now\',\'localtime\') WHERE id = ?').run(String(e), taskId); } }); });
      req.on('timeout', () => req.destroy(new Error('timeout')));
      req.on('error', e => { db.prepare('UPDATE agent_tasks SET status = \'failed\', error = ?, finished_at = datetime(\'now\',\'localtime\') WHERE id = ?').run(String(e.message || e), taskId); });
      req.end(body);
    } else {
      // 模拟模式：生成占位派生内容
      const kinds = { article: '图文文章', image: '配图描述', video: '短视频脚本', drama: '短剧分镜脚本' };
      const a = t.article_id ? db.prepare('SELECT title FROM articles WHERE id = ?').get(t.article_id) : null;
      output = '[模拟生成·' + (kinds[t.task_type] || t.task_type) + '] 基于《' + (a ? a.title : '理论专题') + '》的派生内容示例。\n\n——本内容由模拟模式生成，配置AI Key（后台-系统设置-智能体）后自动切换为真实生成。';
      setTimeout(() => db.prepare('UPDATE agent_tasks SET status = \'draft\', output = ?, finished_at = datetime(\'now\',\'localtime\') WHERE id = ?').run(output, taskId), 300);
    }
  } catch (e) {
    db.prepare('UPDATE agent_tasks SET status = \'failed\', error = ?, finished_at = datetime(\'now\',\'localtime\') WHERE id = ?').run(String(e.message || e), taskId);
  }
}

// ---------- 分发（真实/模拟） ----------
function runDistribution(logId) {
  const lg = db.prepare('SELECT * FROM distribution_logs WHERE id = ?').get(logId);
  if (!lg) return;
  const platforms = getSetting('platform_credentials', {});
  const cred = platforms[lg.platform] || null;
  if (lg.platform === 'wechat' && cred && cred.enabled && cred.appid && cred.secret) {
    // 微信公众号真实发布：token → 封面 → 草稿 → 发布
    const a = db.prepare('SELECT * FROM articles WHERE id = ?').get(lg.article_id);
    wx.publishArticle(a).then(r => {
      db.prepare('UPDATE distribution_logs SET status = \'published\', url = ?, published_at = datetime(\'now\',\'localtime\') WHERE id = ?').run('https://mp.weixin.qq.com/s?publish_id=' + (r.publish_id || ''), logId);
      console.log('[wechat] published article', lg.article_id, 'publish_id', r.publish_id);
    }).catch(e => {
      db.prepare('UPDATE distribution_logs SET status = \'failed\', error = ? WHERE id = ?').run(String(e.message || e), logId);
      console.log('[wechat] publish failed', lg.article_id, String(e.message || e));
    });
    return;
  } else if (cred && cred.enabled && cred.apiKey) {
    // 其他平台：凭据就绪后按平台实现
    db.prepare('UPDATE distribution_logs SET status = \'failed\', error = ? WHERE id = ?').run('平台API适配待凭据核验', logId);
  } else {
    // 模拟分发
    setTimeout(() => db.prepare('UPDATE distribution_logs SET status = \'mock\', url = ?, published_at = datetime(\'now\',\'localtime\') WHERE id = ?').run('https://mock.moonarmor.cn/dist/' + lg.id, logId), 200);
  }
}

// ---------- GitHub 同步（发布后归档到仓库） ----------
function syncGitHub(article) {
  const gh = getSetting('github', null);
  if (!gh || !gh.token || !gh.owner || !gh.repo) return;
  const apiPath = '/repos/' + encodeURIComponent(gh.owner) + '/' + encodeURIComponent(gh.repo) + '/contents/content/' + encodeURIComponent(article.slug) + '.md';
  const ghGet = (cb) => {
    const rq = https.request({ hostname: 'api.github.com', path: apiPath, method: 'GET', timeout: 15000, headers: { Authorization: 'Bearer ' + gh.token, 'User-Agent': 'moonarmor-sync', Accept: 'application/vnd.github+json' } }, res => { let d = ''; res.on('data', c => d += c); res.on('end', () => { try { const j = JSON.parse(d); cb(res.statusCode === 200 ? j.sha : null); } catch (e2) { cb(null); } }); });
    rq.on('error', () => cb(null)); rq.end();
  };
  ghGet(sha => {
    const payload = {
      message: 'publish: ' + article.title,
      content: Buffer.from('# ' + article.title + '\n\n' + (article.summary ? article.summary + '\n\n' : '') + article.content, 'utf8').toString('base64')
    };
    if (sha) payload.sha = sha;
    const body = JSON.stringify(payload);
    const req = https.request({ hostname: 'api.github.com', path: apiPath, method: 'PUT', timeout: 20000, headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + gh.token, 'User-Agent': 'moonarmor-sync', 'Content-Length': Buffer.byteLength(body) } }, res => { let d = ''; res.on('data', c => d += c); res.on('end', () => { if (res.statusCode >= 400) console.log('[github] sync failed', res.statusCode, d.slice(0, 200)); else console.log('[github] synced', article.slug, sha ? '(updated)' : '(created)'); }); });
    req.on('error', e => console.log('[github] sync error', e.message));
    req.end(body);
  });
}

// ---------- 定时发布（排期日历） ----------
setInterval(() => {
  const now = new Date().toISOString().replace(/T/, ' ').slice(0, 16);
  const due = db.prepare("SELECT * FROM articles WHERE schedule_at IS NOT NULL AND schedule_at <= ? AND status IN ('draft','reviewed')").all(now);
  for (const a of due) {
    db.prepare("UPDATE articles SET status = 'published', published_at = COALESCE(published_at, schedule_at), schedule_at = NULL WHERE id = ?").run(a.id);
    console.log('[schedule] auto-published article', a.id, a.title);
  }
}, 60000);

// ---------- 定时自动考核（sHRmatch 在架产品，每天一次） ----------
setInterval(() => {
  try { runListingAssessment(); } catch (e) { console.log('[listing] assessment interval error', e.message); }
}, 60 * 60 * 1000);

// ---------- 路由 ----------
const routes = [];
function route(method, pattern, handler) {
  const re = pattern.replace(/\//g, '\\/').replace(/:([^/]+)/g, '([^/]+)');
  routes.push({ method, pattern: re, handler });
}
function match(pathname, method) {
  for (const r of routes) {
    if (r.method !== method) continue;
    const m = pathname.match(new RegExp('^' + r.pattern + '$'));
    if (m) return { handler: r.handler, params: m.slice(1) };
  }
  return null;
}

// ===== 撮合交易子系统（代码系统+交易所）=====
route('GET', '/api/ex/listings', async (req, res) => { json(res, 200, exEngine.listListings()); });
route('GET', '/api/ex/history/:code', async (req, res) => { json(res, 200, exEngine.getPriceHistory(String(req.params[0]).slice(0, 24), 120)); });
route('GET', '/api/ex/portfolio', async (req, res) => {
  const u = authUser(req); if (!u) return json(res, 401, { error: '需要登录' });
  json(res, 200, exEngine.portfolio(u.id));
});
// F4.3 持仓分析（纯展示，不碰交易）
route('GET', '/api/ex/portfolio-analysis', async (req, res) => {
  const u = authUser(req); if (!u) return json(res, 401, { error: '需要登录' });
  json(res, 200, exEngine.portfolioAnalysis(u.id));
});
route('GET', '/api/ex/stats', async (req, res) => { json(res, 200, exEngine.marketStats()); });
// F4.4 行情预警（纯展示，不碰交易）：价格异动/成交放量/破发，双语免责声明
route('GET', '/api/ex/alerts', async (req, res) => {
  const m = (req.url || '').match(/[?&]change=(\d+(?:\.\d+)?)/);
  const t = (req.url || '').match(/[?&]turnover=(\d+(?:\.\d+)?)/);
  json(res, 200, exEngine.priceAlerts({ changePctMin: m && m[1], turnoverMin: t && t[1] }));
});
// F4.1 超级劳动基准指数（合规安全版：仅基准展示，不构成投资建议）
route('GET', '/api/idx/baseline', async (req, res) => {
  const days = Math.max(7, Math.min(90, parseInt((req.url || '').match(/[?&]days=(\d+)/)?.[1] || '30', 10) || 30));
  const period = (req.url || '').match(/[?&]period=(daily|weekly|monthly)/)?.[1] || 'daily';
  json(res, 200, exEngine.baselineIndex(days, period));
});
route('GET', '/api/ex/trades/:code', async (req, res) => {
  const code = decodeURIComponent(req.params[0]);
  if (!cs.verifyCheckDigit(code)) return json(res, 400, { error: '代码校验失败' });
  const lim = Math.max(1, Math.min(50, parseInt((req.url || '').match(/[?&]limit=(\d+)/)?.[1] || '10', 10) || 10));
  json(res, 200, exEngine.getRecentTrades(code, lim));
});
route('GET', '/api/ex/orderbook/:code', async (req, res) => {
  const code = decodeURIComponent(req.params[0]);
  if (!cs.verifyCheckDigit(code)) return json(res, 400, { error: '代码校验失败' });
  json(res, 200, exEngine.getOrderBook(code));
});
// 别名：文档命名 /api/ex/orderbook（无 code 参数时返回全部标的订单簿摘要）
route('GET', '/api/ex/orderbook', async (req, res) => {
  const listings = exEngine.listListings();
  const books = listings.map(l => ({ code: l.code, name: l.name, ...exEngine.getOrderBook(l.code) }));
  json(res, 200, { total: books.length, books });
});
route('GET', '/api/ex/holdings', async (req, res) => {
  const u = authUser(req); if (!u) return json(res, 401, { error: '需要登录' });
  json(res, 200, exEngine.getHoldings(u.id));
});
route('POST', '/api/ex/order', async (req, res) => {
  const u = authUser(req); if (!u) return json(res, 401, { error: '需要登录' });
  const b = await readBody(req);
  const { code, side, qty, price } = b;
  if (!code || !['buy','sell'].includes(side) || !(qty > 0) || !(price > 0)) return json(res, 400, { error: '参数错误' });
  if (!cs.verifyCheckDigit(code)) return json(res, 400, { error: '代码校验失败' });
  try { json(res, 200, exEngine.placeOrder({ code, userId: u.id, side, qty: Number(qty), price: Number(price) })); }
  catch (e) { json(res, 400, { error: e.message }); }
});
route('POST', '/api/ex/issue', async (req, res) => {
  const u = authUser(req); if (!u) return json(res, 401, { error: '需要登录' });
  const b = await readBody(req);
  const { name, type, totalShares, price } = b;
  if (!name || ![1,2,3,4].includes(Number(type)) || !(totalShares > 0) || !(price > 0)) return json(res, 400, { error: '参数错误' });
  // F2.1 类型专属发行资料（白名单过滤，入库 mk_listings.info）
  const raw = (b && b.info && typeof b.info === 'object') ? b.info : {};
  const info = {};
  if (Number(type) === 1) { // 超级劳动力：职业/技能、地区、日单价参考
    info.skills = String(raw.skills || '').trim().slice(0, 120);
    info.region = String(raw.region || '').trim().slice(0, 40);
    if (raw.daily_rate > 0) info.daily_rate = Number(raw.daily_rate) || 0;
    if (!info.skills) return json(res, 400, { error: '劳动力发行需填写职业/技能' });
  } else if (Number(type) === 2) { // 超级劳动法人：性质、行业、注册资本
    const lt = String(raw.legal_type || 'enterprise');
    info.legal_type = ['enterprise', 'government', 'nonprofit'].includes(lt) ? lt : 'enterprise';
    info.industry = String(raw.industry || '').trim().slice(0, 60);
    if (raw.reg_capital > 0) info.reg_capital = Number(raw.reg_capital) || 0;
    if (!info.industry) return json(res, 400, { error: '法人发行需填写所属行业' });
  } else if (Number(type) === 3) {
    info.category = String(raw.category || '').trim().slice(0, 40);
  } else { // 4 指数
    info.basis = String(raw.basis || '').trim().slice(0, 200);
  }
  try { json(res, 200, exEngine.issueListing({ name: String(name).slice(0, 80), type: Number(type), issuerId: u.id, totalShares: Number(totalShares), price: Number(price), info })); }
  catch (e) { json(res, 400, { error: e.message }); }
});

// ===== 口碑飞轮（#18 任务2：成交→评价→信用→排名；asus 设计 V1.0）=====
// 规则：成交后24h窗口内双方各评一次；三维加权(0.618/0.236/0.146)；公开匿名；差评须说明；信用回写+1/0/−2/−10(clamp[0,100])
route('GET', '/api/ex/reviews/pending', async (req, res) => {
  const u = authUser(req); if (!u) return json(res, 401, { error: '需要登录' });
  json(res, 200, exReviewEngine.pendingReviews(u.id));
});
route('POST', '/api/ex/reviews', async (req, res) => {
  const u = authUser(req); if (!u) return json(res, 401, { error: '需要登录' });
  const b = await readBody(req);
  const dims = Array.isArray(b.dims) ? b.dims : [];
  const r = exReviewEngine.submitReview({ tradeId: Number(b.tradeId), reviewerId: u.id, dim1: dims[0], dim2: dims[1], dim3: dims[2], comment: b.comment });
  if (r.error) return json(res, 400, r);
  json(res, 200, r);
});
route('GET', '/api/ex/reviews/summary', async (req, res) => {
  const q = (req.url || '').match(/[?&]code=([^&]+)/);
  const uq = (req.url || '').match(/[?&]userId=(\d+)/);
  if (q) return json(res, 200, exReviewEngine.codeSummary(decodeURIComponent(q[1])));
  if (uq) return json(res, 200, exReviewEngine.userSummary(Number(uq[1])));
  json(res, 400, { error: '需 code 或 userId 参数' });
});
route('GET', '/api/ex/reviews/summaries', async (req, res) => { json(res, 200, { items: exReviewEngine.allCodeSummaries() }); });
route('GET', '/api/ex/reviews/list', async (req, res) => {
  const q = (req.url || '').match(/[?&]code=([^&]+)/);
  const uq = (req.url || '').match(/[?&]userId=(\d+)/);
  const lim = (req.url || '').match(/[?&]limit=(\d+)/);
  if (!q && !uq) return json(res, 400, { error: '需 code 或 userId 参数' });
  json(res, 200, { items: exReviewEngine.listReviews({ code: q ? decodeURIComponent(q[1]) : null, userId: uq ? Number(uq[1]) : null, limit: lim ? Number(lim[1]) : 20 }) });
});

// ===== 智能体广场（F3.1）：注册表驱动，F3.2 自定义上架沿用此数据口 =====
const AGENT_PLAZA = [
  { id: 'renovation', ico: '🛠️', cat: 'life', name: '装修智能体参谋', desc: '10万问装修知识库+LLM，方案报价一键参谋', href: '/renovation.html' },
  { id: 'contract', ico: '⚖️', cat: 'trade', name: '合同智能审核', desc: '15条规则库扫描条款风险，输出等级与建议', href: '/contract.html' },
  { id: 'fee', ico: '💡', cat: 'trade', name: '费率智能参谋', desc: '基于成交记录智能推荐最优费率档位', href: 'javascript:;', act: 'feeAdvice()' },
  { id: 'help', ico: '📚', cat: 'qa', name: '全站帮助智能体', desc: '站内检索+AI 问答，一键转人工', href: 'javascript:;', act: "var h=document.getElementById('ma-help-btn');if(h)h.click()" },
  { id: 'search', ico: '🔍', cat: 'qa', name: '文档问答智能体', desc: '全站文档检索与问答', href: '/search.html' },
  { id: 'chapter-ask', ico: '🧐', cat: 'qa', name: '章节精读AI助手', desc: '只依据本章内容回答，深度阅读伴侣', href: '/read' },
  { id: 'thoughts', ico: '💭', cat: 'create', name: '深度思考伴侣', desc: '章节思考问题引导，想法可公开交流', href: '/read' },
  { id: 'gov', ico: '🤝', cat: 'gov', name: '治理智能体', desc: '提案/投票/竹筏指数治理看板', href: '/governance.html' },
  { id: 'a1', ico: '🎯', cat: 'trade', name: 'A1 招聘寻源智能体', desc: '已发行上市的超级劳动产品标的，可交易持仓', href: '/exchange.html?code=02315651000000000145' },
  { id: 'upload', ico: '🚀', cat: 'gov', name: '上架自定义智能体', desc: '提交你的智能体入驻广场（F3.2 开放自助上架）', href: 'mailto:18611475369@wo.cn?subject=' + encodeURIComponent('上架自定义智能体') }
];
route('GET', '/api/agents/plaza', async (req, res) => {
  const custom = db.prepare("SELECT id, ico, cat, name, desc, href, 'online' AS status FROM agent_plaza WHERE status='online' ORDER BY id DESC LIMIT 30").all();
  json(res, 200, AGENT_PLAZA.map(a => ({ ...a, status: 'online' })).concat(custom));
});
// F3.2 自定义智能体上架：提交 → 待审 → 管理员审核上线
route('POST', '/api/agents/plaza/submit', async (req, res) => {
  const u = authUser(req); if (!u) return json(res, 401, { error: '请先登录' });
  const b = await readBody(req, 10000);
  const name = String(b.name || '').trim().slice(0, 40);
  const href = String(b.href || '').trim().slice(0, 300);
  if (!name || !href) return json(res, 400, { error: '名称与链接必填' });
  if (!/^https?:\/\/|^\/[a-z]/i.test(href)) return json(res, 400, { error: '链接需为站内路径或 http(s) 地址' });
  const n = db.prepare('SELECT COUNT(*) n FROM agent_plaza WHERE user_id=?').get(u.id).n;
  if (n >= 20) return json(res, 400, { error: '每个账号最多上架 20 个智能体' });
  const ico = String(b.ico || '🤖').trim().slice(0, 8) || '🤖';
  const cat = ['trade', 'create', 'qa', 'gov', 'life'].includes(b.cat) ? b.cat : 'gov';
  const desc = String(b.desc || '').trim().slice(0, 120);
  const r = db.prepare('INSERT INTO agent_plaza(user_id,name,ico,cat,desc,href) VALUES(?,?,?,?,?,?)').run(u.id, name, ico, cat, desc, href);
  json(res, 200, { ok: true, id: r.lastInsertRowid, status: 'pending' });
});
route('GET', '/api/agents/plaza/mine', async (req, res) => {
  const u = authUser(req); if (!u) return json(res, 401, { error: '请先登录' });
  json(res, 200, db.prepare('SELECT id, name, ico, cat, desc, href, status FROM agent_plaza WHERE user_id=? ORDER BY id DESC').all(u.id));
});
route('GET', '/api/agents/plaza/pending', async (req, res) => {
  const u = authUser(req); if (!u || u.role !== 'admin') return json(res, 403, { error: '无权限' });
  json(res, 200, db.prepare("SELECT id, user_id, name, ico, cat, desc, href, status FROM agent_plaza WHERE status='pending' ORDER BY id ASC").all());
});
route('POST', '/api/agents/plaza/:id', async (req, res) => {
  const u = authUser(req); if (!u || u.role !== 'admin') return json(res, 403, { error: '无权限' });
  const id = Number(req.params[0]);
  const b = await readBody(req, 2000);
  const st = b.status === 'online' ? 'online' : 'rejected';
  const r = db.prepare('UPDATE agent_plaza SET status=? WHERE id=?').run(st, id);
  if (!r.changes) return json(res, 404, { error: '不存在' });
  json(res, 200, { ok: true, status: st });
});

// ===== 成都装修智能体集群（行业样板，PIRA 模式复制）=====
// 验收模板（五阶段双语清单，公开）
route('GET', '/api/deco/templates', async (req, res) => {
  json(res, 200, { success: true, data: decoEngine.VALIDATION_TEMPLATES });
});
// 装修记录：写/查（登录即可；主体暂用 person，后续装修版扩展 contractor/company）
route('POST', '/api/deco/records', async (req, res) => {
  const o = deriveArchiveOwner(req);
  if (!o) return json(res, 401, { error: '未登录' });
  const body = await readBody(req);
  json(res, 200, decoEngine.createDecoRecord(o.ownerType, o.ownerId, body));
});
route('GET', '/api/deco/records', async (req, res) => {
  const o = deriveArchiveOwner(req);
  if (!o) return json(res, 401, { error: '未登录' });
  json(res, 200, decoEngine.listDecoRecords(o.ownerType, o.ownerId, { phase: req.query.phase, limit: Number(req.query.limit) || 50, offset: Number(req.query.offset) || 0 }));
});
// 工长/公司信用档案（公开可查）
route('GET', '/api/deco/credit/:ownerId', async (req, res) => {
  json(res, 200, decoEngine.decoCreditSummary(Number(req.params[0])));
});
// 装修平台统计（公开：记录总数/工长数/公司数）
route('GET', '/api/deco/stats', async (req, res) => {
  try {
    const recs = db.prepare('SELECT COUNT(*) c FROM deco_records').get().c;
    const contractors = db.prepare("SELECT COUNT(DISTINCT owner_id) c FROM deco_records WHERE record_type IN ('acceptance','progress')").get().c;
    const phases = db.prepare('SELECT phase, COUNT(*) c FROM deco_records GROUP BY phase').all();
    const workers = db.prepare('SELECT COUNT(*) c FROM worker_profiles').get().c;
    json(res, 200, { success: true, data: { records: recs, contractors: contractors, workers, phases } });
  } catch (e) { json(res, 200, { success: true, data: { records: 0, contractors: 0, workers: 0, phases: [] } }); }
});
// 工人档案与业主影子（装修第一批：业主+工人；/skills 必须注册在 /:ownerId 之前，锚定正则下后者会吞掉前者）
route('GET', '/api/deco/workers/skills', async (req, res) => {
  json(res, 200, { success: true, data: decoEngine.WORKER_SKILLS });
});
// 工人档案：登录工人本人写档案（upsert，写后自动刷新信用分）
route('POST', '/api/deco/workers', async (req, res) => {
  const o = deriveArchiveOwner(req);
  if (!o) return json(res, 401, { error: '未登录' });
  const body = await readBody(req);
  json(res, 200, { success: true, data: decoEngine.upsertWorkerProfile(o.ownerId, body || {}) });
});
// 工人列表（公开，撮合用：城市/技能过滤 + 分页，按信用分降序）
route('GET', '/api/deco/workers', async (req, res) => {
  json(res, 200, { success: true, data: decoEngine.listWorkers({ city: req.query.city, skill: req.query.skill, limit: Number(req.query.limit) || 20, offset: Number(req.query.offset) || 0 }) });
});
// 工人档案：登录工人看自己的档案（含信用分与技能统计；注册在 /:ownerId 之前，避免被吞掉）
route('GET', '/api/deco/workers/me', async (req, res) => {
  const o = deriveArchiveOwner(req);
  if (!o) return json(res, 401, { error: '未登录' });
  json(res, 200, { success: true, data: decoEngine.getWorkerProfile(o.ownerId) });
});
// 工人档案详情（公开可查）
route('GET', '/api/deco/workers/:ownerId', async (req, res) => {
  json(res, 200, { success: true, data: decoEngine.getWorkerProfile(Number(req.params[0])) });
});
// 业主影子（登录看本人 me；管理员 all=1 可指定 ownerId；防横向越权）
route('GET', '/api/deco/shadow/:ownerId', async (req, res) => {
  const o = deriveArchiveOwner(req);
  if (!o) return json(res, 401, { error: '未登录' });
  const u = authUser(req);
  const raw = String(req.params[0]);
  let target = o.ownerId;
  if (raw !== 'me') {
    if (!(u && u.role === 'admin' && req.query.all === '1')) return json(res, 403, { error: '无权查看他人影子' });
    target = Number(raw);
  }
  json(res, 200, { success: true, data: decoEngine.ownerShadow(Number(target)) });
});

// ===== 撮合交易（发单→报价→三要素排名→定标成交；大成都区域门禁）=====
route('POST', '/api/deco/jobs', async (req, res) => {
  const o = deriveArchiveOwner(req);
  if (!o) return json(res, 401, { error: '未登录' });
  const body = await readBody(req);
  const r = decoMatch.createJob(o.ownerId, body || {});
  if (r && r.error === 'BAD_DISTRICT') return json(res, 400, { success: false, error: r.error, message: r.message || '区县无效（大成都 22 区县）' });
  json(res, 200, { success: true, data: r });
});
route('GET', '/api/deco/jobs', async (req, res) => {
  const o = deriveArchiveOwner(req);
  const opts = { status: req.query.status, phase: req.query.phase, district: req.query.district, limit: Number(req.query.limit) || 20, offset: Number(req.query.offset) || 0 };
  if (req.query.mine === '1') { if (!o) return json(res, 401, { error: '未登录' }); opts.mineOwnerId = o.ownerId; }
  json(res, 200, { success: true, data: decoMatch.listJobs(opts) });
});
route('GET', '/api/deco/jobs/:id', async (req, res) => {
  json(res, 200, { success: true, data: decoMatch.getJob(Number(req.params[0])) });
});
route('POST', '/api/deco/jobs/:id/quotes', async (req, res) => {
  const o = deriveArchiveOwner(req);
  if (!o) return json(res, 401, { error: '未登录' });
  const body = await readBody(req);
  const r = decoMatch.upsertQuote(Number(req.params[0]), o.ownerId, body || {});
  if (r && r.error === 'OUT_OF_REGION') return json(res, 403, { success: false, error: r.error, message: r.message || '仅大成都范围工人可参与报价' });
  if (r && r.error === 'JOB_NOT_OPEN') return json(res, 400, { success: false, error: r.error, message: r.message || '任务不在可报价状态' });
  json(res, 200, { success: true, data: r });
});
route('GET', '/api/deco/jobs/:id/quotes', async (req, res) => {
  json(res, 200, { success: true, data: decoMatch.listQuotes(Number(req.params[0])) });
});
route('GET', '/api/deco/jobs/:id/match', async (req, res) => {
  json(res, 200, { success: true, data: decoMatch.computeQuoteScores(Number(req.params[0])) });
});
route('POST', '/api/deco/jobs/:id/award', async (req, res) => {
  const o = deriveArchiveOwner(req);
  if (!o) return json(res, 401, { error: '未登录' });
  const body = await readBody(req);
  json(res, 200, { success: true, data: decoMatch.awardJob(Number(req.params[0]), o.ownerId, Number(body.quoteId)) });
});
route('POST', '/api/deco/jobs/:id/cancel', async (req, res) => {
  const o = deriveArchiveOwner(req);
  if (!o) return json(res, 401, { error: '未登录' });
  json(res, 200, { success: true, data: decoMatch.cancelJob(Number(req.params[0]), o.ownerId) });
});
route('GET', '/api/deco/match/stats', async (req, res) => {
  json(res, 200, { success: true, data: decoMatch.matchStats() });
});

// ===== 大成都定位（22 区县 + bbox 公开）=====
route('GET', '/api/deco/geo/districts', async (req, res) => {
  json(res, 200, { success: true, data: { region: decoGeo.REGION, districts: decoGeo.CHENGDU_DISTRICTS, bounds: decoGeo.CHENGDU_BOUNDS } });
});

// ===== 区域口碑排名（登录；已绑定区县的业主仅可查本区县——西侧不查东侧；新业主未绑定时可浏览）=====
route('GET', '/api/deco/rankings', async (req, res) => {
  const o = deriveArchiveOwner(req);
  if (!o) return json(res, 401, { error: '未登录' });
  const u = authUser(req);
  const district = String(req.query.district || '');
  if (!district) return json(res, 400, { success: false, error: 'NO_DISTRICT', message: '请先定位或选择区县' });
  const own = decoRanking.ownerDistrictOf(o.ownerId);
  if (own) {
    const gate = decoRanking.ownerDistrictGate(o.ownerId, district, !!(u && u.role === 'admin'));
    if (!gate.ok) return json(res, 403, { success: false, error: gate.error, message: '仅可查看本区县口碑排名（西侧不查东侧）' });
  }
  const r = decoRanking.getRankings(district, req.query.role, Number(req.query.limit) || 20, Number(req.query.offset) || 0);
  if (r && r.error === 'BAD_DISTRICT') return json(res, 400, { success: false, error: r.error, message: '区县无效' });
  if (r && r.error === 'BAD_ROLE') return json(res, 400, { success: false, error: r.error, message: '角色无效' });
  json(res, 200, { success: true, data: r });
});

// ===== 标准合约（授权/安全；售后免费收费按 2年/5年 质保口径）=====
route('GET', '/api/deco/contracts/types', async (req, res) => {
  json(res, 200, { success: true, data: decoContract.listContractTypes() });
});
route('GET', '/api/deco/contracts/template/:code', async (req, res) => {
  const t = decoContract.getTemplate(String(req.params[0]));
  if (!t) return json(res, 404, { success: false, error: 'NOT_FOUND' });
  json(res, 200, { success: true, data: t });
});
// V0.1681 合同风险审查（专题一 功能8 / 专题二 风控岗）
route('GET', '/api/deco/contracts/review/:code', async (req, res) => {
  const r = decoContract.reviewContract(String(req.params[0]));
  if (r && r.error === 'NOT_FOUND') return json(res, 404, { success: false, error: r.error });
  json(res, 200, { success: true, data: r });
});
route('POST', '/api/deco/contracts/sign', async (req, res) => {
  const o = deriveArchiveOwner(req);
  if (!o) return json(res, 401, { error: '未登录' });
  const body = await readBody(req);
  json(res, 200, { success: true, data: decoContract.signContract({ code: body.code, ownerId: o.ownerId, partyOwnerId: Number(body.partyOwnerId) || null, jobId: Number(body.jobId) || null }) });
});
route('GET', '/api/deco/contracts', async (req, res) => {
  const o = deriveArchiveOwner(req);
  if (!o) return json(res, 401, { error: '未登录' });
  json(res, 200, { success: true, data: decoContract.listContracts(o.ownerId) });
});

// ===== 工人安全保障（质保金分级 / 保险团购 / 成都装修协会第三方）=====
route('GET', '/api/deco/safety/deposit-tiers', async (req, res) => {
  json(res, 200, { success: true, data: decoSafety.getDepositTiers() });
});
route('POST', '/api/deco/safety/deposit', async (req, res) => {
  const o = deriveArchiveOwner(req);
  if (!o) return json(res, 401, { error: '未登录' });
  const body = await readBody(req);
  const r = decoSafety.deposit(String(body.ownerType || 'worker'), o.ownerId, Number(body.amount) || 0);
  if (r && r.error === 'BAD_OWNER_TYPE') return json(res, 400, { success: false, error: r.error, message: r.message || '主体类型无效' });
  json(res, 200, { success: true, data: r });
});
route('GET', '/api/deco/safety/deposit/me', async (req, res) => {
  const o = deriveArchiveOwner(req);
  if (!o) return json(res, 401, { error: '未登录' });
  const t = String(req.query.ownerType || 'worker');
  json(res, 200, { success: true, data: decoSafety.depositSummary(t, o.ownerId) });
});
route('GET', '/api/deco/safety/insurance-plans', async (req, res) => {
  json(res, 200, { success: true, data: decoSafety.listInsurancePlans() });
});
route('POST', '/api/deco/safety/insurance/buy', async (req, res) => {
  const o = deriveArchiveOwner(req);
  if (!o) return json(res, 401, { error: '未登录' });
  const body = await readBody(req);
  const r = decoSafety.buyInsurance(o.ownerId, Number(body.planId));
  if (r && r.error === 'BAD_PLAN') return json(res, 400, { success: false, error: r.error, message: r.message || '保险方案不存在' });
  if (r && r.error === 'ALREADY_ACTIVE') return json(res, 400, { success: false, error: r.error, message: r.message || '该方案已生效' });
  json(res, 200, { success: true, data: r });
});
route('GET', '/api/deco/safety/policies/me', async (req, res) => {
  const o = deriveArchiveOwner(req);
  if (!o) return json(res, 401, { error: '未登录' });
  json(res, 200, { success: true, data: decoSafety.listPolicies(o.ownerId) });
});
route('GET', '/api/deco/association/about', async (req, res) => {
  json(res, 200, { success: true, data: decoSafety.associationInfo() });
});
// ===== 装修百科知识（第11智能体；七知识域，公开）=====
route('GET', '/api/deco/kb/categories', async (req, res) => {
  json(res, 200, { success: true, data: decoKB.listCategories() });
});
route('GET', '/api/deco/kb/stats', async (req, res) => {
  json(res, 200, { success: true, data: decoKB.kbStats() });
});
// V0.1681 七维知识体系标签（专题四）
route('GET', '/api/deco/kb/dims', async (req, res) => {
  json(res, 200, { success: true, data: decoKB.SEVEN_DIMS });
});
// V0.1681 报价单智能审查（专题一·功能7）
route('POST', '/api/deco/quotes/review', async (req, res) => {
  const body = await readBody(req);
  const r = decoQuote.reviewQuote(body || {});
  if (r && r.error === 'EMPTY') return json(res, 400, { success: false, error: r.error, message: r.message });
  json(res, 200, { success: true, data: r });
});
route('GET', '/api/deco/kb', async (req, res) => {
  json(res, 200, { success: true, data: decoKB.listKB({ category: req.query.category, q: req.query.q, limit: Number(req.query.limit) || 20, offset: Number(req.query.offset) || 0 }) });
});
route('GET', '/api/deco/kb/:id', async (req, res) => {
  const a = decoKB.getKB(Number(req.params[0]));
  if (!a) return json(res, 404, { success: false, error: 'NOT_FOUND' });
  json(res, 200, { success: true, data: a });
});

// ===== 装修获客（第12智能体；线索登记免登录、曝光/点击公开、管理视图登录）=====
route('GET', '/api/deco/leads/channels', async (req, res) => {
  json(res, 200, { success: true, data: decoLead.CHANNELS });
});
route('POST', '/api/deco/leads', async (req, res) => {
  const body = await readBody(req);
  const r = decoLead.createLead(body || {});
  if (r && r.error === 'BAD_DISTRICT') return json(res, 400, { success: false, error: r.error, message: r.message || '仅大成都范围' });
  if (r && r.error === 'BAD_CHANNEL') return json(res, 400, { success: false, error: r.error, message: r.message || '渠道无效' });
  json(res, 200, { success: true, data: r });
});
route('POST', '/api/deco/leads/events', async (req, res) => {
  const body = await readBody(req);
  json(res, 200, { success: true, data: decoLead.recordEvent(String(body.channel || ''), String(body.event || 'click'), body.ref || '') });
});
route('GET', '/api/deco/leads', async (req, res) => {
  const o = deriveArchiveOwner(req);
  if (!o) return json(res, 401, { error: '未登录' });
  json(res, 200, { success: true, data: decoLead.listLeads({ status: req.query.status, channel: req.query.channel, limit: Number(req.query.limit) || 20, offset: Number(req.query.offset) || 0 }) });
});
route('POST', '/api/deco/leads/:id/status', async (req, res) => {
  const o = deriveArchiveOwner(req);
  if (!o) return json(res, 401, { error: '未登录' });
  const body = await readBody(req);
  json(res, 200, { success: true, data: decoLead.updateLeadStatus(Number(req.params[0]), String(body.status || 'contacted')) });
});
route('GET', '/api/deco/leads/stats', async (req, res) => {
  const o = deriveArchiveOwner(req);
  if (!o) return json(res, 401, { error: '未登录' });
  json(res, 200, { success: true, data: decoLead.leadStats() });
});

// ===== 装修飞车 V0（#48）：无登录 5 站端到端试乘动线 =====
// 全部免登录；全部金额为演示数据，不接真实支付、不发生真实扣款。
// 三要素撮合 / 报价审查 / 合同风险 / 五阶段验收全部复用既有规则引擎，非静态假数据。
route('GET', '/api/deco/flycar/templates', async (req, res) => {
  json(res, 200, { success: true, data: decoFlycar.stageTemplates() });
});
route('GET', '/api/deco/flycar/stats', async (req, res) => {
  json(res, 200, { success: true, data: decoFlycar.flycarStats() });
});
route('POST', '/api/deco/flycar/sessions', async (req, res) => {
  const body = await readBody(req);
  const r = decoFlycar.createSession(body || {});
  if (r && r.error === 'NO_DISTRICT') return json(res, 400, { success: false, error: r.error, message: r.message });
  json(res, 200, r);
});
route('GET', '/api/deco/flycar/sessions/:token', async (req, res) => {
  const s = decoFlycar.getSession(String(req.params[0]));
  if (!s) return json(res, 404, { success: false, error: 'NOT_FOUND', message: '试乘会话不存在或已过期' });
  json(res, 200, { success: true, data: decoFlycar.sessionView(s) });
});
route('POST', '/api/deco/flycar/sessions/:token', async (req, res) => {
  const body = await readBody(req);
  const r = decoFlycar.updateSession(String(req.params[0]), body || {});
  if (r && r.error === 'BAD_DISTRICT') return json(res, 400, { success: false, error: r.error, message: r.message });
  if (r && r.error === 'NOT_FOUND') return json(res, 404, { success: false, error: r.error, message: r.message });
  json(res, 200, r);
});
route('GET', '/api/deco/flycar/sessions/:token/match', async (req, res) => {
  const r = decoFlycar.computeMatch(String(req.params[0]));
  if (r && r.error === 'NOT_FOUND') return json(res, 404, { success: false, error: r.error, message: r.message });
  if (r && r.error === 'NO_SEED') return json(res, 503, { success: false, error: r.error, message: r.message });
  json(res, 200, r);
});
route('POST', '/api/deco/flycar/sessions/:token/pick', async (req, res) => {
  const body = await readBody(req);
  const r = decoFlycar.pickCandidate(String(req.params[0]), Number(body && body.candidateId));
  if (r && r.error === 'NOT_FOUND') return json(res, 404, { success: false, error: r.error, message: r.message });
  if (r && r.error === 'BAD_CANDIDATE') return json(res, 400, { success: false, error: r.error, message: r.message });
  json(res, 200, r);
});
route('GET', '/api/deco/flycar/sessions/:token/review', async (req, res) => {
  const r = decoFlycar.reviewSelected(String(req.params[0]));
  if (r && r.error === 'NOT_FOUND') return json(res, 404, { success: false, error: r.error, message: r.message });
  if (r && r.error === 'NO_PICK') return json(res, 400, { success: false, error: r.error, message: r.message });
  json(res, 200, r);
});
route('GET', '/api/deco/flycar/sessions/:token/plan', async (req, res) => {
  const r = decoFlycar.paymentPlan(String(req.params[0]));
  if (r && r.error === 'NOT_FOUND') return json(res, 404, { success: false, error: r.error, message: r.message });
  if (r && r.error === 'NO_PICK') return json(res, 400, { success: false, error: r.error, message: r.message });
  json(res, 200, r);
});
route('POST', '/api/deco/flycar/sessions/:token/stage', async (req, res) => {
  const body = await readBody(req);
  const r = decoFlycar.setStage(String(req.params[0]), String(body && body.code || ''), body && body.checked, body && body.note);
  if (r && r.error === 'NOT_FOUND') return json(res, 404, { success: false, error: r.error, message: r.message });
  if (r && r.error === 'BAD_STAGE') return json(res, 400, { success: false, error: r.error, message: r.message });
  json(res, 200, r);
});
route('POST', '/api/deco/flycar/sessions/:token/score', async (req, res) => {
  const body = await readBody(req);
  const r = decoFlycar.finalScore(String(req.params[0]), Number(body && body.rating));
  if (r && r.error === 'NOT_FOUND') return json(res, 404, { success: false, error: r.error, message: r.message });
  if (r && r.error === 'NO_PICK') return json(res, 400, { success: false, error: r.error, message: r.message });
  if (r && r.error === 'BAD_RATING') return json(res, 400, { success: false, error: r.error, message: r.message });
  json(res, 200, r);
});
// 灰度意见收集（#48 指定 deco_feedback；写免登录，读需要管理员）
route('POST', '/api/deco/flycar/feedback', async (req, res) => {
  const body = await readBody(req);
  const r = decoFlycar.addFeedback(body || {});
  if (r && r.error === 'EMPTY') return json(res, 400, { success: false, error: r.error, message: r.message });
  json(res, 200, r);
});
route('GET', '/api/deco/flycar/feedback.csv', async (req, res) => {
  const u = authUser(req);
  if (!(u && u.role === 'admin')) return json(res, 403, { error: '需要管理员' });
  const csv = decoFlycar.feedbackCsv();
  res.writeHead(200, { 'Content-Type': 'text/csv; charset=utf-8', 'Content-Disposition': 'attachment; filename="deco_feedback.csv"' });
  res.end('\ufeff' + csv);
});
route('GET', '/api/deco/flycar/feedback', async (req, res) => {
  const u = authUser(req);
  if (!(u && u.role === 'admin')) return json(res, 403, { error: '需要管理员' });
  json(res, 200, decoFlycar.listFeedback({ limit: Number(req.query.limit) || 100, offset: Number(req.query.offset) || 0 }));
});
// ===== 档案产品频道·需求建议智能体（多碳基人协同开发；语音/文字均可；asus PR#28 手工合并）=====
route('GET', '/api/archive/feedback/categories', async (req, res) => {
  json(res, 200, { success: true, data: feedbackEngine.CATEGORIES });
});
route('POST', '/api/archive/feedback/agent', async (req, res) => {
  const body = await readBody(req);
  const o = deriveArchiveOwner(req);
  const r = await feedbackEngine.agentChat(String(body.question || ''), o ? o.ownerId : null);
  json(res, 200, { success: true, data: r });
});
route('POST', '/api/archive/feedback', async (req, res) => {
  const o = deriveArchiveOwner(req);
  if (!o) return json(res, 401, { error: '未登录' });
  const body = await readBody(req);
  const r = feedbackEngine.submitFeedback(o.ownerId, body || {});
  if (r && r.error === 'EMPTY') return json(res, 400, { success: false, error: r.error, message: r.message });
  json(res, 200, { success: true, data: r });
});
route('GET', '/api/archive/feedback', async (req, res) => {
  json(res, 200, { success: true, data: feedbackEngine.listFeedback({ status: req.query.status, category: req.query.category, limit: Number(req.query.limit) || 20, offset: Number(req.query.offset) || 0 }) });
});
route('POST', '/api/archive/feedback/:id/vote', async (req, res) => {
  const o = deriveArchiveOwner(req);
  if (!o) return json(res, 401, { error: '未登录' });
  const r = feedbackEngine.voteFeedback(Number(req.params[0]), o.ownerId);
  if (r && r.error === 'ALREADY_VOTED') return json(res, 400, { success: false, error: r.error, message: r.message });
  if (r && r.error === 'NOT_FOUND') return json(res, 404, { success: false, error: r.error });
  json(res, 200, { success: true, data: r });
});
route('GET', '/api/archive/feedback/stats', async (req, res) => {
  json(res, 200, { success: true, data: feedbackEngine.feedbackStats() });
});
// 对话记录（仅管理员：回收未提交的意见，防丢稿）
route('GET', '/api/archive/feedback/chats', async (req, res) => {
  const u = authUser(req);
  if (!u) return json(res, 401, { error: '未登录' });
  if (u.role !== 'admin') return json(res, 403, { error: '仅管理员可查看对话记录' });
  json(res, 200, { success: true, data: feedbackEngine.listChats({ limit: Number(req.query.limit) || 30 }) });
});
// ===== 档案导出（缺口⑦：Word / 文本，越权过滤按 owner）=====
route('GET', '/api/archive/export/list', async (req, res) => {
  const o = deriveArchiveOwner(req);
  if (!o) return json(res, 401, { error: '未登录' });
  json(res, 200, { success: true, data: archiveExport.listExportable(o.ownerType, o.ownerId) });
});
route('GET', '/api/archive/export/text', async (req, res) => {
  const o = deriveArchiveOwner(req);
  if (!o) return json(res, 401, { error: '未登录' });
  const ids = (req.query.archiveIds || '').split(',').map(function (x) { return Number(x); }).filter(Boolean);
  const txt = archiveExport.exportArchiveText(o.ownerType, o.ownerId, { archiveIds: ids });
  res.writeHead(200, { 'Content-Type': 'text/plain; charset=utf-8', 'Content-Disposition': 'attachment; filename*=UTF-8\'\'moonarmor_archive.txt' });
  return res.end(txt);
});
route('GET', '/api/archive/export/docx', async (req, res) => {
  const o = deriveArchiveOwner(req);
  if (!o) return json(res, 401, { error: '未登录' });
  const ids = (req.query.archiveIds || '').split(',').map(function (x) { return Number(x); }).filter(Boolean);
  const buf = archiveExport.exportArchiveDocx(o.ownerType, o.ownerId, { archiveIds: ids });
  res.writeHead(200, { 'Content-Type': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'Content-Disposition': 'attachment; filename*=UTF-8\'\'moonarmor_archive.docx', 'Content-Length': buf.length });
  return res.end(buf);
});
// ===== 装修智能体参谋（10万问知识库 + LLM）=====
route('GET', '/api/renovation/stats', async (req, res) => { json(res, 200, renoKB.stats()); });
route('POST', '/api/renovation/chat', async (req, res) => {
  const b = await readBody(req);
  const q = (b.question || '').trim();
  if (!q) return json(res, 400, { error: '问题不能为空' });
  try {
    const r = await renoKB.answer(q);
    json(res, 200, { answer: r.answer, from: r.from, related: (r.related || []).map(x => ({ id: x.id, cat: x.cat, q: x.q })), wiki: r.wiki || [] });
  } catch (e) { json(res, 500, { error: e.message }); }
});
// 别名：文档命名 /api/renovation/ask（同 chat）
route('POST', '/api/renovation/ask', async (req, res) => {
  const b = await readBody(req);
  const q = (b.question || '').trim();
  if (!q) return json(res, 400, { error: '问题不能为空' });
  try {
    const r = await renoKB.answer(q);
    json(res, 200, { answer: r.answer, from: r.from, related: (r.related || []).map(x => ({ id: x.id, cat: x.cat, q: x.q })), wiki: r.wiki || [] });
  } catch (e) { json(res, 500, { error: e.message }); }
});

// ===== 公开接口 =====
route('GET', '/api/site', async (req, res) => {
  const total = db.prepare('SELECT COUNT(*) c, COALESCE(SUM(LENGTH(content)),0) w FROM articles WHERE status = \'published\'').get();
  const artRows = db.prepare('SELECT content FROM articles WHERE status = \'published\'').all();
  const artWords = artRows.reduce((s, r) => s + bookEngine.countWords(r.content), 0);
  const books = bookEngine.listBooks();
  const bookChars = books.reduce((s, b) => s + (b.chars || 0), 0);
  const bookWords = books.reduce((s, b) => s + (b.words || 0), 0);
  const words = artWords + bookWords;
  const pages = Math.round(words / 1400);
  const pool = db.prepare('SELECT COALESCE(SUM(pool_amount),0) s, COUNT(*) c FROM dividend_ledger').get();
  const views = db.prepare('SELECT COALESCE(SUM(view_count),0) s FROM articles').get();
  const comments = db.prepare('SELECT COUNT(*) c FROM comments').get();
  json(res, 200, {
    name: getSetting('site_name', '月亮盔甲'),
    domain: getSetting('site_domain', 'moonarmor.cn'),
    company: getSetting('company_name', '北京市飞狐灵通软件技术有限公司'),
    stats: { articles: total.c, chars: total.w + bookChars, words: words, pages: pages, pool: pool.s, pool_entries: pool.c, views: views.s, comments: comments.c },
    dividend_ratio: RATIO,
    payment_mode: getSetting('payment_mode', 'simulate')
  });
});

route('GET', '/api/categories', async (req, res) => {
  const rows = db.prepare('SELECT * FROM categories ORDER BY level, sort_order, id').all();
  json(res, 200, rows);
});

route('GET', '/api/areas', async (req, res) => {
  json(res, 200, db.prepare('SELECT * FROM app_areas ORDER BY sort_order, id').all());
});

route('GET', '/api/articles', async (req, res) => {
  const u = new URL(req.url, 'http://x');
  const q = u.searchParams;
  const where = ["status = 'published'"]; const args = [];
  const cat = q.get('cat');
  if (cat) { const c = db.prepare('SELECT level FROM categories WHERE id = ?').get(Number(cat)); if (c) where.push('cat' + c.level + '_id = ?'), args.push(Number(cat)); }
  if (q.get('g')) where.push('granularity LIKE ?'), args.push('%' + q.get('g') + '%');
  if (q.get('area')) where.push('app_areas LIKE ?'), args.push('%' + q.get('area') + '%');
  if (q.get('tag')) where.push('tags LIKE ?'), args.push('%' + q.get('tag') + '%');
  if (q.get('q')) { where.push('(title LIKE ? OR content LIKE ? OR summary LIKE ?)'); const kw = '%' + q.get('q') + '%'; args.push(kw, kw, kw); }
  const page = Math.max(1, Number(q.get('page') || 1));
  const size = Math.min(50, Math.max(1, Number(q.get('size') || 10)));
  const total = db.prepare('SELECT COUNT(*) c FROM articles WHERE ' + where.join(' AND ')).get(...args).c;
  const rows = db.prepare('SELECT * FROM articles WHERE ' + where.join(' AND ') + ' ORDER BY published_at DESC, id DESC LIMIT ? OFFSET ?')
    .all(...args, size, (page - 1) * size).map(r => articleRow(r, false));
  json(res, 200, { total, page, size, items: rows });
});

// ===== 全站全文搜索（FTS5，带高亮）=====
route('GET', '/api/search', async (req, res) => {
  const u = new URL(req.url, 'http://x');
  const q = (u.searchParams.get('q') || '').trim();
  const limit = Number(u.searchParams.get('size') || 20);
  if (!q) return json(res, 200, { total: 0, items: [], engine: 'empty' });
  try {
    const r = searchEngine.search(q, { limit });
    json(res, 200, { total: r.total, items: r.items, engine: r.engine, q });
  } catch (e) { json(res, 500, { error: e.message }); }
});

// 重建搜索索引（管理员）
route('POST', '/api/admin/search/reindex', async (req, res) => {
  const u = authUser(req); if (!u || u.role !== 'admin') return json(res, 403, { error: '无权限' });
  const ok = searchEngine.rebuildIndex();
  const siteOk = searchEngine.rebuildSiteIndex();
  json(res, 200, { ok: true, fts: ok, site: siteOk, stats: searchEngine.siteStats() });
});

// 全站跨类型搜索（搜索网站自身全部 token）
route('GET', '/api/search/site', async (req, res) => {
  const u = new URL(req.url, 'http://x');
  const q = (u.searchParams.get('q') || '').trim();
  const limit = Number(u.searchParams.get('size') || 30);
  if (!q) return json(res, 200, { total: 0, items: [], engine: 'empty' });
  try { json(res, 200, { ...searchEngine.searchSite(q, { limit }), q }); }
  catch (e) { json(res, 500, { error: e.message }); }
});
route('GET', '/api/search/stats', async (req, res) => { json(res, 200, searchEngine.siteStats()); });

// 智能问答：检索站内内容 → 喂给 AI 生成回答（无 Key 时优雅降级为检索摘要）
async function askAI(system, userMsg) {
  const provider = getSetting('ai_providers', {});
  const def = getSetting('ai_default_provider', 'deepseek');
  const cfg = provider[def] || {};
  const keys = Array.isArray(cfg.apiKeys) ? cfg.apiKeys : (cfg.apiKey ? [cfg.apiKey] : []);
  const key = keys.length ? keys[Math.floor(Math.random() * keys.length)] : '';
  if (!key || !cfg.baseUrl) return null;
  return new Promise((resolve) => {
    const body = JSON.stringify({ model: cfg.model || 'deepseek-chat', messages: [{ role: 'system', content: system }, { role: 'user', content: userMsg }], max_tokens: 1200 });
    const httpMod = cfg.baseUrl.indexOf('https://') === 0 ? https : http;
    const req2 = httpMod.request(cfg.baseUrl.replace(/\/$/, ''), { method: 'POST', timeout: 45000, headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + key, 'Content-Length': Buffer.byteLength(body) } }, r => { let d = ''; r.on('data', c => d += c); r.on('end', () => { try { const j = JSON.parse(d); resolve(j.choices && j.choices[0] ? j.choices[0].message.content : null); } catch (e) { resolve(null); } }); });
    req2.on('timeout', () => req2.destroy(new Error('timeout')));
    req2.on('error', () => resolve(null));
    req2.end(body);
  });
}
route('GET', '/api/search/ask', async (req, res) => {
  const u2 = new URL(req.url, 'http://x');
  const q = (u2.searchParams.get('q') || '').trim();
  if (!q) return json(res, 200, { answer: '', sources: [] });
  const r = searchEngine.searchSite(q, { limit: 6 });
  const ctx = r.items.map((it, i) => `[${i + 1}]（${it.type}）${it.title}\n${(it.highlight || '').replace(/<[^>]+>/g, '').slice(0, 600)}`).join('\n\n');
  const sources = r.items.map(it => ({ type: it.type, title: it.title, link: it.link }));
  const sys = '你是月亮盔甲（moonarmor.cn）站内搜索智能体。请仅依据下面给出的本站检索资料，用中文简洁准确地回答用户问题；若资料不足以回答，请说明“本站暂未找到相关内容”，不要编造。';
  const ans = await askAI(sys, `用户问题：${q}\n\n本站检索资料：\n${ctx || '（无）'}\n\n请回答：`);
  if (ans) return json(res, 200, { answer: ans, sources, engine: 'ai' });
  // 降级：无 AI Key 时返回拼接摘要
  const fallback = sources.length ? '未配置 AI，以下为站内检索到的相关条目：\n' + sources.map((s, i) => `${i + 1}. [${s.type}] ${s.title}`).join('\n') : '本站暂未找到相关内容。';
  json(res, 200, { answer: fallback, sources, engine: 'search' });
});

// ===== 全站智能体浮窗：流式对话（SSE） =====
function askAIStream(system, userMsg, history, onDelta) {
  return new Promise((resolve, reject) => {
    const provider = getSetting('ai_providers', {});
    const def = getSetting('ai_default_provider', 'deepseek');
    const cfg = provider[def] || {};
    const keys = Array.isArray(cfg.apiKeys) ? cfg.apiKeys : (cfg.apiKey ? [cfg.apiKey] : []);
    const key = keys.length ? keys[Math.floor(Math.random() * keys.length)] : '';
    if (!key || !cfg.baseUrl) return reject(new Error('no-ai-key'));
    const msgs = [{ role: 'system', content: system }];
    if (Array.isArray(history)) history.forEach(h => { if (h && (h.role === 'user' || h.role === 'assistant')) msgs.push({ role: h.role, content: String(h.content || '').slice(0, 800) }); });
    msgs.push({ role: 'user', content: userMsg });
    const body = JSON.stringify({ model: cfg.model || 'deepseek-chat', messages: msgs, stream: true, max_tokens: 1600 });
    const httpMod = cfg.baseUrl.indexOf('https://') === 0 ? https : http;
    const req2 = httpMod.request(cfg.baseUrl.replace(/\/$/, ''), { method: 'POST', timeout: 90000, headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + key, 'Content-Length': Buffer.byteLength(body) } }, r => {
      let buf = '';
      r.on('data', c => {
        buf += c.toString();
        let idx;
        while ((idx = buf.indexOf('\n')) >= 0) {
          const line = buf.slice(0, idx).trim();
          buf = buf.slice(idx + 1);
          if (line.indexOf('data:') !== 0) continue;
          const data = line.slice(5).trim();
          if (!data || data === '[DONE]') continue;
          try {
            const j = JSON.parse(data);
            const d = j.choices && j.choices[0] && j.choices[0].delta && j.choices[0].delta.content;
            if (d) onDelta(d);
          } catch (e) {}
        }
      });
      r.on('end', () => resolve());
    });
    req2.on('timeout', () => req2.destroy(new Error('timeout')));
    req2.on('error', e => reject(e));
    req2.end(body);
  });
}

const AGENT_SYS = '你是月亮盔甲（moonarmor.cn）的全站智能助手。用中文简洁、友好地回答用户问题。你了解本站的主要板块：理论体系（/read）、超级交易所、装修集群（deco）、信用中心、社区、智能体广场等。若用户问题涉及具体功能，引导到对应页面。不确定时直接说明，不要编造。';

route('POST', '/api/agent/chat', async (req, res) => {
  const b = await readBody(req, 20000);
  const msg = String(b.message || '').trim().slice(0, 1000);
  if (!msg) return json(res, 400, { error: '消息不能为空' });
  const history = Array.isArray(b.history) ? b.history : [];
  const ans = await askAI(AGENT_SYS, msg);
  if (ans) return json(res, 200, { answer: ans });
  json(res, 200, { answer: '智能助手暂未配置，请稍后再试。' });
});

route('POST', '/api/agent/chat/stream', async (req, res) => {
  const b = await readBody(req, 20000);
  const msg = String(b.message || '').trim().slice(0, 1000);
  if (!msg) return json(res, 400, { error: '消息不能为空' });
  const history = Array.isArray(b.history) ? b.history : [];
  res.writeHead(200, { 'Content-Type': 'text/event-stream; charset=utf-8', 'Cache-Control': 'no-cache', 'Connection': 'keep-alive', 'X-Accel-Buffering': 'no' });
  const send = (obj) => res.write('data: ' + JSON.stringify(obj) + '\n\n');
  try {
    await askAIStream(AGENT_SYS, msg, history, delta => send({ delta }));
    send({ done: true });
    res.write('data: [DONE]\n\n');
  } catch (e) {
    if (e.message === 'no-ai-key') send({ error: '智能助手暂未配置，请稍后再试。' });
    else send({ error: '连接失败，请稍后重试。' });
  }
  res.end();
});

// ===== 深度思考（F1.2）：章节思考问题 + 我的想法（存库，可公开/私有） =====
route('GET', '/api/read/thoughts', async (req, res) => {
  const u = authUser(req);
  const slug = String((req.url || '').match(/[?&]ch=([^&]+)/)?.[1] || '').slice(0, 80);
  if (!slug) return json(res, 400, { error: '缺少章节' });
  const pub = db.prepare("SELECT id, nickname, question, content, created_at FROM chapter_thoughts WHERE chapter_slug=? AND visibility='public' AND status='visible' ORDER BY id DESC LIMIT 50").all(slug);
  let mine = [];
  if (u) mine = db.prepare('SELECT id, question, content, visibility, created_at FROM chapter_thoughts WHERE chapter_slug=? AND user_id=? ORDER BY id DESC LIMIT 50').all(slug, u.id);
  json(res, 200, { pub, mine, logged: !!u });
});
route('POST', '/api/read/thoughts', async (req, res) => {
  const u = authUser(req); if (!u) return json(res, 401, { error: '请先登录' });
  const b = await readBody(req, 10000);
  const slug = String(b.chapter || '').slice(0, 80);
  const content = String(b.content || '').trim().slice(0, 4000);
  const question = String(b.question || '').slice(0, 500);
  const visibility = b.visibility === 'public' ? 'public' : 'private';
  if (!slug || !content) return json(res, 400, { error: '想法内容不能为空' });
  const r = db.prepare('INSERT INTO chapter_thoughts(chapter_slug,user_id,nickname,question,content,visibility) VALUES(?,?,?,?,?,?)')
    .run(slug, u.id, u.nickname || '', question, content, visibility);
  json(res, 200, { ok: true, id: r.lastInsertRowid });
});
route('POST', '/api/read/thoughts/:id', async (req, res) => {
  const u = authUser(req); if (!u) return json(res, 401, { error: '请先登录' });
  const id = Number(req.params[0]);
  const row = db.prepare('SELECT id, user_id FROM chapter_thoughts WHERE id=?').get(id);
  if (!row || row.user_id !== u.id) return json(res, 404, { error: '不存在' });
  const b = await readBody(req, 10000);
  if (b.delete) { db.prepare('DELETE FROM chapter_thoughts WHERE id=?').run(id); return json(res, 200, { ok: true, deleted: true }); }
  const visibility = b.visibility === 'public' ? 'public' : 'private';
  db.prepare('UPDATE chapter_thoughts SET visibility=? WHERE id=?').run(visibility, id);
  json(res, 200, { ok: true, visibility });
});

// 章节级 AI 问答（F1.3）：仅基于本章正文的 RAG；无 AI Key 时降级为本章相关段落检索
route('POST', '/api/read/ask', async (req, res) => {
  const b = await readBody(req, 8000);
  const slug = String(b.chapter || '').slice(0, 80);
  const q = String(b.question || '').trim().slice(0, 500);
  if (!slug || !q) return json(res, 400, { error: '缺少章节或问题' });
  let ctx = '';
  try {
    const d = bookEngine.loadBook(slug);
    if (d && d.html) {
      const text = String(d.html).replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
      // 关键词窗口：取问题关键词命中最密集的 3 段，每段 ~600 字
      const kws = q.split(/[\s，。？！、；：,.?!;:]+/).filter(w => w.length >= 2).slice(0, 6);
      const scored = [];
      const WIN = 900, STEP = 450;
      for (let i = 0; i < text.length && scored.length < 200; i += STEP) {
        const seg = text.slice(i, i + WIN);
        let s = 0; for (const k of kws) { let idx = seg.indexOf(k); while (idx !== -1) { s++; idx = seg.indexOf(k, idx + 1); } }
        if (s > 0) scored.push({ s, seg });
      }
      ctx = (scored.sort((a, b2) => b2.s - a.s).slice(0, 3).map(x => x.seg).join('\n\n') || text.slice(0, 1500)).slice(0, 4000);
    }
  } catch (e) {}
  if (!ctx) return json(res, 200, { answer: '本章内容加载失败，请稍后再试。', engine: 'none' });
  const sys = '你是月亮盔甲（moonarmor.cn）的章节精读助手。请仅依据给出的本章原文片段，围绕用户问题用中文简洁作答（可分点）；原文不足以回答的部分明确说明"本章未涉及"，不要编造。';
  const ans = await askAI(sys, `本章原文片段：\n${ctx}\n\n读者问题：${q}\n\n请回答：`);
  if (ans) return json(res, 200, { answer: ans, engine: 'ai' });
  // 降级：无 AI Key，返回最相关原文片段
  const fallback = ctx.split('\n\n')[0] || '';
  json(res, 200, { answer: '（未配置 AI，先给你本章最相关的原文段落）\n\n' + fallback.slice(0, 800), engine: 'search' });
});

// 全站帮助智能体：用户遇问题可对话；复用站内检索 + AI（无 Key 降级），并附人工联系方式
route('POST', '/api/help/chat', async (req, res) => {
  const b = await readBody(req, 8000);
  const msg = String((b && b.message) || '').trim().slice(0, 1000);
  const contact = getSetting('help_contact', { email: '18611475369@wo.cn', phone: '18611475369' });
  const contactLine = `\n\n—— 如需人工协助：邮件 ${contact.email}，电话 ${contact.phone}（工作时间回复）。`;
  if (!msg) return json(res, 200, { answer: '请描述你遇到的问题～' + contactLine, contact });
  let ctx = '', sources = [];
  try {
    const r = searchEngine.searchSite(msg, { limit: 5 });
    ctx = r.items.map((it, i) => `[${i + 1}]（${it.type}）${it.title}\n${(it.highlight || '').replace(/<[^>]+>/g, '').slice(0, 400)}`).join('\n\n');
    sources = r.items.map(it => ({ title: it.title, link: it.link }));
  } catch (e) { /* 检索失败不阻断对话 */ }
  const sys = '你是月亮盔甲（moonarmor.cn）的官方帮助助手。用中文简洁、友好地解答用户关于网站使用的问题（阅读、订阅、付费、内容检索、账号、双语切换等）。可参考下方站内资料；资料不足时如实告知，并引导用户联系人工。不要编造事实。';
  const ans = await askAI(sys, `用户问题：${msg}\n\n站内相关资料：\n${ctx || '（无）'}\n\n请回答：`);
  if (ans) return json(res, 200, { answer: ans + contactLine, sources, contact, engine: 'ai' });
  const fb = sources.length ? '（AI 暂未配置，以下是站内找到的相关条目：）\n' + sources.map((s, i) => `${i + 1}. ${s.title}`).join('\n') : '我暂时无法解答该问题，请直接联系人工协助。';
  json(res, 200, { answer: fb + contactLine, sources, contact, engine: 'fallback' });
});


route('GET', '/api/articles/:slug', async (req, res) => {
  const a = db.prepare('SELECT * FROM articles WHERE slug = ?').get(req.params[0]);
  if (!a || a.status !== 'published') return json(res, 404, { error: '文章不存在或未发布' });
  const u = authUser(req);
  // 付费文章：订阅会员畅读；否则检查是否已购
  let locked = false, content = a.content;
  if (a.is_paid) {
    const sub = hasActiveSubscription(u ? u.id : null);
    const bought = u ? db.prepare('SELECT COUNT(*) c FROM orders WHERE article_id = ? AND user_id = ? AND status = \'paid\'').get(a.id, u.id).c : 0;
    if (!sub && !bought) { locked = true; content = content.slice(0, 300) + '\n\n……（以下为付费内容，请订阅会员或购买后阅读）'; }
  }
  const row = articleRow(a, true); row.content = content; row.locked = locked;
  json(res, 200, row);
});

route('POST', '/api/articles/:id/view', async (req, res) => {
  db.prepare('UPDATE articles SET view_count = view_count + 1 WHERE id = ?').run(Number(req.params[0]));
  json(res, 200, { ok: true });
});

// 文章小结/总结提炼智能体：AI 结构化小结（无 Key 降级为抽取式要点）
route('GET', '/api/articles/:slug/summary', async (req, res) => {
  const a = db.prepare('SELECT * FROM articles WHERE slug = ?').get(req.params[0]);
  if (!a || a.status !== 'published') return json(res, 404, { error: '文章不存在或未发布' });
  const u = authUser(req);
  let content = a.content;
  if (a.is_paid) {
    const sub = hasActiveSubscription(u ? u.id : null);
    const bought = u ? db.prepare('SELECT COUNT(*) c FROM orders WHERE article_id = ? AND user_id = ? AND status = \'paid\'').get(a.id, u.id).c : 0;
    if (!sub && !bought) content = content.slice(0, 400); // 付费未解锁：仅用开头片段做公开小结
  }
  const plain = String(content || '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
  // 抽取式降级要点（免费，无大模型）
  const sens = plain.split(/(?<=[。！？!?；;\n])/).map(s => s.trim()).filter(s => s.length >= 12);
  const fallback = {
    summary: a.summary || sens.slice(0, 2).join(''),
    points: sens.slice(0, 5)
  };
  const sys = '你是月亮盔甲的文章小结智能体。请把用户给出的文章正文，提炼成一段不超过150字的核心小结，并列出3-5条要点。只输出 JSON：{"summary":"...","points":["...","..."]}，不要输出多余内容。';
  const usr = '文章标题：' + a.title + '\n\n正文：\n' + plain.slice(0, 4000);
  const ans = await askAI(sys, usr);
  if (ans) {
    try {
      const m = ans.match(/\{[\s\S]*\}/);
      if (m) { const j = JSON.parse(m[0]); if (j.summary) return json(res, 200, { summary: j.summary, points: (j.points || []).slice(0, 5), engine: 'ai' }); }
    } catch (e) {}
    // AI 返回非 JSON：整段当摘要
    return json(res, 200, { summary: String(ans).slice(0, 300), points: fallback.points, engine: 'ai' });
  }
  json(res, 200, { ...fallback, engine: 'extractive' });
});

route('GET', '/api/articles/:id/comments', async (req, res) => {
  const rows = db.prepare('SELECT id, nickname, content, created_at FROM comments WHERE article_id = ? AND status = \'visible\' ORDER BY id DESC LIMIT 200').all(Number(req.params[0]));
  json(res, 200, rows);
});

route('GET', '/api/articles/:id/rating', async (req, res) => {
  const id = Number(req.params[0]);
  const a = db.prepare('SELECT rating_sum, rating_count FROM articles WHERE id = ?').get(id);
  if (!a) return json(res, 404, { error: 'not found' });
  const user = authUser(req);
  const mine = user ? db.prepare('SELECT score FROM ratings WHERE article_id = ? AND user_id = ?').get(id, user.id) : null;
  const liked = user ? !!db.prepare('SELECT id FROM likes WHERE article_id = ? AND user_id = ?').get(id, user.id) : false;
  json(res, 200, { avg: a.rating_count ? Math.round((a.rating_sum / a.rating_count) * 10) / 10 : 0, count: a.rating_count, mine: mine ? mine.score : 0, liked });
});

route('POST', '/api/articles/:id/like', async (req, res) => {
  const user = authUser(req); if (!user) return json(res, 401, { error: '请先登录' });
  const id = Number(req.params[0]);
  if (!db.prepare('SELECT id FROM articles WHERE id = ?').get(id)) return json(res, 404, { error: 'not found' });
  const existing = db.prepare('SELECT id FROM likes WHERE article_id = ? AND user_id = ?').get(id, user.id);
  if (existing) { db.prepare('DELETE FROM likes WHERE id = ?').run(existing.id); db.prepare('UPDATE articles SET like_count = MAX(0, like_count - 1) WHERE id = ?').run(id); return json(res, 200, { liked: false, like_count: db.prepare('SELECT like_count FROM articles WHERE id = ?').get(id).like_count }); }
  db.prepare("INSERT INTO likes (article_id, target_type, target_id, user_id) VALUES (?, 'article', ?, ?)").run(id, String(id), user.id);
  db.prepare('UPDATE articles SET like_count = like_count + 1 WHERE id = ?').run(id);
  json(res, 200, { liked: true, like_count: db.prepare('SELECT like_count FROM articles WHERE id = ?').get(id).like_count });
});

// ===== 通用点赞（支持 article / chapter 等目标类型）=====
route('GET', '/api/like', async (req, res) => {
  const u = new URL(req.url, 'http://x');
  const targetType = String(u.searchParams.get('target_type') || 'article');
  const targetId = String(u.searchParams.get('target_id') || '');
  if (!targetId) return json(res, 400, { error: '缺少 target_id' });
  const user = authUser(req);
  const liked = user ? !!db.prepare('SELECT id FROM likes WHERE target_type = ? AND target_id = ? AND user_id = ?').get(targetType, targetId, user.id) : false;
  const count = db.prepare('SELECT COUNT(*) c FROM likes WHERE target_type = ? AND target_id = ?').get(targetType, targetId).c;
  json(res, 200, { liked, count });
});
route('POST', '/api/like', async (req, res) => {
  const user = authUser(req); if (!user) return json(res, 401, { error: '请先登录' });
  try {
    const b = await readBody(req, 1e4);
    const targetType = String(b.target_type || 'article');
    const targetId = String(b.target_id || '');
    if (!targetId) return json(res, 400, { error: '缺少 target_id' });
    const existing = db.prepare('SELECT id FROM likes WHERE target_type = ? AND target_id = ? AND user_id = ?').get(targetType, targetId, user.id);
    if (existing) {
      db.prepare('DELETE FROM likes WHERE id = ?').run(existing.id);
      if (targetType === 'article') { const aid = Number(targetId); if (aid) db.prepare('UPDATE articles SET like_count = MAX(0, like_count - 1) WHERE id = ?').run(aid); }
      const count = db.prepare('SELECT COUNT(*) c FROM likes WHERE target_type = ? AND target_id = ?').get(targetType, targetId).c;
      return json(res, 200, { liked: false, count });
    }
    const articleId = targetType === 'article' ? Number(targetId) || 0 : 0;
    db.prepare('INSERT INTO likes (article_id, target_type, target_id, user_id) VALUES (?, ?, ?, ?)').run(articleId, targetType, targetId, user.id);
    if (targetType === 'article' && articleId) db.prepare('UPDATE articles SET like_count = like_count + 1 WHERE id = ?').run(articleId);
    const count = db.prepare('SELECT COUNT(*) c FROM likes WHERE target_type = ? AND target_id = ?').get(targetType, targetId).c;
    json(res, 200, { liked: true, count });
  } catch (e) { json(res, 500, { error: e.message }); }
});

route('POST', '/api/articles/:id/rate', async (req, res) => {
  const user = authUser(req); if (!user) return json(res, 401, { error: '请先登录' });
  const b = await readBody(req, 1e4);
  const score = Math.round(Number(b.score));
  if (score < 1 || score > 5) return json(res, 400, { error: '评分需为1-5' });
  const id = Number(req.params[0]);
  const a = db.prepare('SELECT * FROM articles WHERE id = ?').get(id);
  if (!a) return json(res, 404, { error: 'not found' });
  const old = db.prepare('SELECT score FROM ratings WHERE article_id = ? AND user_id = ?').get(id, user.id);
  if (old) db.prepare('UPDATE ratings SET score = ? WHERE article_id = ? AND user_id = ?').run(score, id, user.id);
  else db.prepare('INSERT INTO ratings (article_id, user_id, score) VALUES (?, ?, ?)').run(id, user.id, score);
  const delta = old ? score - old.score : score;
  db.prepare('UPDATE articles SET rating_sum = rating_sum + ?, rating_count = rating_count + ? WHERE id = ?').run(delta, old ? 0 : 1, id);
  json(res, 200, { ok: true, avg: Math.round(((a.rating_sum + delta) / (a.rating_count + (old ? 0 : 1))) * 10) / 10 });
});

route('GET', '/api/keywords', async (req, res) => {
  json(res, 200, db.prepare('SELECT id, term, target_type, target_id FROM keywords ORDER BY length(term) DESC').all());
});

route('GET', '/api/categories/:id/comments', async (req, res) => {
  const cid = Number(req.params[0]);
  const c = db.prepare('SELECT * FROM categories WHERE id = ?').get(cid);
  if (!c) return json(res, 404, { error: 'not found' });
  const col = 'cat' + c.level + '_id';
  const arts = db.prepare('SELECT id, title FROM articles WHERE ' + col + ' = ? AND status = \'published\'').all(cid);
  const rows = [];
  for (const a of arts) {
    const cs = db.prepare('SELECT c.id, c.nickname, c.content, c.created_at, c.article_id, a.title, a.slug FROM comments c JOIN articles a ON a.id = c.article_id WHERE c.article_id = ? AND c.status = \'visible\' ORDER BY c.id DESC LIMIT 50').all(a.id);
    rows.push(...cs);
  }
  rows.sort((x, y) => String(y.created_at).localeCompare(String(x.created_at)));
  json(res, 200, { category: c, articles: arts, comments: rows.slice(0, 200) });
});

route('GET', '/api/governance', async (req, res) => {
  const docs = db.prepare('SELECT * FROM governance_docs WHERE status = \'published\' ORDER BY doc_type, id DESC').all();
  const pool = db.prepare('SELECT COALESCE(SUM(pool_amount),0) s, COUNT(*) c FROM dividend_ledger').get();
  const revisions = db.prepare('SELECT COUNT(*) c FROM revision_suggestions').get().c;
  const pendingRev = db.prepare('SELECT COUNT(*) c FROM revision_suggestions WHERE status = \'pending\'').get().c;
  const ledger = db.prepare('SELECT * FROM dividend_ledger ORDER BY id DESC LIMIT 30').all();
  json(res, 200, { docs, pool: pool.s, pool_entries: pool.c, revisions, pending_revisions: pendingRev, ledger });
});
// 别名：文档命名 /api/governance/docs（治理文档列表）
route('GET', '/api/governance/docs', async (req, res) => {
  const docs = db.prepare('SELECT * FROM governance_docs WHERE status = \'published\' ORDER BY doc_type, id DESC').all();
  json(res, 200, { success: true, total: docs.length, docs });
});

route('GET', '/api/calendar', async (req, res) => {
  const u = new URL(req.url, 'http://x');
  const m = u.searchParams.get('month') || new Date().toISOString().slice(0, 7);
  const rows = db.prepare('SELECT id, title, slug, status, published_at, schedule_at FROM articles WHERE (published_at LIKE ? OR schedule_at LIKE ? OR published_at IS NULL AND schedule_at LIKE ?) ORDER BY COALESCE(schedule_at, published_at)').all(m + '%', m + '%', m + '%');
  json(res, 200, rows);
});

route('POST', '/api/admin/articles/:id/schedule', async (req, res) => {
  const u = authUser(req); if (!u || !['admin', 'core'].includes(u.role)) return json(res, 403, { error: '无权限' });
  const b = await readBody(req, 1e4);
  const dt = String(b.schedule_at || '');
  if (!/^\d{4}-\d{2}-\d{2}( \d{2}:\d{2})?$/.test(dt)) return json(res, 400, { error: '时间格式错误，如 2026-08-28 10:00' });
  db.prepare('UPDATE articles SET schedule_at = ? WHERE id = ?').run(dt, Number(req.params[0]));
  json(res, 200, { ok: true });
});

route('POST', '/api/admin/governance', async (req, res) => {
  const u = authUser(req); if (!u || u.role !== 'admin') return json(res, 403, { error: '无权限' });
  const b = await readBody(req, 1e6);
  if (!b.title || !['pact', 'audit', 'notice'].includes(b.doc_type)) return json(res, 400, { error: '参数不完整' });
  db.prepare('INSERT INTO governance_docs (doc_type, title, content, status) VALUES (?, ?, ?, ?)').run(b.doc_type, String(b.title), String(b.content || ''), b.status || 'published');
  json(res, 200, { ok: true });
});

route('GET', '/api/admin/governance', async (req, res) => {
  const u = authUser(req); if (!u || u.role !== 'admin') return json(res, 403, { error: '无权限' });
  json(res, 200, db.prepare('SELECT * FROM governance_docs ORDER BY id DESC').all());
});

// ---------- 平台费率档位（sHRmatch） ----------
function feePlanRow(p, userVote) {
  return { id: p.id, name: p.name, mode: p.mode, per_trade_price: p.per_trade_price, income_ratio: p.income_ratio, description: p.description, is_default: p.is_default, sort_order: p.sort_order, status: p.status, votes: userVote };
}

route('GET', '/api/fee-plans', async (req, res) => {
  const rows = db.prepare('SELECT * FROM fee_plans WHERE status = \'on\' ORDER BY sort_order, id').all();
  const u = authUser(req);
  const out = rows.map(p => {
    const v = db.prepare('SELECT COUNT(*) c, SUM(CASE WHEN vote = \'approve\' THEN 1 ELSE 0 END) a, SUM(CASE WHEN vote = \'reject\' THEN 1 ELSE 0 END) r, SUM(CASE WHEN vote = \'abstain\' THEN 1 ELSE 0 END) ab FROM governance_votes WHERE proposal_type = \'fee_plan\' AND proposal_id = ?').get(p.id);
    let myVote = null;
    if (u) { const mv = db.prepare('SELECT vote FROM governance_votes WHERE proposal_type = \'fee_plan\' AND proposal_id = ? AND user_id = ?').get(p.id, u.id); if (mv) myVote = mv.vote; }
    return feePlanRow(p, { total: v.c, approve: v.a || 0, reject: v.r || 0, abstain: v.ab || 0, mine: myVote });
  });
  json(res, 200, out);
});

route('POST', '/api/admin/fee-plans', async (req, res) => {
  const u = authUser(req); if (!u || u.role !== 'admin') return json(res, 403, { error: '无权限' });
  const b = await readBody(req, 1e5);
  if (!b.name || !['per_trade', 'per_income', 'hybrid'].includes(b.mode)) return json(res, 400, { error: '参数不完整' });
  const r = db.prepare('INSERT INTO fee_plans (name, mode, per_trade_price, income_ratio, description, is_default, sort_order) VALUES (?, ?, ?, ?, ?, ?, ?)')
    .run(String(b.name), String(b.mode), Number(b.per_trade_price || 0), Number(b.income_ratio || 0), String(b.description || ''), b.is_default ? 1 : 0, Number(b.sort_order || 0));
  json(res, 200, { ok: true, id: Number(r.lastInsertRowid) });
});

route('PUT', '/api/admin/fee-plans/:id', async (req, res) => {
  const u = authUser(req); if (!u || u.role !== 'admin') return json(res, 403, { error: '无权限' });
  const b = await readBody(req, 1e5);
  const id = Number(req.params[0]);
  const p = db.prepare('SELECT * FROM fee_plans WHERE id = ?').get(id);
  if (!p) return json(res, 404, { error: 'not found' });
  db.prepare('UPDATE fee_plans SET name = ?, mode = ?, per_trade_price = ?, income_ratio = ?, description = ?, is_default = ?, sort_order = ?, status = ?, updated_at = datetime(\'now\',\'localtime\') WHERE id = ?')
    .run(String(b.name ?? p.name), String(b.mode ?? p.mode), Number(b.per_trade_price ?? p.per_trade_price), Number(b.income_ratio ?? p.income_ratio), String(b.description ?? p.description), b.is_default ?? p.is_default, Number(b.sort_order ?? p.sort_order), String(b.status ?? p.status), id);
  json(res, 200, { ok: true });
});

// 用户自选费率档位
route('POST', '/api/me/fee-plan', async (req, res) => {
  const u = authUser(req); if (!u) return json(res, 401, { error: '请先登录' });
  const b = await readBody(req, 1e5);
  const planId = Number(b.plan_id);
  const p = db.prepare('SELECT * FROM fee_plans WHERE id = ? AND status = \'on\'').get(planId);
  if (!p) return json(res, 404, { error: '档位不存在' });
  db.prepare('INSERT INTO user_fee_plans (user_id, plan_id, chosen_reason, chosen_by) VALUES (?, ?, ?, ?) ON CONFLICT(user_id) DO UPDATE SET plan_id = excluded.plan_id, chosen_reason = excluded.chosen_reason, chosen_by = excluded.chosen_by, updated_at = datetime(\'now\',\'localtime\')')
    .run(u.id, planId, String(b.reason || ''), String(b.chosen_by || 'user'));
  json(res, 200, { ok: true, plan: feePlanRow(p, null) });
});

route('GET', '/api/me/fee-plan', async (req, res) => {
  const u = authUser(req); if (!u) return json(res, 401, { error: '请先登录' });
  const uf = db.prepare('SELECT * FROM user_fee_plans WHERE user_id = ?').get(u.id);
  if (!uf) return json(res, 200, { chosen: null, plan: null });
  const p = db.prepare('SELECT * FROM fee_plans WHERE id = ?').get(uf.plan_id);
  json(res, 200, { chosen: { plan_id: uf.plan_id, reason: uf.chosen_reason, chosen_by: uf.chosen_by }, plan: p ? feePlanRow(p, null) : null });
});

// 治理投票（费率档位/公约/规则）
route('POST', '/api/governance/vote', async (req, res) => {
  const u = authUser(req); if (!u) return json(res, 401, { error: '请先登录' });
  const b = await readBody(req, 1e5);
  const pt = String(b.proposal_type || 'fee_plan');
  const pid = Number(b.proposal_id || 0);
  const vote = ['approve', 'reject', 'abstain'].includes(b.vote) ? b.vote : 'approve';
  db.prepare('INSERT INTO governance_votes (proposal_type, proposal_id, user_id, vote, note) VALUES (?, ?, ?, ?, ?) ON CONFLICT(proposal_type, proposal_id, user_id) DO UPDATE SET vote = excluded.vote, note = excluded.note, created_at = datetime(\'now\',\'localtime\')')
    .run(pt, pid, u.id, vote, String(b.note || ''));
  const v = db.prepare('SELECT COUNT(*) c, SUM(CASE WHEN vote = \'approve\' THEN 1 ELSE 0 END) a, SUM(CASE WHEN vote = \'reject\' THEN 1 ELSE 0 END) r, SUM(CASE WHEN vote = \'abstain\' THEN 1 ELSE 0 END) ab FROM governance_votes WHERE proposal_type = ? AND proposal_id = ?').get(pt, pid);
  json(res, 200, { ok: true, tally: { total: v.c, approve: v.a || 0, reject: v.r || 0, abstain: v.ab || 0, mine: vote } });
});

// 智能体参谋：根据用户画像推荐费率档位
route('POST', '/api/agents/fee-advice', async (req, res) => {
  const u = authUser(req); if (!u) return json(res, 401, { error: '请先登录' });
  const b = await readBody(req, 1e5);
  const plans = db.prepare('SELECT * FROM fee_plans WHERE status = \'on\' ORDER BY sort_order, id').all();
  if (!plans.length) return json(res, 200, { advice: null, reason: '暂无可用档位' });
  // 简单规则参谋：有订单历史则按历史金额倾向，否则推荐默认档；真实 AI 可后续接入
  const orderStats = db.prepare('SELECT COUNT(*) c, COALESCE(SUM(amount),0) s FROM orders WHERE user_id = ? AND status = \'paid\'').get(u.id);
  const tipStats = db.prepare('SELECT COUNT(*) c, COALESCE(SUM(amount),0) s FROM tips WHERE user_id = ? AND status = \'paid\'').get(u.id);
  const totalEarn = (orderStats.s || 0) + (tipStats.s || 0);
  const totalTrades = (orderStats.c || 0) + (tipStats.c || 0);
  let pick = plans.find(p => p.is_default) || plans[0];
  let reason = '你暂无成交记录，推荐默认档位「' + pick.name + '」起步。';
  if (totalTrades > 0) {
    // 按收益档 vs 按次档的成本比较：按次成本 = 次数 * per_trade_price；按收益成本 = 收益 * income_ratio/1000
    const perTrade = plans.filter(p => p.mode === 'per_trade' || p.mode === 'hybrid').sort((a, b) => a.per_trade_price - b.per_trade_price)[0];
    const perIncome = plans.filter(p => p.mode === 'per_income' || p.mode === 'hybrid').sort((a, b) => a.income_ratio - b.income_ratio)[0];
    if (perTrade && perIncome && totalEarn > 0) {
      const costTrade = totalTrades * perTrade.per_trade_price;
      const costIncome = totalEarn * perIncome.income_ratio / 1000;
      pick = costTrade <= costIncome ? perTrade : perIncome;
      reason = '你有 ' + totalTrades + ' 笔成交、累计收益 ¥' + totalEarn.toFixed(2) + '。按次档成本约 ¥' + costTrade.toFixed(2) + '，按收益档成本约 ¥' + costIncome.toFixed(2) + '，故推荐「' + pick.name + '」。';
    }
  }
  // 执行调整：auto_apply=true 时，智能体自动为用户切换到推荐档位
  let applied = false;
  if (b.auto_apply) {
    db.prepare('INSERT INTO user_fee_plans (user_id, plan_id, chosen_reason, chosen_by) VALUES (?, ?, ?, ?) ON CONFLICT(user_id) DO UPDATE SET plan_id = excluded.plan_id, chosen_reason = excluded.chosen_reason, chosen_by = excluded.chosen_by, updated_at = datetime(\'now\',\'localtime\')')
      .run(u.id, pick.id, '智能体执行调整：' + reason, 'agent');
    applied = true;
  }
  json(res, 200, { advice: feePlanRow(pick, null), reason, applied, total_trades: totalTrades, total_earn: totalEarn });
});

// ---------- sHRmatch 用户自主上架产品（生态撮合） ----------
function listingRow(l) {
  return { id: l.id, designer_id: l.designer_id, title: l.title, category: l.category, variety_code: l.variety_code, base_asset: l.base_asset, description: l.description, price: l.price, unit: l.unit, supply_qty: l.supply_qty, commission_ratio: l.commission_ratio, designer_ratio: l.designer_ratio, score: l.score, status: l.status, reject_reason: l.reject_reason, metrics: JSON.parse(l.metrics || '{}'), created_at: l.created_at, updated_at: l.updated_at };
}

// 上架申请
route('POST', '/api/listings', async (req, res) => {
  const u = authUser(req); if (!u) return json(res, 401, { error: '请先登录' });
  const b = await readBody(req, 1e6);
  if (!b.title || !b.category || !(b.price >= 0)) return json(res, 400, { error: '标题/品类/价格必填' });
  const cats = ['labor', 'product', 'institution', 'index', 'service', 'fund'];
  if (!cats.includes(b.category)) return json(res, 400, { error: '品类无效' });
  const ratio = Math.min(0.5, Math.max(0, Number(b.commission_ratio ?? 0.1))); // 平台分成上限 50%
  const r = db.prepare('INSERT INTO listings (designer_id, title, category, variety_code, base_asset, description, price, unit, supply_qty, commission_ratio, designer_ratio, status, metrics) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, \'pending\', ?)')
    .run(u.id, String(b.title).slice(0, 120), String(b.category), String(b.variety_code || ''), String(b.base_asset || ''), String(b.description || ''), Math.round(Number(b.price) * 100) / 100, String(b.unit || '份'), Number(b.supply_qty || 0), ratio, Math.round((1 - ratio) * 1000) / 1000, JSON.stringify({ submit_note: String(b.submit_note || '').slice(0, 300) }));
  json(res, 200, { ok: true, id: Number(r.lastInsertRowid), status: 'pending' });
});

// 我的上架（设计者视角）
route('GET', '/api/me/listings', async (req, res) => {
  const u = authUser(req); if (!u) return json(res, 401, { error: '请先登录' });
  const rows = db.prepare('SELECT * FROM listings WHERE designer_id = ? ORDER BY id DESC').all(u.id);
  json(res, 200, rows.map(listingRow));
});

// 公开上架列表（撮合大厅）
route('GET', '/api/listings', async (req, res) => {
  const u = new URL(req.url, 'http://x');
  const cat = u.searchParams.get('category') || '';
  const where = cat ? 'WHERE status = \'on\' AND category = ?' : 'WHERE status = \'on\'';
  const rows = cat ? db.prepare('SELECT * FROM listings ' + where + ' ORDER BY score DESC, id DESC').all(cat) : db.prepare('SELECT * FROM listings ' + where + ' ORDER BY score DESC, id DESC').all();
  json(res, 200, rows.map(listingRow));
});

// 上架详情（含历史成交 + 指标序列）
route('GET', '/api/listings/:id', async (req, res) => {
  const l = db.prepare('SELECT * FROM listings WHERE id = ?').get(Number(req.params[0]));
  if (!l) return json(res, 404, { error: 'not found' });
  const d = db.prepare('SELECT id, nickname, avatar FROM users WHERE id = ?').get(l.designer_id);
  const m = db.prepare('SELECT * FROM listing_metrics WHERE listing_id = ? ORDER BY id DESC LIMIT 1').get(l.id);
  const trades = db.prepare('SELECT lt.id, lt.qty, lt.amount, lt.status, lt.rating, lt.complaint, lt.created_at, u.nickname FROM listing_trades lt LEFT JOIN users u ON u.id = lt.buyer_id WHERE lt.listing_id = ? AND lt.status = \'settled\' ORDER BY lt.id DESC LIMIT 50').all(l.id);
  const metricsHist = db.prepare('SELECT period, trade_count, trade_volume, buyer_count, return_rate, rating_avg, complaint_count, score FROM listing_metrics WHERE listing_id = ? ORDER BY period ASC').all(l.id);
  json(res, 200, { ...listingRow(l), designer: d ? { nickname: d.nickname, avatar: d.avatar } : null, latest_metrics: m, trades, metrics_hist: metricsHist });
});

// 撮合成交结算：更新成交指标 + 复购率
function settleListingTrade(orderNo) {
  const t = db.prepare('SELECT * FROM listing_trades WHERE order_no = ?').get(orderNo);
  if (!t || t.status === 'settled') return t;
  db.prepare('UPDATE listing_trades SET status = \'settled\', settled_at = datetime(\'now\',\'localtime\') WHERE order_no = ?').run(orderNo);
  const l = db.prepare('SELECT * FROM listings WHERE id = ?').get(t.listing_id);
  if (!l) return db.prepare('SELECT * FROM listing_trades WHERE order_no = ?').get(orderNo);
  const period = new Date().toISOString().slice(0, 7);
  let m = db.prepare('SELECT * FROM listing_metrics WHERE listing_id = ? AND period = ? ORDER BY id DESC LIMIT 1').get(l.id, period);
  if (!m) {
    db.prepare('INSERT INTO listing_metrics (listing_id, trade_count, trade_volume, buyer_count, return_rate, period, period_start) VALUES (?, 0, 0, 0, 0, ?, ?)').run(l.id, period, period);
    m = db.prepare('SELECT * FROM listing_metrics WHERE listing_id = ? AND period = ? ORDER BY id DESC LIMIT 1').get(l.id, period);
  }
  // 复购率：该买家在本listing的历史成交数 > 1 即算复购
  const prev = db.prepare('SELECT COUNT(*) c FROM listing_trades WHERE listing_id = ? AND buyer_id = ? AND status = \'settled\'').get(l.id, t.buyer_id).c;
  const isReturn = prev > 1;
  db.prepare('UPDATE listing_metrics SET trade_count = trade_count + 1, trade_volume = trade_volume + ?, buyer_count = buyer_count + (CASE WHEN ? THEN 0 ELSE 1 END), return_rate = ?, updated_at = datetime(\'now\',\'localtime\') WHERE id = ?')
    .run(t.amount, isReturn ? 1 : 0, isReturn ? 1 : 0, m.id);
  return db.prepare('SELECT * FROM listing_trades WHERE order_no = ?').get(orderNo);
}

// 撮合成交（买家下单）
route('POST', '/api/listings/:id/trade', async (req, res) => {
  const u = authUser(req); if (!u) return json(res, 401, { error: '请先登录' });
  const l = db.prepare('SELECT * FROM listings WHERE id = ? AND status = \'on\'').get(Number(req.params[0]));
  if (!l) return json(res, 404, { error: '该产品未上架或不存在' });
  const b = await readBody(req, 1e5);
  const qty = Math.max(1, Number(b.qty || 1));
  if (l.supply_qty > 0 && qty > l.supply_qty) return json(res, 400, { error: '库存不足' });
  const amount = Math.round(l.price * qty * 100) / 100;
  if (amount <= 0) return json(res, 400, { error: '金额无效' });
  const commission = Math.round(amount * l.commission_ratio * 100) / 100;
  const designerAmt = Math.round((amount - commission) * 100) / 100;
  const no = orderNo('LST');
  db.prepare('INSERT INTO listing_trades (listing_id, buyer_id, designer_id, qty, amount, commission_amount, designer_amount, status, order_no) VALUES (?, ?, ?, ?, ?, ?, ?, \'pending\', ?)')
    .run(l.id, u.id, l.designer_id, qty, amount, commission, designerAmt, no);
  const payMode = getSetting('payment_mode', 'simulate');
  if (payMode === 'simulate') {
    settleListingTrade(no);
    return json(res, 200, { ok: true, order_no: no, status: 'settled', amount, commission, designer_amount: designerAmt });
  }
  if (payMode === 'alipay') {
    const form = pay.buildPagePayForm(no, 'sHRmatch 撮合·' + l.title, amount);
    return json(res, 200, { ok: true, order_no: no, status: 'pending', amount, pay_url: form.url || null, redirect: !!form.url });
  }
  json(res, 200, { ok: true, order_no: no, status: 'pending', amount });
});

// 设计者收益（我的分成）
route('GET', '/api/me/listing-income', async (req, res) => {
  const u = authUser(req); if (!u) return json(res, 401, { error: '请先登录' });
  const rows = db.prepare('SELECT lt.*, l.title FROM listing_trades lt JOIN listings l ON l.id = lt.listing_id WHERE lt.designer_id = ? ORDER BY lt.id DESC').all(u.id);
  const total = db.prepare('SELECT COALESCE(SUM(designer_amount),0) s, COUNT(*) c FROM listing_trades WHERE designer_id = ? AND status = \'settled\'').get(u.id);
  json(res, 200, { total_settled: total.s, settled_count: total.c, trades: rows });
});

// 买家评价 + 投诉（成交后，支撑考核指标）
route('POST', '/api/listings/trades/:orderNo/rate', async (req, res) => {
  const u = authUser(req); if (!u) return json(res, 401, { error: '请先登录' });
  const t = db.prepare('SELECT * FROM listing_trades WHERE order_no = ?').get(req.params[0]);
  if (!t) return json(res, 404, { error: '订单不存在' });
  if (t.buyer_id !== u.id) return json(res, 403, { error: '只能评价自己的订单' });
  if (t.status !== 'settled') return json(res, 400, { error: '订单未结算，暂不可评价' });
  const b = await readBody(req, 1e5);
  const rating = Math.max(1, Math.min(5, Number(b.rating || 5)));
  const complaint = b.complaint ? 1 : 0;
  db.prepare('UPDATE listing_trades SET rating = ?, complaint = ?, rating_note = ? WHERE order_no = ?').run(rating, complaint, String(b.note || '').slice(0, 200), t.order_no);
  const period = new Date().toISOString().slice(0, 7);
  let m = db.prepare('SELECT * FROM listing_metrics WHERE listing_id = ? AND period = ? ORDER BY id DESC LIMIT 1').get(t.listing_id, period);
  if (!m) { db.prepare('INSERT INTO listing_metrics (listing_id, trade_count, trade_volume, buyer_count, return_rate, rating_avg, complaint_count, period, period_start) VALUES (?, 0, 0, 0, 0, 0, 0, ?, ?)').run(t.listing_id, period, period); m = db.prepare('SELECT * FROM listing_metrics WHERE listing_id = ? AND period = ? ORDER BY id DESC LIMIT 1').get(t.listing_id, period); }
  const agg = db.prepare('SELECT COALESCE(AVG(rating),0) av, COALESCE(SUM(complaint),0) cp FROM listing_trades WHERE listing_id = ? AND status = \'settled\' AND rating > 0').get(t.listing_id);
  db.prepare('UPDATE listing_metrics SET rating_avg = ?, complaint_count = ?, updated_at = datetime(\'now\',\'localtime\') WHERE id = ?').run(Math.round(agg.av * 10) / 10, agg.cp || 0, m.id);
  json(res, 200, { ok: true });
});

// 买家我的成交（可评价列表）
route('GET', '/api/me/listing-trades', async (req, res) => {
  const u = authUser(req); if (!u) return json(res, 401, { error: '请先登录' });
  const rows = db.prepare('SELECT lt.*, l.title, l.category FROM listing_trades lt JOIN listings l ON l.id = lt.listing_id WHERE lt.buyer_id = ? ORDER BY lt.id DESC').all(u.id);
  json(res, 200, rows);
});

// 考核打分（可复用：管理员手动 / 定时自动）
function computeListingScore(id) {
  const l = db.prepare('SELECT * FROM listings WHERE id = ?').get(id);
  if (!l) return null;
  const m = db.prepare('SELECT * FROM listing_metrics WHERE listing_id = ? ORDER BY id DESC LIMIT 1').get(id);
  const tradeScore = m && m.trade_count > 0 ? Math.min(100, m.trade_count * 10) : 0;
  const buyerScore = m && m.buyer_count > 0 ? Math.min(100, m.buyer_count * 15) : 0;
  const returnScore = Math.min(100, (m ? m.return_rate : 0) * 100);
  const ratingScore = Math.min(100, (m ? m.rating_avg : 0) * 20);
  const complaintScore = m && m.complaint_count > 0 ? Math.max(0, 100 - m.complaint_count * 20) : 100;
  const total = Math.round((tradeScore * 0.3 + buyerScore * 0.2 + returnScore * 0.2 + ratingScore * 0.2 + complaintScore * 0.1) * 10) / 10;
  db.prepare('UPDATE listings SET score = ?, metrics = ?, updated_at = datetime(\'now\',\'localtime\') WHERE id = ?').run(total, JSON.stringify({ tradeScore, buyerScore, returnScore, ratingScore, complaintScore }), id);
  return { score: total, breakdown: { tradeScore, buyerScore, returnScore, ratingScore, complaintScore } };
}

// 定时自动考核：每天对在架产品算分，跌破阈值自动下架并通知设计者
function runListingAssessment() {
  const threshold = Number(getSetting('listing_score_threshold', 40));
  const rows = db.prepare('SELECT * FROM listings WHERE status = \'on\'').all();
  for (const l of rows) {
    try {
      const r = computeListingScore(l.id);
      if (r && r.score < threshold) {
        db.prepare('UPDATE listings SET status = \'off\', reject_reason = ?, updated_at = datetime(\'now\',\'localtime\') WHERE id = ?').run('考核不达标：综合分 ' + r.score + ' 低于阈值 ' + threshold, l.id);
        db.prepare('INSERT INTO notifications (user_id, type, title, content, link) VALUES (?, \'system\', ?, ?, ?)').run(l.designer_id, '你的上架产品已自动下架', '「' + l.title + '」综合分 ' + r.score + ' 低于阈值 ' + threshold + '，已自动下架。', '/shrmatch.html');
        console.log('[listing] auto-delisted', l.id, l.title, 'score=' + r.score);
      }
    } catch (e) { console.log('[listing] assess fail', l.id, e.message); }
  }
}

// 管理员：审核上架/下架 + 考核
route('GET', '/api/admin/listings', async (req, res) => {
  const u = authUser(req); if (!u || !['admin', 'core'].includes(u.role)) return json(res, 403, { error: '无权限' });
  json(res, 200, db.prepare('SELECT * FROM listings ORDER BY CASE status WHEN \'pending\' THEN 0 WHEN \'on\' THEN 1 WHEN \'off\' THEN 2 ELSE 3 END, id DESC').all().map(listingRow));
});

route('POST', '/api/admin/listings/:id/status', async (req, res) => {
  const u = authUser(req); if (!u || !['admin', 'core'].includes(u.role)) return json(res, 403, { error: '无权限' });
  const b = await readBody(req, 1e5);
  const id = Number(req.params[0]);
  const l = db.prepare('SELECT * FROM listings WHERE id = ?').get(id);
  if (!l) return json(res, 404, { error: 'not found' });
  const st = String(b.status || '');
  if (!['on', 'off', 'rejected'].includes(st)) return json(res, 400, { error: '状态无效' });
  const reason = String(b.reason || '');
  db.prepare('UPDATE listings SET status = ?, reject_reason = ?, updated_at = datetime(\'now\',\'localtime\') WHERE id = ?').run(st, reason, id);
  // 通知设计者
  db.prepare('INSERT INTO notifications (user_id, type, title, content, link) VALUES (?, \'system\', ?, ?, ?)').run(l.designer_id, '你的上架产品「' + l.title + '」状态更新', (st === 'on' ? '已上架，开始生态撮合' : st === 'off' ? '已下架：' + reason : '未通过：' + reason), '/shrmatch.html');
  json(res, 200, { ok: true });
});

// 指标考核（管理员触发打分）
route('POST', '/api/admin/listings/:id/score', async (req, res) => {
  const u = authUser(req); if (!u || !['admin', 'core'].includes(u.role)) return json(res, 403, { error: '无权限' });
  const r = computeListingScore(Number(req.params[0]));
  if (!r) return json(res, 404, { error: 'not found' });
  json(res, 200, { ok: true, score: r.score, breakdown: r.breakdown });
});

// ---------- 订阅会员（文章类付费） ----------
function subPlanRow(p) { return { id: p.id, name: p.name, period_days: p.period_days, price: p.price, original_price: p.original_price, description: p.description, badge: p.badge, status: p.status, sort_order: p.sort_order }; }

route('GET', '/api/subscription-plans', async (req, res) => {
  json(res, 200, db.prepare('SELECT * FROM subscription_plans WHERE status = \'on\' ORDER BY sort_order, id').all().map(subPlanRow));
});

route('POST', '/api/admin/subscription-plans', async (req, res) => {
  const u = authUser(req); if (!u || u.role !== 'admin') return json(res, 403, { error: '无权限' });
  const b = await readBody(req, 1e5);
  if (!b.name || !b.period_days || !(b.price >= 0)) return json(res, 400, { error: '参数不完整' });
  const r = db.prepare('INSERT INTO subscription_plans (name, period_days, price, original_price, description, badge, sort_order) VALUES (?, ?, ?, ?, ?, ?, ?)')
    .run(String(b.name), Number(b.period_days), Number(b.price), Number(b.original_price || 0), String(b.description || ''), String(b.badge || ''), Number(b.sort_order || 0));
  json(res, 200, { ok: true, id: Number(r.lastInsertRowid) });
});

// 开通/续费订阅（三通道）
route('POST', '/api/subscriptions', async (req, res) => {
  const u = authUser(req); if (!u) return json(res, 401, { error: '请先登录' });
  const b = await readBody(req, 1e5);
  const plan = db.prepare('SELECT * FROM subscription_plans WHERE id = ? AND status = \'on\'').get(Number(b.plan_id));
  if (!plan) return json(res, 404, { error: '套餐不存在' });
  const channel = ['alipay', 'wechat', 'bank', 'balance'].includes(b.channel) ? b.channel : 'bank';
  const amount = plan.price;
  const no = orderNo('SUB');
  // 生成订阅记录（先 pending）
  const now = new Date();
  const expires = new Date(now.getTime() + plan.period_days * 24 * 3600 * 1000);
  const r = db.prepare('INSERT INTO subscriptions (user_id, plan_id, status, started_at, expires_at, order_no) VALUES (?, ?, \'active\', ?, ?, ?)')
    .run(u.id, plan.id, now.toISOString(), expires.toISOString(), no);
  // 记账
  db.prepare('INSERT INTO ledger (user_id, biz_type, biz_id, order_no, amount, channel, direction, note, status) VALUES (?, \'subscription\', ?, ?, ?, ?, \'in\', ?, \'pending\')')
    .run(u.id, Number(r.lastInsertRowid), no, amount, channel, '订阅「' + plan.name + '」');
  const payMode = getSetting('payment_mode', 'simulate');
  if (channel === 'alipay' && payMode === 'alipay') {
    const form = pay.buildPagePayForm(no, '订阅·' + plan.name, amount);
    return json(res, 200, { ok: true, order_no: no, pay_url: form.url || null, redirect: !!form.url, channel });
  }
  if (channel === 'bank') {
    // 银行直通：登记待核对转账
    db.prepare('INSERT INTO bank_transfers (user_id, order_no, amount, status) VALUES (?, ?, ?, \'pending\')').run(u.id, no, amount);
    return json(res, 200, { ok: true, order_no: no, channel: 'bank', status: 'pending', bank_info: getSetting('bank_account', null) });
  }
  if (channel === 'wechat') {
    // 微信商户模式暂停：改用打赏二维码（wx-zanshang.jpg），到账后人工核对开通
    return json(res, 200, { ok: true, order_no: no, channel: 'wechat', status: 'pending', amount, qr_img: '/wx-zanshang.jpg' });
  }
  // simulate/balance 直接生效
  db.prepare('UPDATE subscriptions SET status = \'active\' WHERE order_no = ?').run(no);
  db.prepare('UPDATE ledger SET status = \'confirmed\', confirmed_at = datetime(\'now\',\'localtime\') WHERE order_no = ?').run(no);
  json(res, 200, { ok: true, order_no: no, status: 'active', channel });
});

// 我的订阅
route('GET', '/api/me/subscription', async (req, res) => {
  const u = authUser(req); if (!u) return json(res, 401, { error: '请先登录' });
  const s = db.prepare('SELECT s.*, p.name, p.period_days FROM subscriptions s JOIN subscription_plans p ON p.id = s.plan_id WHERE s.user_id = ? ORDER BY s.id DESC LIMIT 1').get(u.id);
  if (!s) return json(res, 200, { active: false, subscription: null });
  const active = s.status === 'active' && new Date(s.expires_at) > new Date();
  json(res, 200, { active, subscription: { id: s.id, plan_name: s.name, period_days: s.period_days, status: s.status, started_at: s.started_at, expires_at: s.expires_at } });
});

// 银行转账登记（用户提交转账凭证）
route('POST', '/api/bank-transfers', async (req, res) => {
  const u = authUser(req); if (!u) return json(res, 401, { error: '请先登录' });
  const b = await readBody(req, 1e5);
  const order_no = String(b.order_no || '');
  const amount = Math.round(Number(b.amount) * 100) / 100;
  if (!amount || amount <= 0) return json(res, 400, { error: '金额无效' });
  const r = db.prepare('INSERT INTO bank_transfers (user_id, order_no, amount, payer_name, bank_ref, proof, status) VALUES (?, ?, ?, ?, ?, ?, \'pending\')')
    .run(u.id, order_no, amount, String(b.payer_name || ''), String(b.bank_ref || ''), String(b.proof || ''));
  json(res, 200, { ok: true, id: Number(r.lastInsertRowid) });
});

// 账本（管理员）
route('GET', '/api/admin/ledger', async (req, res) => {
  const u = authUser(req); if (!u || !['admin', 'core'].includes(u.role)) return json(res, 403, { error: '无权限' });
  const u2 = new URL(req.url, 'http://x');
  const channel = u2.searchParams.get('channel') || '';
  const rows = channel ? db.prepare('SELECT * FROM ledger WHERE channel = ? ORDER BY id DESC LIMIT 500').all(channel) : db.prepare('SELECT * FROM ledger ORDER BY id DESC LIMIT 500').all();
  const totals = db.prepare('SELECT COALESCE(SUM(CASE WHEN direction = \'in\' AND status = \'confirmed\' THEN amount ELSE 0 END),0) income, COALESCE(SUM(CASE WHEN direction = \'out\' AND status = \'confirmed\' THEN amount ELSE 0 END),0) expense FROM ledger').get();
  json(res, 200, { rows, total_income: totals.income, total_expense: totals.expense, balance: Math.round((totals.income - totals.expense) * 100) / 100 });
});

// 银行转账核对（管理员确认入账）
route('GET', '/api/admin/bank-transfers', async (req, res) => {
  const u = authUser(req); if (!u || !['admin', 'core'].includes(u.role)) return json(res, 403, { error: '无权限' });
  json(res, 200, db.prepare('SELECT bt.*, us.nickname FROM bank_transfers bt LEFT JOIN users us ON us.id = bt.user_id ORDER BY bt.id DESC LIMIT 200').all());
});

route('POST', '/api/admin/bank-transfers/:id/confirm', async (req, res) => {
  const u = authUser(req); if (!u || !['admin', 'core'].includes(u.role)) return json(res, 403, { error: '无权限' });
  const b = await readBody(req, 1e5);
  const id = Number(req.params[0]);
  const bt = db.prepare('SELECT * FROM bank_transfers WHERE id = ?').get(id);
  if (!bt) return json(res, 404, { error: 'not found' });
  const ok = b.confirm === true || b.confirm === 'true';
  db.prepare('UPDATE bank_transfers SET status = ?, reject_reason = ?, confirmed_at = datetime(\'now\',\'localtime\') WHERE id = ?').run(ok ? 'confirmed' : 'rejected', String(b.reason || ''), id);
  if (ok && bt.order_no) {
    // 关联的订阅订单生效 + 记账确认
    db.prepare('UPDATE ledger SET status = \'confirmed\', confirmed_at = datetime(\'now\',\'localtime\') WHERE order_no = ?').run(bt.order_no);
    db.prepare('UPDATE subscriptions SET status = \'active\' WHERE order_no = ?').run(bt.order_no);
    // 关联的下载订单：发放授权 + 入账（统一用 confirmed 口径）
    const dl = db.prepare('SELECT * FROM download_orders WHERE order_no = ?').get(bt.order_no);
    if (dl) {
      try {
        downloadEngine.grantLicense(dl.user_id, dl.scope, dl.target, dl.order_no, dl.amount, 'admin');
        db.prepare("UPDATE download_orders SET status = 'paid', paid_at = datetime('now','localtime') WHERE order_no = ?").run(bt.order_no);
        try { sseEngine.sendEvent(dl.user_id, 'DOWNLOAD', { scope: dl.scope, target: dl.target }); } catch (e) {}
      } catch (e) {}
    }
  }
  json(res, 200, { ok: true });
});

// 银行账号配置（公开）
route('GET', '/api/bank-account', async (req, res) => {
  json(res, 200, getSetting('bank_account', null));
});

// 扫码支付：创建订单并返回二维码内容（手机扫码 → 打开支付页完成支付）
route('POST', '/api/pay/qr-order', async (req, res) => {
  const b = await readBody(req, 1e5);
  const amount = Math.round(Number(b.amount) * 100) / 100;
  if (!amount || amount <= 0) return json(res, 400, { error: '金额无效' });
  const u = authUser(req);
  const kind = ['tip', 'subscription', 'product'].includes(b.kind) ? b.kind : 'tip';
  const no = orderNo('QR');
  // 生成支付页链接（二维码内容）
  const base = (getSetting('site_domain', 'moonarmor.cn') === 'moonarmor.cn' ? 'https://moonarmor.cn' : 'http://47.116.167.44');
  const payUrl = base + '/pay/qr?o=' + encodeURIComponent(no) + '&a=' + amount + (b.plan_id ? '&plan=' + Number(b.plan_id) : '');
  db.prepare('INSERT INTO ledger (user_id, biz_type, order_no, amount, channel, direction, note, status) VALUES (?, ?, ?, ?, \'bank\', \'in\', ?, \'pending\')')
    .run(u ? u.id : null, kind, no, amount, '扫码支付订单·' + kind);
  json(res, 200, { ok: true, order_no: no, amount, qr_text: payUrl, pay_url: payUrl, kind });
});

// 支付通道状态（公开）：控制前端哪些通道可选，避免未生效通道被点击报错
route('GET', '/api/payment-channels', async (req, res) => {
  const s = getSetting('payment_channels', {});
  const bank = getSetting('bank_account', null);
  const alipayCfg = getSetting('alipay', {}) || {};
  // 国内通道 + 海外通道（海外预留：paypal / stripe / paddle）
  const defs = [
    { key: 'bank', name: '银行转账', icon: '🏦', note: '对公账户直通', auto: !!bank },
    { key: 'alipay', name: '支付宝', icon: '💙', note: '', auto: !!(alipayCfg.appid && alipayCfg.privateKey) },
    { key: 'wechat', name: '微信支付', icon: '💚', note: '微信扫码打赏', auto: true },
    { key: 'paypal', name: 'PayPal', icon: '🌐', note: '海外收款', auto: false },
    { key: 'stripe', name: 'Stripe', icon: '💳', note: '海外信用卡', auto: false },
    { key: 'paddle', name: 'Paddle', icon: '🧾', note: '海外订阅（含税务）', auto: false },
  ];
  const channels = defs.map(d => ({ key: d.key, name: d.name, icon: d.icon, enabled: d.auto, note: d.note }))
    .filter(c => c.key === 'bank' || c.key === 'alipay' || c.key === 'wechat' || c.enabled);
  json(res, 200, channels);
});

// ---------- C：文生视频 / 文生短剧 / 切片分成 ----------
function mediaRow(m) {
  return { id: m.id, article_id: m.article_id, kind: m.kind, title: m.title, provider: m.provider, prompt: m.prompt, script: m.script, duration: m.duration, status: m.status, output_url: m.output_url, cover_url: m.cover_url, error: m.error, author_id: m.author_id, created_at: m.created_at, finished_at: m.finished_at };
}

// 创建文生视频/短剧任务
route('POST', '/api/media/tasks', async (req, res) => {
  const u = authUser(req); if (!u) return json(res, 401, { error: '请先登录' });
  const b = await readBody(req, 1e6);
  if (!b.title) return json(res, 400, { error: '标题必填' });
  const kind = ['video', 'drama'].includes(b.kind) ? b.kind : 'video';
  const provider = String(b.provider || getSetting('video_provider', 'mock'));
  const r = db.prepare('INSERT INTO media_tasks (article_id, kind, title, provider, prompt, script, duration, status, author_id) VALUES (?, ?, ?, ?, ?, ?, ?, \'queued\', ?)')
    .run(b.article_id ? Number(b.article_id) : null, kind, String(b.title).slice(0, 120), provider, String(b.prompt || ''), String(b.script || ''), Number(b.duration || 0), u.id);
  const id = Number(r.lastInsertRowid);
  runMediaTask(id);
  json(res, 200, { ok: true, id, status: 'queued' });
});

// 媒体任务生成（真实 provider 或模拟）
function runMediaTask(id) {
  const t = db.prepare('SELECT * FROM media_tasks WHERE id = ?').get(id);
  if (!t) return;
  db.prepare('UPDATE media_tasks SET status = \'running\' WHERE id = ?').run(id);
  const providers = getSetting('video_providers', {});
  const cfg = providers[t.provider] || {};
  const key = cfg.apiKey || '';
  if (key && cfg.baseUrl) {
    // 真实视频生成：按 provider 协议调用（可灵/即梦/海螺等）
    try {
      const body = JSON.stringify({ model: cfg.model || 'default', prompt: t.prompt, duration: t.duration || 5 });
      const httpMod = cfg.baseUrl.indexOf('https://') === 0 ? https : http;
      const req = httpMod.request(cfg.baseUrl, { method: 'POST', timeout: 120000, headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + key, 'Content-Length': Buffer.byteLength(body) } }, resp => {
        let d = ''; resp.on('data', c => d += c); resp.on('end', () => {
          try {
            const j = JSON.parse(d);
            const url = j.output_url || (j.data && j.data[0] && j.data[0].url) || (j.video_url) || '';
            if (url) db.prepare('UPDATE media_tasks SET status = \'draft\', output_url = ?, finished_at = datetime(\'now\',\'localtime\') WHERE id = ?').run(url, id);
            else db.prepare('UPDATE media_tasks SET status = \'failed\', error = ?, finished_at = datetime(\'now\',\'localtime\') WHERE id = ?').run('未返回视频地址: ' + d.slice(0, 160), id);
          } catch (e) { db.prepare('UPDATE media_tasks SET status = \'failed\', error = ?, finished_at = datetime(\'now\',\'localtime\') WHERE id = ?').run(String(e.message), id); }
        });
      });
      req.on('timeout', () => req.destroy(new Error('timeout')));
      req.on('error', e => db.prepare('UPDATE media_tasks SET status = \'failed\', error = ?, finished_at = datetime(\'now\',\'localtime\') WHERE id = ?').run(String(e.message || e), id));
      req.end(body);
      return;
    } catch (e) { /* fallthrough 模拟 */ }
  }
  // 模拟模式
  const names = { video: '短视频', drama: '短剧' };
  setTimeout(() => {
    db.prepare('UPDATE media_tasks SET status = \'draft\', output_url = ?, script = ?, error = ?, finished_at = datetime(\'now\',\'localtime\') WHERE id = ?')
      .run('[模拟成片] ' + t.title, t.script || ('【' + (names[t.kind] || '视频') + '分镜脚本·模拟】\n1. 开场：' + t.title + '\n2. 论点展开\n3. 收尾署名月亮盔甲'), '配置视频生成 Key（可灵/即梦/海螺）后自动切换真实生成', id);
  }, 400);
}

// 我的媒体任务
route('GET', '/api/me/media', async (req, res) => {
  const u = authUser(req); if (!u) return json(res, 401, { error: '请先登录' });
  json(res, 200, db.prepare('SELECT * FROM media_tasks WHERE author_id = ? ORDER BY id DESC LIMIT 100').all(u.id).map(mediaRow));
});

// 公开发布的媒体（母视频）
route('GET', '/api/media', async (req, res) => {
  const rows = db.prepare('SELECT * FROM media_tasks WHERE status = \'published\' ORDER BY id DESC LIMIT 100').all();
  json(res, 200, rows.map(mediaRow));
});

// 媒体详情（含切片授权统计）
route('GET', '/api/media/:id', async (req, res) => {
  const m = db.prepare('SELECT * FROM media_tasks WHERE id = ?').get(Number(req.params[0]));
  if (!m) return json(res, 404, { error: 'not found' });
  const licenses = db.prepare('SELECT sl.*, u.nickname FROM slice_licenses sl LEFT JOIN users u ON u.id = sl.licensee_id WHERE sl.media_id = ? ORDER BY sl.id DESC').all(m.id);
  const earn = db.prepare('SELECT COALESCE(SUM(amount),0) total, COALESCE(SUM(owner_amount),0) owner FROM slice_earnings WHERE media_id = ? AND status = \'confirmed\'').get(m.id);
  json(res, 200, { ...mediaRow(m), licenses, earnings: { total: earn.total, owner: earn.owner } });
});

// 发布媒体（管理员/作者）
route('POST', '/api/media/:id/publish', async (req, res) => {
  const u = authUser(req); if (!u) return json(res, 401, { error: '请先登录' });
  const m = db.prepare('SELECT * FROM media_tasks WHERE id = ?').get(Number(req.params[0]));
  if (!m) return json(res, 404, { error: 'not found' });
  if (m.author_id !== u.id && !['admin', 'core'].includes(u.role)) return json(res, 403, { error: '无权限' });
  db.prepare('UPDATE media_tasks SET status = \'published\' WHERE id = ?').run(m.id);
  json(res, 200, { ok: true });
});

// 申请切片授权（C3）
route('POST', '/api/media/:id/license', async (req, res) => {
  const u = authUser(req); if (!u) return json(res, 401, { error: '请先登录' });
  const m = db.prepare('SELECT * FROM media_tasks WHERE id = ? AND status = \'published\'').get(Number(req.params[0]));
  if (!m) return json(res, 404, { error: '该母视频未发布，暂不可申请切片' });
  const b = await readBody(req, 1e5);
  const exist = db.prepare('SELECT * FROM slice_licenses WHERE media_id = ? AND licensee_id = ?').get(m.id, u.id);
  if (exist) return json(res, 200, { ok: true, id: exist.id, status: exist.status, note: '已申请过' });
  const r = db.prepare('INSERT INTO slice_licenses (media_id, licensee_id, note) VALUES (?, ?, ?)').run(m.id, u.id, String(b.note || ''));
  json(res, 200, { ok: true, id: Number(r.lastInsertRowid), status: 'pending' });
});

// 我的切片授权
route('GET', '/api/me/slice-licenses', async (req, res) => {
  const u = authUser(req); if (!u) return json(res, 401, { error: '请先登录' });
  const rows = db.prepare('SELECT sl.*, m.title FROM slice_licenses sl JOIN media_tasks m ON m.id = sl.media_id WHERE sl.licensee_id = ? ORDER BY sl.id DESC').all(u.id);
  json(res, 200, rows);
});

// 提交切片收益（切片创作者）
route('POST', '/api/slice-licenses/:id/earnings', async (req, res) => {
  const u = authUser(req); if (!u) return json(res, 401, { error: '请先登录' });
  const lic = db.prepare('SELECT * FROM slice_licenses WHERE id = ?').get(Number(req.params[0]));
  if (!lic) return json(res, 404, { error: 'not found' });
  if (lic.licensee_id !== u.id) return json(res, 403, { error: '无权限' });
  if (lic.status !== 'approved') return json(res, 400, { error: '授权未通过，暂不可提交收益' });
  const b = await readBody(req, 1e5);
  const amount = Math.round(Number(b.amount) * 100) / 100;
  if (!amount || amount <= 0) return json(res, 400, { error: '金额无效' });
  const licAmt = Math.round(amount * lic.ratio_licensee * 100) / 100;
  const ownAmt = Math.round((amount - licAmt) * 100) / 100;
  const r = db.prepare('INSERT INTO slice_earnings (license_id, media_id, platform, amount, licensee_amount, owner_amount, proof, status) VALUES (?, ?, ?, ?, ?, ?, ?, \'pending\')')
    .run(lic.id, lic.media_id, String(b.platform || ''), amount, licAmt, ownAmt, String(b.proof || ''));
  json(res, 200, { ok: true, id: Number(r.lastInsertRowid), licensee_amount: licAmt, owner_amount: ownAmt });
});

// 管理员：切片授权审核 + 收益确认
route('GET', '/api/admin/slice-licenses', async (req, res) => {
  const u = authUser(req); if (!u || !['admin', 'core'].includes(u.role)) return json(res, 403, { error: '无权限' });
  const rows = db.prepare('SELECT sl.*, m.title, us.nickname FROM slice_licenses sl JOIN media_tasks m ON m.id = sl.media_id LEFT JOIN users us ON us.id = sl.licensee_id ORDER BY sl.id DESC LIMIT 200').all();
  json(res, 200, rows);
});

route('POST', '/api/admin/slice-licenses/:id/review', async (req, res) => {
  const u = authUser(req); if (!u || !['admin', 'core'].includes(u.role)) return json(res, 403, { error: '无权限' });
  const b = await readBody(req, 1e5);
  const id = Number(req.params[0]);
  const lic = db.prepare('SELECT * FROM slice_licenses WHERE id = ?').get(id);
  if (!lic) return json(res, 404, { error: 'not found' });
  const st = ['approved', 'rejected', 'revoked'].includes(b.status) ? b.status : 'approved';
  const rl = b.ratio_licensee != null ? Math.min(0.9, Math.max(0.1, Number(b.ratio_licensee))) : lic.ratio_licensee;
  db.prepare('UPDATE slice_licenses SET status = ?, ratio_licensee = ?, ratio_owner = ?, approved_at = datetime(\'now\',\'localtime\') WHERE id = ?').run(st, rl, Math.round((1 - rl) * 1000) / 1000, id);
  json(res, 200, { ok: true });
});

route('GET', '/api/admin/slice-earnings', async (req, res) => {
  const u = authUser(req); if (!u || !['admin', 'core'].includes(u.role)) return json(res, 403, { error: '无权限' });
  const rows = db.prepare('SELECT se.*, m.title, us.nickname FROM slice_earnings se JOIN media_tasks m ON m.id = se.media_id LEFT JOIN slice_licenses sl ON sl.id = se.license_id LEFT JOIN users us ON us.id = sl.licensee_id ORDER BY se.id DESC LIMIT 200').all();
  json(res, 200, rows);
});

route('POST', '/api/admin/slice-earnings/:id/confirm', async (req, res) => {
  const u = authUser(req); if (!u || !['admin', 'core'].includes(u.role)) return json(res, 403, { error: '无权限' });
  const b = await readBody(req, 1e5);
  const id = Number(req.params[0]);
  const se = db.prepare('SELECT * FROM slice_earnings WHERE id = ?').get(id);
  if (!se) return json(res, 404, { error: 'not found' });
  const ok = b.confirm === true || b.confirm === 'true';
  db.prepare('UPDATE slice_earnings SET status = ?, confirmed_at = datetime(\'now\',\'localtime\') WHERE id = ?').run(ok ? 'confirmed' : 'rejected', id);
  if (ok) {
    // 收益入账本
    db.prepare('INSERT INTO ledger (user_id, biz_type, biz_id, amount, channel, direction, note, status) VALUES (?, \'slice_owner\', ?, ?, \'bank\', \'in\', ?, \'confirmed\')')
      .run(null, se.media_id, se.owner_amount, '切片收益·版权方分成');
  }
  json(res, 200, { ok: true });
});

route('POST', '/api/comments', async (req, res) => {
  const b = await readBody(req, 1e5);
  const article_id = Number(b.article_id); const content = String(b.content || '').trim();
  if (!article_id || content.length < 2 || content.length > 2000) return json(res, 400, { error: '参数不完整' });
  const user = authUser(req);
  const parent_id = b.parent_id ? Number(b.parent_id) : null;
  const r = db.prepare('INSERT INTO comments (article_id, parent_id, user_id, nickname, content) VALUES (?, ?, ?, ?, ?)')
    .run(article_id, parent_id, user ? user.id : null, user ? user.nickname : String(b.nickname || '匿名读者').slice(0, 30), content);
  db.prepare('UPDATE articles SET comment_count = comment_count + 1 WHERE id = ?').run(article_id);
  json(res, 200, { ok: true, id: r.lastInsertRowid });
});

route('POST', '/api/tips', async (req, res) => {
  const b = await readBody(req, 1e5);
  const amount = Math.round(Number(b.amount) * 100) / 100;
  if (!amount || amount <= 0) return json(res, 400, { error: '金额无效' });
  const user = authUser(req);
  const no = orderNo('MA');
  db.prepare('INSERT INTO tips (article_id, user_id, nickname, amount, message, order_no, pay_channel, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)')
    .run(b.article_id ? Number(b.article_id) : null, user ? user.id : null, user ? user.nickname : String(b.nickname || '读者').slice(0, 30), amount, String(b.message || '').slice(0, 200), no, String(b.channel || 'simulate'), 'pending');
  let tip = db.prepare('SELECT * FROM tips WHERE order_no = ?').get(no);
  const payMode = getSetting('payment_mode', 'simulate');
  if (b.channel === 'bank') {
    db.prepare('INSERT INTO bank_transfers (user_id, order_no, amount, status) VALUES (?, ?, ?, \'pending\')').run(user ? user.id : null, no, amount);
    db.prepare('INSERT INTO ledger (user_id, biz_type, order_no, amount, channel, direction, note, status) VALUES (?, \'tip\', ?, ?, \'bank\', \'in\', ?, \'pending\')').run(user ? user.id : null, no, amount, '打赏·银行转账');
    return json(res, 200, { ok: true, order_no: no, channel: 'bank', status: 'pending', amount, bank_info: getSetting('bank_account', null) });
  }
  if (b.channel === 'wechat') {
    // 微信 Native 扫码：商户已开通则下真单返回 code_url，未配置时降级静态打赏图
    if (wxpay.ready()) {
      const r = await wxpay.nativePay(no, '打赏支持月亮盔甲', amount);
      if (r.ok) return json(res, 200, { ok: true, order_no: no, channel: 'wechat', status: 'pending', amount, code_url: r.data.code_url, qr_img: '/api/qr.png?d=' + encodeURIComponent(r.data.code_url), real: true });
      return json(res, 200, { ok: true, order_no: no, channel: 'wechat', status: 'pending', amount, qr_img: '/wx-zanshang.jpg', fallback: true, error: r.error });
    }
    return json(res, 200, { ok: true, order_no: no, channel: 'wechat', status: 'pending', amount, qr_img: '/wx-zanshang.jpg', fallback: true });
  }
  if (payMode === 'simulate' || b.channel === 'simulate') { tip = payTip(no); }
  else if (payMode === 'alipay' && b.channel === 'alipay') {
    const form = pay.buildPagePayForm(no, '打赏支持月亮盔甲', amount);
    return json(res, 200, { ok: true, order_no: no, pay_url: form.url || null, redirect: !!form.url });
  }
  json(res, 200, { ok: true, order_no: no, status: tip.status, amount: tip.amount });
});

route('GET', '/api/products', async (req, res) => {
  json(res, 200, db.prepare('SELECT * FROM products WHERE status = \'on\' ORDER BY sort_order, id').all());
});

route('POST', '/api/orders', async (req, res) => {
  const b = await readBody(req, 1e5);
  const product = b.product_id ? db.prepare('SELECT * FROM products WHERE id = ?').get(Number(b.product_id)) : null;
  const amount = product ? product.price : (Math.round(Number(b.amount) * 100) / 100);
  if (!product && (!amount || amount <= 0)) return json(res, 400, { error: '无效商品或金额' });
  const user = authUser(req);
  const no = orderNo('OR');
  db.prepare('INSERT INTO orders (order_no, product_id, user_id, nickname, amount, pay_channel, status) VALUES (?, ?, ?, ?, ?, ?, ?)')
    .run(no, product ? product.id : null, user ? user.id : null, user ? user.nickname : '游客', amount, String(b.channel || 'simulate'), 'pending');
  const payMode = getSetting('payment_mode', 'simulate');
  if (b.channel === 'bank') {
    db.prepare('INSERT INTO bank_transfers (user_id, order_no, amount, status) VALUES (?, ?, ?, \'pending\')').run(user ? user.id : null, no, amount);
    db.prepare('INSERT INTO ledger (user_id, biz_type, order_no, amount, channel, direction, note, status) VALUES (?, \'order\', ?, ?, \'bank\', \'in\', ?, \'pending\')').run(user ? user.id : null, no, amount, '订单·银行转账');
    return json(res, 200, { ok: true, order_no: no, channel: 'bank', status: 'pending', amount, bank_info: getSetting('bank_account', null) });
  }
  if (b.channel === 'wechat') {
    // 微信 Native 扫码：商户已开通则下真单返回 code_url，未配置时降级静态打赏图
    if (wxpay.ready()) {
      const r = await wxpay.nativePay(no, (product ? product.name : '月亮盔甲订单'), amount);
      if (r.ok) return json(res, 200, { ok: true, order_no: no, channel: 'wechat', status: 'pending', amount, code_url: r.data.code_url, qr_img: '/api/qr.png?d=' + encodeURIComponent(r.data.code_url), real: true });
      return json(res, 200, { ok: true, order_no: no, channel: 'wechat', status: 'pending', amount, qr_img: '/wx-zanshang.jpg', fallback: true, error: r.error });
    }
    return json(res, 200, { ok: true, order_no: no, channel: 'wechat', status: 'pending', amount, qr_img: '/wx-zanshang.jpg', fallback: true });
  }
  if (payMode === 'simulate' || b.channel === 'simulate') {
    payOrder(no);
    return json(res, 200, { ok: true, order_no: no, status: 'paid', amount });
  }
  if (payMode === 'alipay' && b.channel === 'alipay') {
    const form = pay.buildPagePayForm(no, (product ? product.name : '订单'), amount);
    return json(res, 200, { ok: true, order_no: no, redirect: !!form.url, pay_url: form.url || null });
  }
  json(res, 200, { ok: true, order_no: no, status: 'pending' });
});

route('GET', '/api/orders/:no', async (req, res) => {
  const o = db.prepare('SELECT * FROM orders WHERE order_no = ?').get(req.params[0]);
  json(res, 200, o ? { order_no: o.order_no, status: o.status, amount: o.amount } : { error: 'not found' });
});

route('POST', '/api/revisions', async (req, res) => {
  const b = await readBody(req, 1e5);
  const content = String(b.content || '').trim();
  if (!b.article_id || content.length < 5) return json(res, 400, { error: '内容过短' });
  const user = authUser(req);
  db.prepare('INSERT INTO revision_suggestions (article_id, user_id, nickname, content) VALUES (?, ?, ?, ?)')
    .run(Number(b.article_id), user ? user.id : null, user ? user.nickname : '匿名', content);
  json(res, 200, { ok: true });
});

route('GET', '/api/tencent-docs/status', async (req, res) => {
  const c = getSetting('tencent_docs', null) || {};
  json(res, 200, { configured: !!(c.token), mcpUrl: c.mcpUrl || 'https://docs.qq.com/openapi/mcp' });
});

route('POST', '/api/tencent-docs/test', async (req, res) => {
  const r = await td.initAndListTools().catch(e => ({ ok: false, error: String(e.message || e) }));
  json(res, 200, r);
});

route('POST', '/api/tencent-docs/sync', async (req, res) => {
  const b = await readBody(req, 1e5);
  const a = b.article_id ? db.prepare('SELECT * FROM articles WHERE id = ?').get(Number(b.article_id)) : null;
  if (!a) return json(res, 404, { error: '文章不存在' });
  const t = await td.initAndListTools().catch(e => ({ ok: false, error: String(e.message || e) }));
  if (!t.ok) return json(res, 200, t);
  const createTool = t.tools.find(n => n === 'doc.create_with_markdown') || t.tools.find(n => /doc.*create|create.*doc/i.test(n));
  if (!createTool) return json(res, 200, { ok: false, error: '未找到可用文档工具', tools: t.tools });
  const md = '# ' + a.title + '\n\n' + a.content;
  const args = createTool === 'doc.create_with_markdown' ? { base64_markdown: Buffer.from(md, 'utf8').toString('base64'), title: a.title.slice(0, 36) } : { title: a.title.slice(0, 36), markdown: md };
  const r = await td.callTool(createTool, args).catch(e => ({ error: String(e.message || e) }));
  json(res, 200, { ok: !r.error, tool: createTool, result: r, tools: t.tools });
});

route('GET', '/api/dividends', async (req, res) => {
  const sum = db.prepare('SELECT COALESCE(SUM(pool_amount),0) s, COUNT(*) c FROM dividend_ledger').get();
  const rows = db.prepare('SELECT * FROM dividend_ledger ORDER BY id DESC LIMIT 50').all();
  json(res, 200, { pool: sum.s, entries: sum.c, ratio: RATIO, ledger: rows });
});

route('POST', '/api/agents/derive', async (req, res) => {
  const b = await readBody(req, 1e5);
  const user = authUser(req);
  if (!b.article_id || !Array.isArray(b.types) || !b.types.length) return json(res, 400, { error: '参数不完整' });
  const a = db.prepare('SELECT * FROM articles WHERE id = ?').get(Number(b.article_id));
  if (!a) return json(res, 404, { error: '文章不存在' });
  const allowed = ['article', 'image', 'video', 'drama'];
  const ids = [];
  for (const t of b.types) {
    if (!allowed.includes(t)) continue;
    const r = db.prepare('INSERT INTO agent_tasks (article_id, task_type, provider, status, params) VALUES (?, ?, ?, \'queued\', ?)')
      .run(a.id, t, getSetting('ai_default_provider', 'deepseek'), JSON.stringify({ title: a.title, source: a.content.slice(0, 6000), kind: t }));
    ids.push(r.lastInsertRowid);
    runAgentTask(Number(r.lastInsertRowid));
  }
  json(res, 200, { ok: true, task_ids: ids });
});

route('GET', '/api/agents/tasks', async (req, res) => {
  const u = new URL(req.url, 'http://x');
  const rows = db.prepare('SELECT * FROM agent_tasks ORDER BY id DESC LIMIT 100').all().map(t => ({ ...t, params: JSON.parse(t.params || '{}') }));
  json(res, 200, rows);
});

route('POST', '/api/distribute', async (req, res) => {
  const b = await readBody(req, 1e5);
  if (!b.article_id || !Array.isArray(b.platforms) || !b.platforms.length) return json(res, 400, { error: '参数不完整' });
  const ids = [];
  for (const p of b.platforms) {
    const r = db.prepare('INSERT INTO distribution_logs (article_id, platform, status) VALUES (?, ?, \'pending\')').run(Number(b.article_id), String(p));
    ids.push(r.lastInsertRowid);
    runDistribution(Number(r.lastInsertRowid));
  }
  json(res, 200, { ok: true, log_ids: ids });
});

route('GET', '/api/distributions', async (req, res) => {
  const u = new URL(req.url, 'http://x');
  const aid = Number(u.searchParams.get('article_id') || 0);
  const rows = aid ? db.prepare('SELECT * FROM distribution_logs WHERE article_id = ? ORDER BY id DESC').all(aid)
    : db.prepare('SELECT * FROM distribution_logs ORDER BY id DESC LIMIT 100').all();
  json(res, 200, rows);
});

// ===== 认证 =====
// 登录页智能推荐：按手机号查账号是否存在及微信/支付宝绑定状态（只读，频控防枚举）
const _probeWin = new Map(); // phone -> {count, t}
route('GET', '/api/auth/probe', async (req, res) => {
  const u = new URL(req.url, 'http://x');
  const phone = String(u.searchParams.get('phone') || '').trim();
  if (!/^1\d{10}$/.test(phone)) return json(res, 400, { error: '手机号格式不正确' });
  const now = Date.now();
  const w = _probeWin.get(phone) || { count: 0, t: now };
  if (now - w.t > 60000) { w.count = 0; w.t = now; }
  w.count++; _probeWin.set(phone, w);
  if (w.count > 10) return json(res, 429, { error: '查询过于频繁，请稍后再试' });
  const row = db.prepare('SELECT wechat_openid, alipay_user_id FROM users WHERE phone = ?').get(phone);
  if (!row) return json(res, 200, { exists: false });
  json(res, 200, { exists: true, has_wechat: !!row.wechat_openid, has_alipay: !!row.alipay_user_id });
});

// P0 登录通道：识别账号类型（手机号/邮箱/证件号，三选一注册登录）
function detectIdType(v) {
  if (/^1\d{10}$/.test(v)) return 'phone';
  if (/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v) && v.length <= 60) return 'email';
  if (/^[0-9A-Za-z]{5,30}$/.test(v)) return 'id_card';
  return null;
}

route('POST', '/api/auth/register', async (req, res) => {
  const b = await readBody(req, 1e5);
  const account = String(b.id || b.phone || '').trim();
  const password = String(b.password || '');
  const type = detectIdType(account);
  if (!type) return json(res, 400, { error: '账号格式不正确（支持手机号/邮箱/证件号）' });
  const nickname = String(b.nickname || '').trim().slice(0, 30) || ('用户' + account.slice(-4));
  if (password.length < 6) return json(res, 400, { error: '密码至少6位' });
  if (db.prepare(`SELECT id FROM users WHERE ${type} = ?`).get(account)) return json(res, 400, { error: '该账号已注册' });
  const r = db.prepare(`INSERT INTO users (${type}, nickname, password_hash) VALUES (?, ?, ?)`).run(account, nickname, hashPassword(password));
  const token = createSession(Number(r.lastInsertRowid));
  json(res, 200, { ok: true, token, user: publicUser(db.prepare('SELECT * FROM users WHERE id = ?').get(Number(r.lastInsertRowid))) }, { 'Set-Cookie': 'ma_token=' + token + '; Path=/; Max-Age=2592000; SameSite=Lax' });
});

route('POST', '/api/auth/login', async (req, res) => {
  const b = await readBody(req, 1e5);
  const account = String(b.id || b.phone || '').trim();
  const u = db.prepare('SELECT * FROM users WHERE phone = ? OR email = ? OR id_card = ?').get(account, account, account);
  if (!u || !verifyPassword(String(b.password || ''), u.password_hash)) return json(res, 401, { error: '账号或密码错误' });
  const token = createSession(u.id);
  json(res, 200, { ok: true, token, user: publicUser(u) }, { 'Set-Cookie': 'ma_token=' + token + '; Path=/; Max-Age=2592000; SameSite=Lax' });
});

route('POST', '/api/auth/logout', async (req, res) => {
  const h = req.headers['authorization'] || '';
  const token = h.startsWith('Bearer ') ? h.slice(7) : null;
  if (token) destroySession(token);
  json(res, 200, { ok: true }, { 'Set-Cookie': 'ma_token=; Path=/; Max-Age=0; SameSite=Lax' });
});

route('GET', '/api/auth/me', async (req, res) => {
  const u = authUser(req);
  const pu = publicUser(u);
  if (pu) pu.super = isSuperAdmin(u);
  json(res, 200, { user: pu });
});

// 兼容 exchange/renovation 等页的用户盒：返回用户对象本体（未登录 401），区别于 /api/auth/me 的 {user}
route('GET', '/api/me', async (req, res) => {
  const u = authUser(req);
  if (!u) return json(res, 401, { error: '请先登录' });
  const pu = publicUser(u);
  if (pu) pu.super = isSuperAdmin(u);
  json(res, 200, pu);
});

route('GET', '/api/me/orders', async (req, res) => {
  const u = authUser(req); if (!u) return json(res, 401, { error: '请先登录' });
  json(res, 200, db.prepare('SELECT * FROM orders WHERE user_id = ? ORDER BY id DESC LIMIT 100').all(u.id));
});
route('GET', '/api/me/tips', async (req, res) => {
  const u = authUser(req); if (!u) return json(res, 401, { error: '请先登录' });
  json(res, 200, db.prepare('SELECT * FROM tips WHERE user_id = ? ORDER BY id DESC LIMIT 100').all(u.id));
});


// ===== 多智慧体协同通讯（comm）：智能体群体 + 碳基人(VX)协同对话群 =====
// 主通道自建，不依赖 GitHub（可与 agent-comm 分支联合镜像）；旧 _agent-inbox 协议并行保留不动。
// 智能体鉴权：环境变量 COMM_TOKENS_JSON='{"chief":"...","asus":"..."}'（X-Agent-Id + X-Agent-Key 头），
//   未配置则智能体通道 fail-closed；碳基人(VX)走主站登录 session（须 admin/superadmin）。
let COMM_TOKENS = {};
try { COMM_TOKENS = JSON.parse(process.env.COMM_TOKENS_JSON || '{}'); } catch (e) { COMM_TOKENS = {}; }
function authComm(req) {
  const u = authUser(req);
  if (u && (isSuperAdmin(u) || u.role === 'admin')) return { me: 'vx', via: 'session', user: u };
  const aid = String(req.headers['x-agent-id'] || '').toLowerCase().trim();
  const akey = String(req.headers['x-agent-key'] || '');
  if (aid && akey && COMM_TOKENS[aid] && COMM_TOKENS[aid] === akey) return { me: aid, via: 'agent' };
  return null;
}
const COMM_TYPES = new Set(['BLOCK', 'ASK', 'INFO']);
function commCleanId(s) { return String(s || '').toLowerCase().trim().replace(/[^a-z0-9_-]/g, '').slice(0, 32); }

route('POST', '/api/comm/send', async (req, res) => {
  const a = authComm(req); if (!a) return json(res, 401, { error: '需要智能体令牌或管理员登录' });
  const b = await readBody(req, 1e5);
  const to = commCleanId(b.to) || 'all';
  const type = COMM_TYPES.has(String(b.type || '').toUpperCase()) ? String(b.type).toUpperCase() : 'INFO';
  const subject = String(b.subject || '').slice(0, 120);
  const body = String(b.body || '').slice(0, 4000);
  if (!body.trim()) return json(res, 400, { error: '消息不能为空' });
  const r = db.prepare('INSERT INTO comm_messages (from_id, to_id, type, subject, body) VALUES (?, ?, ?, ?, ?)')
    .run(a.me, to, type, subject, body);
  json(res, 200, { ok: true, id: Number(r.lastInsertRowid) });
});

route('GET', '/api/comm/feed', async (req, res) => {
  const a = authComm(req); if (!a) return json(res, 401, { error: '需要智能体令牌或管理员登录' });
  const since = Math.max(0, parseInt((req.url || '').match(/[?&]since=(\d+)/)?.[1] || '0', 10) || 0);
  const lim = Math.max(1, Math.min(200, parseInt((req.url || '').match(/[?&]limit=(\d+)/)?.[1] || '200', 10) || 200));
  // 可见性：全员广播 + 发给我的 + 我发出的
  const messages = db.prepare(
    "SELECT * FROM comm_messages WHERE id > ? AND (to_id = 'all' OR to_id = ? OR from_id = ?) ORDER BY id ASC LIMIT ?"
  ).all(since, a.me, a.me, lim);
  const heartbeats = {};
  const nowMs = Date.now();
  for (const h of db.prepare('SELECT agent_id, meta, updated_at FROM comm_heartbeats').all()) {
    const ts = Date.parse((h.updated_at || '').replace(' ', 'T'));
    heartbeats[h.agent_id] = { ts: h.updated_at, online: !!(ts && (nowMs - ts) < 5 * 60 * 1000) };
  }
  json(res, 200, { me: a.me, via: a.via, messages, heartbeats });
});

route('POST', '/api/comm/ack/:id', async (req, res) => {
  const a = authComm(req); if (!a) return json(res, 401, { error: '需要智能体令牌或管理员登录' });
  const id = parseInt(req.params[0], 10);
  if (!(id > 0)) return json(res, 400, { error: '参数错误' });
  const m = db.prepare('SELECT * FROM comm_messages WHERE id = ?').get(id);
  if (!m) return json(res, 404, { error: '消息不存在' });
  if (!m.ack) db.prepare("UPDATE comm_messages SET ack = 1, ack_by = ?, ack_at = datetime('now','localtime') WHERE id = ?").run(a.me, id);
  json(res, 200, { ok: true, id });
});

route('POST', '/api/comm/heartbeat', async (req, res) => {
  const a = authComm(req); if (!a) return json(res, 401, { error: '需要智能体令牌或管理员登录' });
  const b = await readBody(req, 1e4);
  const meta = JSON.stringify((b && typeof b.meta === 'object' && b.meta) ? b.meta : {}).slice(0, 2000);
  db.prepare("INSERT INTO comm_heartbeats (agent_id, meta, updated_at) VALUES (?, ?, datetime('now','localtime')) "
    + "ON CONFLICT(agent_id) DO UPDATE SET meta = excluded.meta, updated_at = excluded.updated_at").run(a.me, meta);
  json(res, 200, { ok: true, me: a.me });
});

// ===== 管理接口 =====
route('GET', '/api/articles/:id/related', async (req, res) => {
  const id = Number(req.params[0]);
  const a = db.prepare('SELECT * FROM articles WHERE id = ?').get(id);
  if (!a) return json(res, 404, { error: 'not found' });
  const row = (r) => ({ id: r.id, title: r.title, slug: r.slug, summary: r.summary, cat1_id: r.cat1_id, view_count: r.view_count });
  const same = db.prepare('SELECT * FROM articles WHERE cat1_id = ? AND id != ? AND status = ? ORDER BY view_count DESC, id DESC LIMIT 3').all(a.cat1_id, id, 'published').map(row);
  let cross = [];
  if (a.tags && JSON.parse(a.tags).length) {
    const tagSql = JSON.parse(a.tags).map(t => 'tags LIKE ?').join(' OR ');
    const tagArgs = JSON.parse(a.tags).map(t => '%' + t + '%');
    cross = db.prepare('SELECT * FROM articles WHERE id != ? AND status = ? AND cat1_id != ? AND (' + tagSql + ') ORDER BY view_count DESC LIMIT 2').all(id, 'published', a.cat1_id, ...tagArgs).map(row);
  }
  if (cross.length < 2) {
    const extra = db.prepare('SELECT * FROM articles WHERE id != ? AND status = ? AND cat1_id != ? ORDER BY view_count DESC, id DESC LIMIT ?').all(id, 'published', a.cat1_id, 2 - cross.length).map(row);
    cross = cross.concat(extra.filter(x => !cross.some(c => c.id === x.id))).slice(0, 2);
  }
  json(res, 200, { same, cross, source: a.source_doc || null });
});

route('GET', '/api/articles/:id/versions', async (req, res) => {
  const rows = db.prepare('SELECT id, version_no, change_note, created_at FROM article_versions WHERE article_id = ? ORDER BY id DESC LIMIT 30').all(Number(req.params[0]));
  json(res, 200, rows);
});

route('GET', '/api/articles/:id/versions/:vid', async (req, res) => {
  const v = db.prepare('SELECT * FROM article_versions WHERE id = ? AND article_id = ?').get(Number(req.params[1]), Number(req.params[0]));
  json(res, 200, v || { error: '版本不存在' });
});

route('POST', '/api/articles/:id/favorite', async (req, res) => {
  const user = authUser(req); if (!user) return json(res, 401, { error: '请先登录' });
  const id = Number(req.params[0]);
  if (!db.prepare('SELECT id FROM articles WHERE id = ?').get(id)) return json(res, 404, { error: 'not found' });
  const ex = db.prepare('SELECT id FROM favorites WHERE article_id = ? AND user_id = ?').get(id, user.id);
  if (ex) { db.prepare('DELETE FROM favorites WHERE id = ?').run(ex.id); return json(res, 200, { favorited: false }); }
  db.prepare('INSERT INTO favorites (article_id, user_id) VALUES (?, ?)').run(id, user.id);
  json(res, 200, { favorited: true });
});

route('GET', '/api/me/favorites', async (req, res) => {
  const user = authUser(req); if (!user) return json(res, 401, { error: '请先登录' });
  const rows = db.prepare('SELECT a.id, a.title, a.slug, a.summary, f.created_at FROM favorites f JOIN articles a ON a.id = f.article_id WHERE f.user_id = ? ORDER BY f.id DESC LIMIT 100').all(user.id);
  json(res, 200, rows);
});

route('GET', '/api/me/comments', async (req, res) => {
  const user = authUser(req); if (!user) return json(res, 401, { error: '请先登录' });
  const rows = db.prepare('SELECT c.id, c.content, c.created_at, a.title, a.slug FROM comments c JOIN articles a ON a.id = c.article_id WHERE c.user_id = ? ORDER BY c.id DESC LIMIT 100').all(user.id);
  json(res, 200, rows);
});

route('GET', '/api/me/revisions', async (req, res) => {
  const user = authUser(req); if (!user) return json(res, 401, { error: '请先登录' });
  const rows = db.prepare('SELECT r.id, r.content, r.status, r.created_at, a.title, a.slug FROM revision_suggestions r JOIN articles a ON a.id = r.article_id WHERE r.user_id = ? ORDER BY r.id DESC LIMIT 100').all(user.id);
  json(res, 200, rows);
});

route('GET', '/api/me/notifications', async (req, res) => {
  const user = authUser(req); if (!user) return json(res, 401, { error: '请先登录' });
  const rows = db.prepare('SELECT * FROM notifications WHERE user_id = ? ORDER BY id DESC LIMIT 100').all(user.id);
  const unread = db.prepare('SELECT COUNT(*) c FROM notifications WHERE user_id = ? AND is_read = 0').get(user.id).c;
  json(res, 200, { items: rows, unread });
});

route('POST', '/api/me/notifications/read', async (req, res) => {
  const user = authUser(req); if (!user) return json(res, 401, { error: '请先登录' });
  db.prepare('UPDATE notifications SET is_read = 1 WHERE user_id = ?').run(user.id);
  json(res, 200, { ok: true });
});

route('GET', '/api/admin/revisions', async (req, res) => {
  const u = authUser(req); if (!u || !['admin', 'core'].includes(u.role)) return json(res, 403, { error: '无权限' });
  const rows = db.prepare('SELECT r.*, a.title AS article_title, a.slug FROM revision_suggestions r JOIN articles a ON a.id = r.article_id ORDER BY r.id DESC LIMIT 200').all();
  json(res, 200, rows);
});

route('POST', '/api/admin/revisions/:id', async (req, res) => {
  const u = authUser(req); if (!u || !['admin', 'core'].includes(u.role)) return json(res, 403, { error: '无权限' });
  const b = await readBody(req, 1e5);
  const status = String(b.status || '');
  if (!['pending', 'accepted', 'rejected', 'merged'].includes(status)) return json(res, 400, { error: '无效状态' });
  const rv = db.prepare('SELECT * FROM revision_suggestions WHERE id = ?').get(Number(req.params[0]));
  if (!rv) return json(res, 404, { error: 'not found' });
  db.prepare('UPDATE revision_suggestions SET status = ? WHERE id = ?').run(status, rv.id);
  if (rv.user_id && status !== 'pending') {
    db.prepare('INSERT INTO notifications (user_id, type, title, content, link) VALUES (?, ?, ?, ?, ?)')
      .run(rv.user_id, 'revision', status === 'accepted' ? '您的修订建议已被采纳' : '您的修订建议未通过', String(b.note || '').slice(0, 200), rv.article_id ? '/article.html?slug=' + (db.prepare('SELECT slug FROM articles WHERE id = ?').get(rv.article_id) || {}).slug : '');
  }
  json(res, 200, { ok: true });
});

route('GET', '/api/chapters/pdfs', async (req, res) => {
  const dir = path.join(WEB_ROOT, 'chapters');
  let files = [];
  if (fs.existsSync(dir)) {
    files = fs.readdirSync(dir).filter(f => f.endsWith('.pdf')).sort((a, b) => a.localeCompare(b, 'zh-Hans-CN', { numeric: true }));
    files = files.map(f => { const st = fs.statSync(path.join(dir, f)); return { file: f, title: f.slice(0, -4), size: st.size }; });
  }
  json(res, 200, files);
});

route('GET', '/api/chapters', async (req, res) => {
  const dir = path.join(WEB_ROOT, 'chapters');
  let files = [];
  if (fs.existsSync(dir)) {
    files = fs.readdirSync(dir).filter(f => f.endsWith('.md')).sort((a, b) => a.localeCompare(b, 'zh-Hans-CN', { numeric: true }));
    files = files.map(f => { const st = fs.statSync(path.join(dir, f)); return { file: f, title: f.slice(0, -3), size: st.size }; });
  }
  json(res, 200, files);
});

function readerHash() {
  const pw = String(getSetting('reader_password', '871003'));
  return crypto.createHash('sha256').update('moonarmor:' + pw).digest('hex');
}
function checkReaderAuth(req) {
  const c = req.headers['cookie'] || '';
  const m = c.match(/(?:^|;\s*)reader_auth=([^;]+)/);
  return !!m && m[1] === readerHash();
}

// 是否有效订阅会员
function hasActiveSubscription(userId) {
  if (!userId) return false;
  const s = db.prepare('SELECT * FROM subscriptions WHERE user_id = ? AND status = \'active\' ORDER BY id DESC LIMIT 1').get(userId);
  return !!(s && new Date(s.expires_at) > new Date());
}

// 订阅会员鉴权（口令 或 有效订阅）
function checkReaderOrSubscriber(req) {
  if (checkReaderAuth(req)) return true;
  const u = authUser(req);
  return hasActiveSubscription(u ? u.id : null);
}

route('POST', '/api/reader/verify', async (req, res) => {
  const b = await readBody(req, 1e4);
  const pw = String(getSetting('reader_password', '871003'));
  if (String(b.password || '') === pw) {
    res.setHeader('Set-Cookie', 'reader_auth=' + readerHash() + '; Path=/; HttpOnly; Max-Age=604800; SameSite=Lax');
    return json(res, 200, { ok: true });
  }
  json(res, 200, { ok: false, error: '密码错误' });
});

route('GET', '/api/reader/status', async (req, res) => {
  json(res, 200, { authorized: checkReaderAuth(req) });
});

function hashContent(text) {
  return crypto.createHash('sha256').update(String(text || '')).digest('hex');
}
function buildCredential(article, hash) {
  return JSON.stringify({
    schema: 'moonarmor-content-credential/1.0', type: 'ContentCredential',
    article_id: article.id, title: article.title,
    author: article.author_name || '谢沛频（VX）',
    content_hash: hash,
    issued_at: new Date().toISOString(),
    license: '版权归原作者所有 · 保留所有权利',
    generator: '月亮盔甲 moonarmor.cn'
  });
}
function appendContentRecord(article, type, note) {
  const h = hashContent(article.content);
  const last = db.prepare('SELECT content_hash FROM content_records ORDER BY id DESC LIMIT 1').get();
  const cred = type === 'publish' ? buildCredential(article, h) : '';
  db.prepare('INSERT INTO content_records (article_id, content_hash, prev_hash, record_type, note, credential) VALUES (?, ?, ?, ?, ?, ?)')
    .run(article.id, h, last ? last.content_hash : '', type, note || '', cred);
  return h;
}

route('GET', '/api/articles/:id/credential', async (req, res) => {
  const id = Number(req.params[0]);
  const a = db.prepare('SELECT * FROM articles WHERE id = ?').get(id);
  if (!a) return json(res, 404, { error: 'not found' });
  const rec = db.prepare("SELECT * FROM content_records WHERE article_id = ? AND credential != '' ORDER BY id DESC LIMIT 1").get(id);
  if (!rec) return json(res, 404, { error: '暂无凭证（发布后自动生成）' });
  json(res, 200, { credential: JSON.parse(rec.credential) });
});

route('GET', '/api/evidence', async (req, res) => {
  const rows = db.prepare('SELECT r.*, a.title FROM content_records r LEFT JOIN articles a ON a.id = r.article_id ORDER BY r.id DESC LIMIT 100').all();
  const chain = db.prepare('SELECT * FROM content_records ORDER BY id ASC').all();
  let broken = 0;
  for (let i = 1; i < chain.length; i++) { if (chain[i].prev_hash !== chain[i - 1].content_hash) broken++; }
  json(res, 200, { total: chain.length, integrity: broken === 0, broken_links: broken, records: rows });
});

route('GET', '/api/articles/:id/evidence', async (req, res) => {
  const id = Number(req.params[0]);
  const a = db.prepare('SELECT * FROM articles WHERE id = ?').get(id);
  if (!a) return json(res, 404, { error: 'not found' });
  const rows = db.prepare('SELECT * FROM content_records WHERE article_id = ? ORDER BY id DESC LIMIT 50').all(id);
  const current = hashContent(a.content);
  const verified = rows.length > 0 && rows[0].content_hash === current;
  json(res, 200, { article: { id: a.id, title: a.title }, current_hash: current, verified, records: rows });
});

route('POST', '/api/evidence/verify', async (req, res) => {
  const b = await readBody(req, 1e5);
  const h = hashContent(b.content);
  json(res, 200, { hash: h, match: b.hash === h });
});

function wxApiGet(path) {
  return new Promise((resolve, reject) => {
    const req = https.request({ hostname: 'api.weixin.qq.com', path, method: 'GET', timeout: 15000 }, res => {
      let d = ''; res.on('data', c => d += c); res.on('end', () => { try { resolve(JSON.parse(d)); } catch (e) { reject(new Error(d.slice(0, 200))); } });
    });
    req.on('error', reject); req.on('timeout', () => req.destroy(new Error('timeout'))); req.end();
  });
}
function wechatOAuthConfig() {
  const w = (getSetting('platform_credentials', {}) || {}).wechat || {};
  return { appid: w.appid || '', secret: w.secret || '', configured: !!(w.appid && w.secret) };
}

// ===== 账号绑定（微信/支付宝 ↔ 手机账号）=====
const _pendingBind = new Map(); // token -> {provider, sub, t}
function _bindCol(provider) { return provider === 'wechat' ? 'wechat_openid' : 'alipay_user_id'; }
// 解析一次第三方登录：已绑→直接登录；已登录→绑定当前号；未登录→发 pending token 引导绑定
function _bindResolve(provider, sub, req) {
  const col = _bindCol(provider);
  let user = db.prepare('SELECT * FROM users WHERE ' + col + ' = ?').get(sub);
  if (user) return { user };
  const me = authUser(req);
  if (me) {
    if (db.prepare('SELECT id FROM users WHERE ' + col + ' = ? AND id <> ?').get(sub, me.id)) return { error: '该' + (provider === 'wechat' ? '微信' : '支付宝') + '已绑定其他账号' };
    db.prepare('UPDATE users SET ' + col + ' = ?, updated_at = datetime(\'now\',\'localtime\') WHERE id = ?').run(sub, me.id);
    return { user: db.prepare('SELECT * FROM users WHERE id = ?').get(me.id), bound: true };
  }
  const token = 'pb_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
  _pendingBind.set(token, { provider, sub, t: Date.now() });
  return { needBind: true, token };
}
function _redirectLogin(res, user) {
  const token = createSession(user.id);
  res.writeHead(302, { Location: '/user.html?token=' + token + '&welcome=1', 'Set-Cookie': 'ma_token=' + token + '; Path=/; Max-Age=2592000; SameSite=Lax' });
  res.end();
}

route('GET', '/api/auth/wechat/url', async (req, res) => {
  const c = wechatOAuthConfig();
  if (!c.configured) return json(res, 200, { configured: false, error: '微信登录未配置（后台-系统设置-分发平台 wechat 项填 appid/secret）' });
  const redirect = (getSetting('site_domain', 'moonarmor.cn') === 'moonarmor.cn' ? 'https://moonarmor.cn' : 'http://47.116.167.44') + '/api/auth/wechat/callback';
  const url = 'https://open.weixin.qq.com/connect/oauth2/authorize?appid=' + c.appid + '&redirect_uri=' + encodeURIComponent(redirect) + '&response_type=code&scope=snsapi_userinfo&state=moonarmor#wechat_redirect';
  json(res, 200, { configured: true, url });
});

route('GET', '/api/auth/wechat/callback', async (req, res) => {
  const u = new URL(req.url, 'http://x');
  const code = u.searchParams.get('code');
  if (!code) return json(res, 400, { error: '缺少 code' });
  const c = wechatOAuthConfig();
  if (!c.configured) return json(res, 200, { error: '微信登录未配置' });
  try {
    const tr = await wxApiGet('/sns/oauth2/access_token?appid=' + encodeURIComponent(c.appid) + '&secret=' + encodeURIComponent(c.secret) + '&code=' + encodeURIComponent(code) + '&grant_type=authorization_code');
    if (!tr.openid) return json(res, 400, { error: '微信登录失败: ' + (tr.errmsg || '未知错误') });
    const r = _bindResolve('wechat', tr.openid, req);
    if (r.error) return res.writeHead(302, { Location: '/login.html?binderr=' + encodeURIComponent(r.error) }), res.end();
    if (r.needBind) return res.writeHead(302, { Location: '/bind.html?t=' + r.token + '&p=wechat' }), res.end();
    _redirectLogin(res, r.user);
  } catch (e) { json(res, 400, { error: String(e.message || e) }); }
});

route('GET', '/api/auth/alipay/url', async (req, res) => {
  const r = ao.buildAuthUrl((getSetting('site_domain', 'moonarmor.cn') === 'moonarmor.cn' ? 'https://moonarmor.cn' : 'http://47.116.167.44') + '/api/auth/alipay/callback');
  if (!r.configured) return json(res, 200, { configured: false, error: '支付宝登录未配置（后台-系统设置-支付 填 appid/私钥）' });
  json(res, 200, r);
});

route('GET', '/api/auth/alipay/callback', async (req, res) => {
  const u = new URL(req.url, 'http://x');
  const code = u.searchParams.get('auth_code');
  const providerErr = u.searchParams.get('error');
  // 三种失败必须分开，且都把人送回登录页给出可点的下一步，
  // 不许把 "缺少 auth_code" 这种技术报错甩给用户（他把页面关了就再不回来了）。
  const backWith = (reason) => {
    res.writeHead(302, { Location: '/login.html?autherr=' + reason });
    res.end();
  };
  // 1) 用户自己点了取消
  if (providerErr) {
    console.warn('[alipay] 用户取消或被拒:', providerErr);
    return backWith('cancelled');
  }
  // 2) 支付宝回跳但没带授权码 —— 最常见原因是应用未签约「获取会员信息」权限
  if (!code) {
    console.warn('[alipay] 回跳无 auth_code：检查应用是否已签约「获取会员信息」且已上线');
    return backWith('no_code');
  }
  // 3) 拿码换身份失败（码过期 / 网络 / 签名）
  try {
    const uid = await ao.oauthToken(code);
    const r = _bindResolve('alipay', uid, req);
    if (r.error) return res.writeHead(302, { Location: '/login.html?binderr=' + encodeURIComponent(r.error) }), res.end();
    if (r.needBind) return res.writeHead(302, { Location: '/bind.html?t=' + r.token + '&p=alipay' }), res.end();
    _redirectLogin(res, r.user);
  } catch (e) {
    console.warn('[alipay] 换码失败:', String(e.message || e));
    return backWith('exchange_failed');
  }
});

// ===== 支付宝扫码登录（桌面出码，手机确认，桌面轮询）=====
// 为什么需要这一套：二维码被手机扫走之后，授权是在手机上完成的；
// 桌面浏览器不会自己变成登录态。所以必须有 ticket + 轮询把这根线接回来。
const _qrLogins = new Map(); // ticket -> {t, token, user}
setInterval(() => {
  const now = Date.now();
  for (const [k, v] of _qrLogins) if (now - v.t > 10 * 60 * 1000) _qrLogins.delete(k);
}, 60 * 1000).unref?.();

route('GET', '/api/auth/alipay/qr', async (req, res) => {
  const host = (getSetting('site_domain', 'moonarmor.cn') === 'moonarmor.cn' ? 'https://moonarmor.cn' : 'http://47.116.167.44');
  const ticket = 'qrt' + Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
  _qrLogins.set(ticket, { t: Date.now() });
  const redirect = host + '/api/auth/alipay/qr-callback/' + ticket;
  const r = ao.buildAuthUrlFor(redirect);
  if (!r.configured) return json(res, 200, { configured: false, error: '支付宝登录未配置' });
  json(res, 200, { configured: true, ticket, url: r.url });
});

route('GET', '/api/auth/alipay/qr/status', async (req, res) => {
  const u = new URL(req.url, 'http://x');
  const tk = u.searchParams.get('ticket') || '';
  const e = _qrLogins.get(tk);
  if (!e) return json(res, 404, { status: 'expired', error: '二维码过期，请刷新' });
  if (!e.token) return json(res, 200, { status: 'waiting' });
  json(res, 200, { status: 'ok', token: e.token, user: e.user });
});

// 手机端回跳：收码 → 换身份 → 找到/创建用户 → 写 ticket → 提示回电脑
route('GET', '/api/auth/alipay/qr-callback/:ticket', async (req, res) => {
  const u = new URL(req.url, 'http://x');
  const code = u.searchParams.get('auth_code');
  const ticket = req.params ? req.params.ticket : String(u.pathname.split('/').pop());
  const e = _qrLogins.get(ticket);
  const done = (html) => { res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' }); res.end(html); };
  if (!e) return done('<meta charset="utf-8"><h2>二维码已过期</h2><p>请回到电脑刷新页面重新扫码。</p>');
  if (!code) { console.warn('[alipay-qr] 回跳无 auth_code'); return done('<meta charset="utf-8"><h2>授权没完成</h2><p>请回到电脑重新试一次。</p>'); }
  try {
    const uid = await ao.oauthToken(code);
    let user = db.prepare('SELECT * FROM users WHERE alipay_user_id = ?').get(uid);
    if (!user) {
      const nick = '用户' + Math.random().toString(36).slice(2, 6);
      const ins = db.prepare('INSERT INTO users (nickname, alipay_user_id) VALUES (?,?)').run(nick, uid);
      user = db.prepare('SELECT * FROM users WHERE id = ?').get(Number(ins.lastInsertRowid));
    }
    const token = createSession(user.id);
    e.token = token; e.user = publicUser(user); e.t = Date.now();
    console.log('[alipay-qr] 扫码登录成功 ticket=' + ticket.slice(0, 8) + ' user=' + user.id);
    done('<meta charset="utf-8"><div style="font-family:system-ui;text-align:center;padding:60px 20px"><h2>已经在电脑上登录了</h2><p style="color:#888">可以关掉这个页面，回到电脑继续。</p></div>');
  } catch (err) {
    console.warn('[alipay-qr] 换码失败:', String(err.message || err));
    done('<meta charset="utf-8"><h2>授权失败</h2><p>请回到电脑,换微信或邮箱登录。</p>');
  }
});

// 查当前账号绑定状态
route('GET', '/api/auth/bindings', async (req, res) => {
  const u = authUser(req); if (!u) return json(res, 401, { error: '请先登录' });
  json(res, 200, { wechat: !!u.wechat_openid, alipay: !!u.alipay_user_id });
});
// 扫码后未登录：输手机密码完成绑定（或注册并绑定）
route('POST', '/api/auth/bind', async (req, res) => {
  const b = await readBody(req, 1e5);
  const t = String(b.token || '');
  const pb = _pendingBind.get(t);
  if (!pb || Date.now() - pb.t > 10 * 60 * 1000) { _pendingBind.delete(t); return json(res, 400, { error: '绑定已过期，请重新扫码' }); }
  const phone = String(b.phone || '').trim(), password = String(b.password || '');
  // mode='new'：不绑老账号，直接用第三方身份建新号。
  // 为什么要有这条路：用户刚用支付宝/微信验明了身份，再逼他回忆密码是白设的墙，
  // 忘了密码的人会在这里彻底卡死（2026-10-27 实际发生）。手机号与密码都留作「以后补」。
  if (b.mode === 'new') {
    const colN = _bindCol(pb.provider);
    if (db.prepare('SELECT id FROM users WHERE ' + colN + ' = ?').get(pb.sub)) return json(res, 400, { error: '该账号已被绑定' });
    const nick = String(b.nickname || '').trim().slice(0, 20) || ('用户' + Math.random().toString(36).slice(2, 6));
    const insN = db.prepare('INSERT INTO users (nickname, ' + colN + ') VALUES (?,?)').run(nick, pb.sub);
    const userN = db.prepare('SELECT * FROM users WHERE id = ?').get(Number(insN.lastInsertRowid));
    _pendingBind.delete(t);
    const tokenN = createSession(userN.id);
    return json(res, 200, { ok: true, token: tokenN, user: publicUser(userN), created: true });
  }
  if (!/^1\d{10}$/.test(phone)) return json(res, 400, { error: '手机号格式不正确' });
  const col = _bindCol(pb.provider);
  if (db.prepare('SELECT id FROM users WHERE ' + col + ' = ?').get(pb.sub)) return json(res, 400, { error: '该账号已被绑定' });
  let user;
  if (b.mode === 'register') {
    if (password.length < 6) return json(res, 400, { error: '密码至少6位' });
    if (db.prepare('SELECT id FROM users WHERE phone = ?').get(phone)) return json(res, 400, { error: '该手机号已注册，请用「登录并绑定」' });
    const ins = db.prepare('INSERT INTO users (phone, nickname, password_hash, ' + col + ') VALUES (?,?,?,?)').run(phone, '用户' + phone.slice(-4), hashPassword(password), pb.sub);
    user = db.prepare('SELECT * FROM users WHERE id = ?').get(Number(ins.lastInsertRowid));
  } else {
    user = db.prepare('SELECT * FROM users WHERE phone = ?').get(phone);
    if (!user || !verifyPassword(password, user.password_hash)) return json(res, 401, { error: '手机号或密码错误' });
    db.prepare('UPDATE users SET ' + col + ' = ?, updated_at = datetime(\'now\',\'localtime\') WHERE id = ?').run(pb.sub, user.id);
    user = db.prepare('SELECT * FROM users WHERE id = ?').get(user.id);
  }
  _pendingBind.delete(t);
  const token = createSession(user.id);
  json(res, 200, { ok: true, token, user: publicUser(user) }, { 'Set-Cookie': 'ma_token=' + token + '; Path=/; Max-Age=2592000; SameSite=Lax' });
});
// 解绑
route('POST', '/api/auth/unbind', async (req, res) => {
  const u = authUser(req); if (!u) return json(res, 401, { error: '请先登录' });
  const b = await readBody(req, 1e5);
  const col = _bindCol(String(b.provider || ''));
  if (!col || (String(b.provider) !== 'wechat' && String(b.provider) !== 'alipay')) return json(res, 400, { error: '未知 provider' });
  db.prepare('UPDATE users SET ' + col + ' = NULL, updated_at = datetime(\'now\',\'localtime\') WHERE id = ?').run(u.id);
  json(res, 200, { ok: true });
});

route('POST', '/api/auth/change-password', async (req, res) => {
  const user = authUser(req); if (!user) return json(res, 401, { error: '请先登录' });
  const b = await readBody(req, 1e5);
  const oldPw = String(b.old_password || ''), newPw = String(b.new_password || '');
  if (!verifyPassword(oldPw, user.password_hash)) return json(res, 400, { error: '原密码错误' });
  if (newPw.length < 6) return json(res, 400, { error: '新密码至少6位' });
  db.prepare('UPDATE users SET password_hash = ?, updated_at = datetime(\'now\',\'localtime\') WHERE id = ?').run(hashPassword(newPw), user.id);
  json(res, 200, { ok: true });
});

route('POST', '/api/report', async (req, res) => {
  const b = await readBody(req, 1e5);
  if (!b.target_type || !b.target_id || !String(b.reason || '').trim()) return json(res, 400, { error: '参数不完整' });
  const user = authUser(req);
  db.prepare('INSERT INTO reports (target_type, target_id, user_id, reason) VALUES (?, ?, ?, ?)')
    .run(String(b.target_type), Number(b.target_id), user ? user.id : null, String(b.reason).slice(0, 500));
  json(res, 200, { ok: true });
});

route('GET', '/api/admin/reports', async (req, res) => {
  const u = authUser(req); if (!u || u.role !== 'admin') return json(res, 403, { error: '无权限' });
  json(res, 200, db.prepare('SELECT * FROM reports ORDER BY id DESC LIMIT 200').all());
});

route('POST', '/api/admin/reports/:id', async (req, res) => {
  const u = authUser(req); if (!u || u.role !== 'admin') return json(res, 403, { error: '无权限' });
  const b = await readBody(req, 1e4);
  const status = String(b.status || '');
  if (!['pending', 'resolved', 'dismissed'].includes(status)) return json(res, 400, { error: '无效状态' });
  db.prepare('UPDATE reports SET status = ? WHERE id = ?').run(status, Number(req.params[0]));
  json(res, 200, { ok: true });
});

// 全站自检：后台一键体检（页面可达性 / 内联脚本语法 / 死链 / 版本号）
async function runSelfCheck() {
  const host = 'moonarmor.cn';
  const get = (p) => new Promise((resolve) => {
    const rq = https.get({ host, path: p, timeout: 12000, headers: { 'User-Agent': 'moonarmor-selfcheck' } }, (r) => {
      let d = ''; r.on('data', (c) => { d += c; if (d.length > 200000) r.destroy(); });
      r.on('end', () => resolve({ code: r.statusCode, body: d }));
      r.on('error', () => resolve({ code: 0, body: '' }));
    });
    rq.on('error', () => resolve({ code: 0, body: '' }));
    rq.on('timeout', () => { rq.destroy(); resolve({ code: 0, body: '' }); });
  });
  const pages = ['index','subscribe','pay','reader','category','service','user','login','article','agent','credit','shrmatch','calendar','discussion','governance','media','intent','listing','search','stats','admin','contract','register','privacy','user-agreement','risk-disclaimer'].map(p => '/' + p + '.html');
  pages.push('/', '/read', '/download', '/read/ch001', '/read/ch006', '/exchange.html', '/renovation.html', '/community.html');
  const ress = ['/app.js', '/app.css', '/qrcode.js', '/sw.js', '/favicon.ico', '/help-agent.js', '/window-controls.js', '/reading-progress.js', '/chapter-thoughts.js', '/chapter-ask.js', '/chapter-exlink.js', '/nav.registry.js'];
  const lines = []; let ok = 0, bad = 0; const issues = [];
  lines.push('===== 全站自检报告 ' + new Date().toLocaleString('zh-CN') + ' =====');
  lines.push('');
  lines.push('--- 1) 页面可达性 ---');
  for (const p of pages) { const r = await get(p); if (r.code === 200 || r.code === 302) ok++; else { bad++; lines.push('  ❌ ' + r.code + ' ' + p); issues.push({ sev: 'error', cat: '页面可达性', text: r.code + ' ' + p, where: p }); } }
  lines.push('  -> ' + (bad ? ('❌ ' + bad + ' 个异常') : '✅ 全部 ' + pages.length + ' 个页面正常'));
  lines.push('');
  lines.push('--- 2) 关键资源 ---');
  for (const p of ress) { const r = await get(p); if (r.code === 200) ok++; else { bad++; lines.push('  ❌ ' + r.code + ' ' + p); issues.push({ sev: 'error', cat: '关键资源', text: r.code + ' ' + p, where: p }); } }
  lines.push('  -> ' + (bad ? ('有异常见上') : '✅ 关键资源全部 200'));
  lines.push('');
  lines.push('--- 3) 内联脚本语法（防按钮失效） ---');
  for (const pg of ['/download', '/read/ch006']) {
    const r = await get(pg); const h = r.body || '';
    const re = /<script>([\s\S]*?)<\/script>/g; let m, i = 0, syntaxBad = 0;
    while ((m = re.exec(h))) { i++; try { new Function(m[1]); } catch (e) { syntaxBad++; lines.push('  ❌ ' + pg + ' 脚本块#' + i + ' ' + e.message); issues.push({ sev: 'error', cat: '内联脚本语法', text: pg + ' 脚本块#' + i + ' ' + e.message, where: pg }); } }
    if (syntaxBad) bad++; else { ok++; lines.push('  ✅ ' + pg + ' ' + i + ' 个脚本块语法正常'); }
  }
  lines.push('');
  lines.push('--- 4) 死链审计（首页内部链接） ---');
  const home = await get('/'); const hrefs = (home.body.match(/href="(\/[^"#?]*)"/g) || []).map(s => s.slice(6, -1));
  const uniq = [...new Set(hrefs)]; let dlBad = 0;
  for (const l of uniq) { const r = await get(l); if (r.code !== 200 && r.code !== 302 && r.code !== 401) { dlBad++; bad++; lines.push('  ❌ 死链 ' + r.code + ' ' + l); issues.push({ sev: 'warn', cat: '死链', text: r.code + ' ' + l, where: l }); } }
  lines.push('  -> ' + (dlBad ? (dlBad + ' 个死链，见上') : '✅ 无死链'));
  lines.push('');
  lines.push('--- 5) 版本号 ---');
  const sw = await get('/sw.js'); const sv = (sw.body.match(/moonarmor-v\d+/) || ['?'])[0];
  const dl = await get('/download'); const vv = (dl.body.match(/app\.js\?v=([a-z0-9-]+)/) || ['?', '?'])[1];
  lines.push('  sw.js = ' + sv + '  |  阅读/下载页 VIEW = ' + vv);
  lines.push('');
  lines.push('--- 6) 文案缺英文（双语闭环） ---');
  try {
    const ov = getSetting('i18n_override', { zh: {}, en: {} });
    const miss = Object.keys(ov.zh || {}).filter(k => !((ov.en || {})[k]));
    if (miss.length) { bad++; lines.push('  ❌ ' + miss.length + ' 个已录入文案缺英文（前5：' + miss.slice(0, 5).join('、') + '）'); issues.push({ sev: 'warn', cat: '双语', text: miss.length + ' 个文案缺英文', to: 'p14' }); }
    else lines.push('  ✅ 已录入文案英文齐全（基础词表请到「文案与文档」筛选“仅缺英文”复核）');
  } catch (e) { lines.push('  ⚠️ 文案检查跳过：' + e.message); }
  lines.push('');
  lines.push('===== 结论：' + (bad === 0 ? '✅ 全站健康，无异常' : ('❌ 发现 ' + bad + ' 项异常，请对照修复入口逐项处理')) + ' =====');
  return { report: lines.join('\n'), ok, bad, issues };
}
route('POST', '/api/admin/self-check', async (req, res) => {
  const u = authUser(req); if (!u || u.role !== 'admin') return json(res, 403, { error: '无权限' });
  const r = await runSelfCheck();
  json(res, 200, r);
});
// 别名：GET 方法也支持（文档点名接口）
route('GET', '/api/admin/self-check', async (req, res) => {
  const u = authUser(req); if (!u || u.role !== 'admin') return json(res, 403, { error: '无权限' });
  const r = await runSelfCheck();
  json(res, 200, r);
});
route('GET', '/api/admin/stats', async (req, res) => {
  const u = authUser(req); if (!u || u.role !== 'admin') return json(res, 403, { error: '无权限' });
  const count = (sql) => db.prepare(sql).get().c;
  const sum = (sql) => db.prepare(sql).get().s || 0;
  json(res, 200, {
    articles: { total: count('SELECT COUNT(*) c FROM articles'), draft: count('SELECT COUNT(*) c FROM articles WHERE status=\'draft\''), reviewed: count('SELECT COUNT(*) c FROM articles WHERE status=\'reviewed\''), published: count('SELECT COUNT(*) c FROM articles WHERE status=\'published\'') },
    users: count('SELECT COUNT(*) c FROM users'),
    comments: count('SELECT COUNT(*) c FROM comments'),
    tips: { total: count('SELECT COUNT(*) c FROM tips'), paid: count('SELECT COUNT(*) c FROM tips WHERE status=\'paid\''), amount: sum('SELECT SUM(amount) s FROM tips WHERE status=\'paid\'') },
    orders: { total: count('SELECT COUNT(*) c FROM orders'), paid: count('SELECT COUNT(*) c FROM orders WHERE status=\'paid\''), amount: sum('SELECT SUM(amount) s FROM orders WHERE status=\'paid\'') },
    pool: sum('SELECT SUM(pool_amount) s FROM dividend_ledger'),
    // 与 /api/admin/ledger 同口径：已确认的收入合计，保证仪表盘与账本数字一致
    revenue: sum('SELECT COALESCE(SUM(CASE WHEN direction = \'in\' AND status = \'confirmed\' THEN amount ELSE 0 END),0) s FROM ledger'),
    tasks: { queued: count('SELECT COUNT(*) c FROM agent_tasks WHERE status IN (\'queued\',\'running\')'), draft: count('SELECT COUNT(*) c FROM agent_tasks WHERE status=\'draft\'') },
    dist: count('SELECT COUNT(*) c FROM distribution_logs WHERE status=\'mock\'')
  });
});

route('GET', '/api/admin/articles', async (req, res) => {
  const u = authUser(req); if (!u || !['admin', 'core'].includes(u.role)) return json(res, 403, { error: '无权限' });
  const rows = db.prepare('SELECT * FROM articles ORDER BY id DESC LIMIT 500').all().map(r => articleRow(r, false));
  json(res, 200, rows);
});

route('POST', '/api/admin/articles', async (req, res) => {
  const u = authUser(req); if (!u || !['admin', 'core'].includes(u.role)) return json(res, 403, { error: '无权限' });
  const b = await readBody(req, 5e6);
  if (!b.title || !b.content) return json(res, 400, { error: '标题和内容必填' });
  const r = db.prepare('INSERT INTO articles (title, slug, content, summary, author_id, cat1_id, cat2_id, cat3_id, granularity, app_areas, tags, status, is_paid, price, source_doc) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)')
    .run(String(b.title), b.slug || (slugify(b.title) + '-' + Date.now()), String(b.content), String(b.summary || '').slice(0, 300), u.id, b.cat1_id || null, b.cat2_id || null, b.cat3_id || null, b.granularity || '', JSON.stringify(b.app_areas || []), JSON.stringify(b.tags || []), b.status || 'draft', b.is_paid ? 1 : 0, b.price || 0, b.source_doc || '');
  json(res, 200, { ok: true, id: Number(r.lastInsertRowid) });
});

route('PUT', '/api/admin/articles/:id', async (req, res) => {
  const u = authUser(req); if (!u || !['admin', 'core'].includes(u.role)) return json(res, 403, { error: '无权限' });
  const b = await readBody(req, 5e6);
  const id = Number(req.params[0]);
  const a = db.prepare('SELECT * FROM articles WHERE id = ?').get(id);
  if (!a) return json(res, 404, { error: 'not found' });
  db.prepare('INSERT INTO article_versions (article_id, title, content, summary, version_no, change_note) VALUES (?, ?, ?, ?, ?, ?)').run(a.id, a.title, a.content, a.summary, a.version, String(b.change_note || '编辑保存'));
  db.prepare('UPDATE articles SET title = ?, content = ?, summary = ?, cat1_id = ?, cat2_id = ?, cat3_id = ?, granularity = ?, app_areas = ?, tags = ?, is_paid = ?, price = ?, version = version + 1, updated_at = datetime(\'now\',\'localtime\') WHERE id = ?')
    .run(String(b.title ?? a.title), String(b.content ?? a.content), String(b.summary ?? a.summary), b.cat1_id ?? a.cat1_id, b.cat2_id ?? a.cat2_id, b.cat3_id ?? a.cat3_id, b.granularity ?? a.granularity, JSON.stringify(b.app_areas ?? JSON.parse(a.app_areas)), JSON.stringify(b.tags ?? JSON.parse(a.tags)), b.is_paid ?? a.is_paid, b.price ?? a.price, id);
  const a2 = db.prepare('SELECT * FROM articles WHERE id = ?').get(id);
  if (a2) appendContentRecord(a2, 'edit', String(b.change_note || '编辑保存'));
  json(res, 200, { ok: true });
});

route('POST', '/api/admin/articles/status', async (req, res) => {
  const u = authUser(req); if (!u || u.role !== 'admin') return json(res, 403, { error: '无权限' });
  const b = await readBody(req, 1e6);
  const ids = Array.isArray(b.ids) ? b.ids.map(Number) : [Number(b.id)];
  const status = String(b.status || '');
  if (!['draft', 'reviewed', 'published', 'archived'].includes(status)) return json(res, 400, { error: '无效状态' });
  const stmt = db.prepare('UPDATE articles SET status = ?, published_at = CASE WHEN ? = \'published\' AND published_at IS NULL THEN datetime(\'now\',\'localtime\') ELSE published_at END WHERE id = ?');
  for (const id of ids) { stmt.run(status, status, id); if (status === 'published') { const a = db.prepare('SELECT * FROM articles WHERE id = ?').get(id); if (a) { syncGitHub(a); appendContentRecord(a, 'publish', '发布'); } } }
  json(res, 200, { ok: true, count: ids.length });
});

route('POST', '/api/admin/import', async (req, res) => {
  const u = authUser(req); if (!u || !['admin', 'core'].includes(u.role)) return json(res, 403, { error: '无权限' });
  const b = await readBody(req, 10e6);
  const text = String(b.text || '');
  if (text.length < 20) return json(res, 400, { error: '内容过短' });
  const title = String(b.title || '').trim() || (text.split('\n')[0] || '未命名').slice(0, 60);
  const r = db.prepare('INSERT INTO articles (title, slug, content, summary, author_id, cat1_id, cat2_id, cat3_id, granularity, status, source_doc) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, \'draft\', ?)')
    .run(title, slugify(title) + '-' + Date.now(), text, String(b.summary || '').slice(0, 300), u.id, b.cat1_id || null, b.cat2_id || null, b.cat3_id || null, b.granularity || 'L4', b.source_doc || '后台导入');
  json(res, 200, { ok: true, id: Number(r.lastInsertRowid) });
});

route('GET', '/api/admin/users', async (req, res) => {
  const u = authUser(req); if (!u || u.role !== 'admin') return json(res, 403, { error: '无权限' });
  json(res, 200, db.prepare('SELECT id, phone, nickname, role, verified, created_at FROM users ORDER BY id DESC LIMIT 200').all());
});

// 管理员重置指定用户密码（忘记密码闭环：无短信/邮件，由管理员核验身份后重置）
route('POST', '/api/admin/users/reset-password', async (req, res) => {
  const u = authUser(req); if (!u || u.role !== 'admin') return json(res, 403, { error: '无权限' });
  const b = await readBody(req, 1e5);
  const id = Number(b.user_id); if (!id) return json(res, 400, { error: '缺少 user_id' });
  const newPw = String(b.new_password || ''); if (newPw.length < 6) return json(res, 400, { error: '新密码至少6位' });
  const r = db.prepare('UPDATE users SET password_hash = ?, updated_at = datetime(\'now\',\'localtime\') WHERE id = ?').run(hashPassword(newPw), id);
  if (!r.changes) return json(res, 404, { error: '用户不存在' });
  json(res, 200, { ok: true });
});

route('PUT', '/api/admin/settings', async (req, res) => {
  const u = authUser(req); if (!u || u.role !== 'admin') return json(res, 403, { error: '无权限' });
  const b = await readBody(req, 2e6);
  for (const [k, v] of Object.entries(b)) setSetting(k, mergeSecrets(v, getSetting(k, null)));
  json(res, 200, { ok: true });
});

route('GET', '/api/admin/settings', async (req, res) => {
  const u = authUser(req); if (!u || u.role !== 'admin') return json(res, 403, { error: '无权限' });
  const rows = db.prepare('SELECT key, value FROM settings').all();
  const out = {}; for (const r of rows) out[r.key] = JSON.parse(r.value);
  json(res, 200, maskSecrets(out));
});

// ===== 文案覆盖层（后台可编辑，前台实时生效）=====
// 公共：返回当前文案覆盖字典 { zh:{key:val}, en:{key:val} } 与文档覆盖 { path: html }
route('GET', '/api/i18n', async (req, res) => {
  const ov = getSetting('i18n_override', { zh: {}, en: {} });
  const docs = getSetting('doc_override', {});
  json(res, 200, { ov: { zh: ov.zh || {}, en: ov.en || {} }, docs: docs || {} });
});
// 后台：保存文案覆盖（局部合并）
route('PUT', '/api/admin/i18n', async (req, res) => {
  const u = authUser(req); if (!isSuperAdmin(u)) return json(res, 403, { error: '仅超级管理员（VX）可修改文案' });
  const b = await readBody(req, 2e6);
  const cur = getSetting('i18n_override', { zh: {}, en: {} });
  if (b.zh) for (const [k, v] of Object.entries(b.zh)) { if (v === '' || v == null) delete cur.zh[k]; else cur.zh[k] = v; }
  if (b.en) for (const [k, v] of Object.entries(b.en)) { if (v === '' || v == null) delete cur.en[k]; else cur.en[k] = v; }
  setSetting('i18n_override', cur);
  json(res, 200, { ok: true });
});
// 后台：保存/读取文档覆盖（整篇 HTML 可编辑）
route('PUT', '/api/admin/docs', async (req, res) => {
  const u = authUser(req); if (!isSuperAdmin(u)) return json(res, 403, { error: '仅超级管理员（VX）可修改文档' });
  const b = await readBody(req, 4e6);
  const docs = getSetting('doc_override', {});
  if (b && b.path) { if (b.html === '' || b.html == null) delete docs[b.path]; else docs[b.path] = b.html; setSetting('doc_override', docs); }
  json(res, 200, { ok: true });
});

route('GET', '/api/admin/orders', async (req, res) => {
  const u = authUser(req); if (!u || u.role !== 'admin') return json(res, 403, { error: '无权限' });
  json(res, 200, db.prepare('SELECT * FROM orders ORDER BY id DESC LIMIT 200').all());
});
route('GET', '/api/admin/tips', async (req, res) => {
  const u = authUser(req); if (!u || u.role !== 'admin') return json(res, 403, { error: '无权限' });
  json(res, 200, db.prepare('SELECT * FROM tips ORDER BY id DESC LIMIT 200').all());
});
route('POST', '/api/admin/tips/:id/confirm', async (req, res) => {
  const u = authUser(req); if (!u || u.role !== 'admin') return json(res, 403, { error: '无权限' });
  const t = db.prepare('SELECT * FROM tips WHERE id = ?').get(Number(req.params[0]));
  if (!t) return json(res, 404, { error: 'not found' });
  payTip(t.order_no);
  json(res, 200, { ok: true });
});

// ===== 支付宝回调 =====
function settleDownloadOrder(no) {
  try {
    const o = db.prepare('SELECT * FROM download_orders WHERE order_no = ?').get(no);
    if (!o) return false;
    if (o.status === 'paid') return true;
    const g = downloadEngine.grantLicense(o.user_id, o.scope, o.target, no, o.amount, o.pay_channel || 'alipay');
    db.prepare("UPDATE download_orders SET status = 'paid', paid_at = datetime('now','localtime') WHERE order_no = ?").run(no);
    db.prepare("UPDATE ledger SET status = 'confirmed', confirmed_at = datetime('now','localtime') WHERE order_no = ?").run(no);
    try { sseEngine.sendEvent(o.user_id, 'DOWNLOAD', { scope: o.scope, target: o.target, expires_at: g.expires_at }); } catch (e) {}
    return true;
  } catch (e) { return false; }
}
function settleContractPayment(no) {
  try {
    const p = contractEngine.getPaymentByOrderNo(no);
    if (!p) return false;
    if (p.status === 'completed') return true;
    const r = contractEngine.completePayment(p.id, no);
    if (!r.success) return false;
    db.prepare("UPDATE ledger SET status = 'confirmed', confirmed_at = datetime('now','localtime') WHERE order_no = ?").run(no);
    try { sseEngine.sendEvent(p.payer_id, 'CONTRACT_PAY', { contract_id: p.contract_id, payment_id: p.id, status: 'completed' }); } catch (e) {}
    return true;
  } catch (e) { console.error('[settleContractPayment]', e.message); return false; }
}
function settleByOrderNo(no) {
  if (!no) return;
  if (no.startsWith('LST')) settleListingTrade(no);      // sHRmatch 撮合成交
  else if (no.startsWith('OR')) payOrder(no);             // 商品订单
  else if (no.startsWith('MA')) payTip(no);               // 打赏
  else if (no.startsWith('DL')) settleDownloadOrder(no);  // 文档下载授权
  else if (no.startsWith('CP')) settleContractPayment(no); // 合同付款
}
route('GET', '/api/pay/return/alipay', async (req, res) => {
  const u = new URL(req.url, 'http://x');
  const no = u.searchParams.get('out_trade_no');
  if (no) settleByOrderNo(no);
  res.writeHead(302, { Location: '/pay.html?order_no=' + encodeURIComponent(no || '') + '&ok=1' });
  res.end();
});
route('POST', '/api/pay/notify/alipay', async (req, res) => {
  let raw = ''; for await (const c of req) raw += c;
  const params = new URLSearchParams(raw);
  const ok = pay.verifyNotify(Object.fromEntries(params));
  const no = params.get('out_trade_no');
  if (!ok) console.error('[pay] alipay notify 验签失败 out_trade_no=' + no + ' status=' + params.get('trade_status'));
  if (ok && no && params.get('trade_status') === 'TRADE_SUCCESS') settleByOrderNo(no);
  res.writeHead(200, { 'Content-Type': 'text/plain' }); res.end('success');
});

// 二维码渲染（文本 → PNG），供微信/支付宝出码使用
route('GET', '/api/qr.png', async (req, res) => {
  const d = String((req.query && req.query.d) || '');
  if (!d) { res.writeHead(400, { 'Content-Type': 'text/plain' }); return res.end('missing d'); }
  let QR = null;
  try { QR = require('/opt/qrgen/node_modules/qrcode'); } catch (e) { try { QR = require('qrcode'); } catch (e2) { QR = null; } }
  if (!QR) { res.writeHead(503, { 'Content-Type': 'text/plain' }); return res.end('qr unavailable'); }
  try {
    const buf = await QR.toBuffer(d, { width: Number((req.query && req.query.s) || 320) || 320, margin: 1, errorCorrectionLevel: 'M' });
    res.writeHead(200, { 'Content-Type': 'image/png', 'Cache-Control': 'public, max-age=86400' });
    return res.end(buf);
  } catch (e) { res.writeHead(500, { 'Content-Type': 'text/plain' }); return res.end('qr error'); }
});

// 支付宝当面付：为订单生成付款二维码（240708b reconcile 误删，自历史原文恢复）
route('POST', '/api/pay/alipay-qr', async (req, res) => {
  try {
    const b = await readBody(req, 1e5);
    const no = String(b.order_no || '');
    if (!no) return json(res, 400, { success: false, error: '缺少订单号' });
    let amount = Number(b.amount) || 0;
    if (!amount) {
      const o = db.prepare('SELECT amount FROM download_orders WHERE order_no = ?').get(no);
      if (o) amount = o.amount;
    }
    if (!amount) { const t = db.prepare('SELECT amount FROM tips WHERE order_no = ?').get(no); if (t) amount = t.amount; }
    if (!amount) return json(res, 400, { success: false, error: '订单不存在' });
    // 1) 优先「当面付」——可在本页直接弹出二维码
    const r = await pay.precreate(no, '月亮盔甲 · 支持共建', amount);
    const qc = r.ok ? ((r.data && r.data.qr_code) || '') : '';
    if (!qc) {
      // 2) 回退「电脑网站支付」——收银台页面本身就带二维码，可内嵌展示
      const back = String(b.back || '').indexOf('moonarmor.cn') >= 0 ? String(b.back) : '';
      const f = pay.buildPagePayForm(no, '月亮盔甲 · 支持共建', amount, back ? { returnUrl: 'https://moonarmor.cn/api/pay/return/alipay?back=' + encodeURIComponent(back) } : null);
      return json(res, 200, {
        success: false,
        error: r.error || '支付宝未返回二维码',
        fallback: true,
        cashier_url: f.url || null,
      });
    }
    json(res, 200, { success: true, qr_code: qc, qr_img: '/api/qr.png?d=' + encodeURIComponent(qc) + '&s=340', amount: amount });
  } catch (e) { json(res, 500, { success: false, error: e.message }); }
});

// 支付通道自检（管理员一键检测；240708b reconcile 误删，自历史原文恢复）
route('POST', '/api/admin/pay-check', async (req, res) => {
  const u = authUser(req); if (!u || u.role !== 'admin') return json(res, 403, { error: '无权限' });
  const out = { alipay: {}, wechat: {}, bank: {}, mode: getSetting('payment_mode', 'simulate') };
  try {
    const ap = getSetting('alipay', null);
    out.alipay.configured = !!(ap && ap.appid && ap.privateKey);
    out.alipay.appid = (ap && ap.appid) || null;
    if (out.alipay.configured) {
      const n1 = 'CHK' + Date.now();
      const p = await pay.precreate(n1, '通道自检', 0.01);
      out.alipay.precreate = p.ok ? 'ok' : String(p.error).slice(0, 60);
      const q = await pay.queryTrade(n1);
      out.alipay.query = q.ok ? 'ok' : (String(q.error).indexOf('TRADE_NOT_EXIST') >= 0 ? 'ok（接口有权限）' : String(q.error).slice(0, 60));
      const f = pay.buildPagePayForm(n1, '通道自检', 0.01);
      out.alipay.cashier = f.url ? 'ok' : 'fail';
    }
  } catch (e) { out.alipay.error = e.message; }
  try {
    const wp = getSetting('wechat_pay', null);
    out.wechat.configured = !!(wp && wp.mchid);
    out.wechat.mchid = (wp && wp.mchid) || null;
    out.wechat.ready = wxpay.ready();
    if (out.wechat.ready) {
      const n2 = 'CHK' + Date.now();
      const w = await wxpay.nativePay(n2, '通道自检', 0.01);
      out.wechat.native = w.ok ? 'ok' : String(w.error).slice(0, 60);
    }
  } catch (e) { out.wechat.error = e.message; }
  try { const ba = getSetting('bank_account', null); out.bank.configured = !!(ba && ba.account_no); out.bank.account_no = (ba && ba.account_no) || null; } catch (e) { out.bank.error = e.message; }
  json(res, 200, { success: true, data: out });
});

// 微信 Native 扫码出码（章节下载等入口复用）
route('POST', '/api/pay/wechat-native', async (req, res) => {
  try {
    if (!wxpay.ready()) return json(res, 200, { success: false, error: '微信支付未配置', fallback: true });
    const b = await readBody(req, 1e5);
    const no = String(b.order_no || '');
    if (!no) return json(res, 400, { success: false, error: '缺少订单号' });
    let amount = Number(b.amount) || 0;
    if (!amount) { const o = db.prepare('SELECT amount FROM download_orders WHERE order_no = ?').get(no); if (o) amount = o.amount; }
    if (!amount) { const t = db.prepare('SELECT amount FROM tips WHERE order_no = ?').get(no); if (t) amount = t.amount; }
    if (!amount) return json(res, 400, { success: false, error: '订单不存在' });
    const r = await wxpay.nativePay(no, '月亮盔甲下载/打赏', amount);
    if (!r.ok) return json(res, 502, { success: false, error: r.error });
    json(res, 200, { success: true, code_url: r.data.code_url, qr_img: '/api/qr.png?d=' + encodeURIComponent(r.data.code_url), amount: amount });
  } catch (e) { json(res, 500, { success: false, error: e.message }); }
});

// 微信 JSAPI 公众号/小程序支付：返回 prepay_id 签名参数供前端 WeixinJSBridge / wx.requestPayment 唤起
route('POST', '/api/pay/wechat-jsapi', async (req, res) => {
  try {
    if (!wxpay.ready()) return json(res, 200, { success: false, error: '微信支付未配置' });
    const b = await readBody(req, 1e5);
    const no = String(b.order_no || '');
    const openid = String(b.openid || '');
    if (!no) return json(res, 400, { success: false, error: '缺少订单号' });
    if (!openid) return json(res, 400, { success: false, error: '缺少 openid（公众号/小程序需先 OAuth 授权）' });
    let amount = Number(b.amount) || 0;
    if (!amount) { const o = db.prepare('SELECT amount FROM download_orders WHERE order_no = ?').get(no); if (o) amount = o.amount; }
    if (!amount) { const t = db.prepare('SELECT amount FROM tips WHERE order_no = ?').get(no); if (t) amount = t.amount; }
    if (!amount) return json(res, 400, { success: false, error: '订单不存在' });
    const r = await wxpay.jsapiPay(no, '月亮盔甲下载/打赏', amount, openid);
    if (!r.ok) return json(res, 502, { success: false, error: r.error });
    const prepayId = r.data.prepay_id;
    const params = wxpay.buildJsapiParams(prepayId);
    json(res, 200, { success: true, prepay_id: prepayId, jsapiParams: params });
  } catch (e) { json(res, 500, { success: false, error: e.message }); }
});

// 微信 H5 支付：返回 mweb_url，前端跳转即可唤起微信内置浏览器收银台
route('POST', '/api/pay/wechat-h5', async (req, res) => {
  try {
    if (!wxpay.ready()) return json(res, 200, { success: false, error: '微信支付未配置' });
    const b = await readBody(req, 1e5);
    const no = String(b.order_no || '');
    if (!no) return json(res, 400, { success: false, error: '缺少订单号' });
    let amount = Number(b.amount) || 0;
    if (!amount) { const o = db.prepare('SELECT amount FROM download_orders WHERE order_no = ?').get(no); if (o) amount = o.amount; }
    if (!amount) { const t = db.prepare('SELECT amount FROM tips WHERE order_no = ?').get(no); if (t) amount = t.amount; }
    if (!amount) return json(res, 400, { success: false, error: '订单不存在' });
    const ip = (req.headers && (req.headers['x-forwarded-for'] || req.headers['x-real-ip'])) ? String(req.headers['x-forwarded-for'] || req.headers['x-real-ip']).split(',')[0].trim() : '127.0.0.1';
    const r = await wxpay.h5Pay(no, '月亮盔甲下载/打赏', amount, ip);
    if (!r.ok) return json(res, 502, { success: false, error: r.error });
    json(res, 200, { success: true, mweb_url: r.data.mweb_url });
  } catch (e) { json(res, 500, { success: false, error: e.message }); }
});

// 微信支付结果回调（AES-GCM 解密成功即视为可信来源）
route('POST', '/api/pay/notify/wechat', async (req, res) => {
  let raw = '';
  try {
    for await (const c of req) raw += c;
    const j = JSON.parse(raw || '{}');
    let settled = false;
    if (j.resource) {
      const d = wxpay.decryptResource(j.resource);
      if (d && d.out_trade_no && d.trade_state === 'SUCCESS') { settleByOrderNo(d.out_trade_no); settled = true; }
    }
    res.writeHead(200, { 'Content-Type': 'application/json' });
    return res.end(JSON.stringify({ code: 'SUCCESS', message: settled ? '已开通' : '已接收' }));
  } catch (e) {
    res.writeHead(500, { 'Content-Type': 'application/json' });
    return res.end(JSON.stringify({ code: 'FAIL', message: String(e.message).slice(0, 100) }));
  }
});

// 订单状态：本地优先，未到账则主动向支付宝/微信核验（后台自我验证付款）
route('GET', '/api/pay/status', async (req, res) => {
  try {
    const no = String((req.query && req.query.order_no) || '');
    if (!no) return json(res, 400, { success: false, error: '缺少订单号' });
    const out = { success: true, order_no: no, paid: false, status: 'pending' };
    const dl = db.prepare('SELECT * FROM download_orders WHERE order_no = ?').get(no);
    const tip = db.prepare('SELECT * FROM tips WHERE order_no = ?').get(no);
    if ((dl && dl.status === 'paid') || (tip && tip.status === 'paid')) {
      out.paid = true; out.status = 'paid';
      if (dl) { out.kind = 'download'; out.scope = dl.scope; out.slug = dl.target; }
      else out.kind = 'tip';
      return json(res, 200, out);
    }
    if (getSetting('payment_mode', 'simulate') === 'alipay') {
      const q = await pay.queryTrade(no);
      if (q.ok && q.data) {
        const st = q.data.trade_status;
        if (st === 'TRADE_SUCCESS' || st === 'TRADE_FINISHED') {
          settleByOrderNo(no);
          out.paid = true; out.status = 'paid'; out.verified = 'alipay_query';
          const dl2 = db.prepare('SELECT * FROM download_orders WHERE order_no = ?').get(no);
          if (dl2) { out.kind = 'download'; out.scope = dl2.scope; out.slug = dl2.target; } else out.kind = 'tip';
          return json(res, 200, out);
        }
        out.trade_status = st || null;
      } else if (q.error) { out.query_error = q.error; }
    }
    if (!out.paid && wxpay.ready()) {
      const w = await wxpay.queryOrder(no);
      if (w.ok && w.data) {
        const st2 = w.data.trade_state;
        if (st2 === 'SUCCESS') {
          settleByOrderNo(no);
          out.paid = true; out.status = 'paid'; out.verified = 'wechat_query';
          const dl3 = db.prepare('SELECT * FROM download_orders WHERE order_no = ?').get(no);
          if (dl3) { out.kind = 'download'; out.scope = dl3.scope; out.slug = dl3.target; } else out.kind = 'tip';
          return json(res, 200, out);
        }
        out.wx_trade_state = st2 || null;
      } else if (w.error) { out.wx_query_error = w.error; }
    }
    json(res, 200, out);
  } catch (e) { json(res, 500, { success: false, error: e.message }); }
});

// ===== 网站地图（全站 token：页面/章节/文章/类目/应用领域）=====
route('GET', '/api/sitemap', async (req, res) => {
  try {
    const PT = { 'index.html':'首页','cschat-cell.html':'CSchat-Cell 细胞协作','archive.html':'个人档案','shrmatch.html':'sHRmatch 撮合','exchange.html':'超级交易所','credit.html':'信用中心','search.html':'搜索','contract.html':'合同中心','intent.html':'智能撮合','service.html':'产品服务','admin.html':'管理后台','user.html':'个人中心','login.html':'登录','register.html':'注册','category.html':'分类导航','reader.html':'在线阅读','article.html':'文章阅读','media.html':'视频工作台','stats.html':'数据统计','discussion.html':'讨论区','governance.html':'治理中心','subscribe.html':'订阅会员','pay.html':'支付','privacy.html':'隐私政策','user-agreement.html':'用户协议','risk-disclaimer.html':'风险提示','calendar.html':'排期日历','listing.html':'品种上架','bind.html':'账号绑定','agent.html':'智能体' };
    const pages = fs.readdirSync(WEB_ROOT).filter(f => f.endsWith('.html')).map(f => ({ type:'page', title: PT[f] || f.replace('.html',''), url:'/' + f }));
    const chapters = bookEngine.listBooks().map(b => ({ type:'chapter', title: b.title, url:'/read/' + b.slug, no: b.no || 0 }));
    const articles = db.prepare("SELECT slug, title FROM articles WHERE status='published' ORDER BY id DESC").all().map(a => ({ type:'article', title: a.title, url:'/article.html?slug=' + a.slug }));
    const categories = db.prepare("SELECT id, name, level FROM categories ORDER BY sort_order, id").all().map(c => ({ type:'category', title: c.name, url:'/category.html?cat=' + c.id }));
    const areas = db.prepare("SELECT id, name FROM app_areas ORDER BY sort_order, id").all().map(a => ({ type:'area', title: a.name, url:'/category.html' }));
    json(res, 200, { success: true, data: { pages, chapters, articles, categories, areas } });
  } catch (e) { json(res, 500, { success: false, error: e.message }); }
});

// ===== 静态文件 =====
const MIME = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.json': 'application/json', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.gif': 'image/gif', '.svg': 'image/svg+xml', '.ico': 'image/x-icon', '.woff2': 'font/woff2', '.md': 'text/markdown; charset=utf-8', '.webmanifest': 'application/manifest+json; charset=utf-8' };
function serveStatic(req, res, pathname) {
  let p = pathname === '/' ? '/index.html' : pathname;
  let fp = path.join(WEB_ROOT, decodeURIComponent(p));
  if (!fp.startsWith(WEB_ROOT)) return json(res, 403, { error: 'forbidden' });
  if (!fs.existsSync(fp) || fs.statSync(fp).isDirectory()) { fp = path.join(fp, 'index.html'); if (!fs.existsSync(fp)) return json(res, 404, { error: 'not found' }); }
  const ext = path.extname(fp).toLowerCase();
  // 文档页可被后台覆盖（优先读库），key 形如 'privacy.html' 或 '/privacy.html'
  if (ext === '.html') {
    try {
      const docs = getSetting('doc_override', {});
      const base = path.basename(fp);
      const ovHtml = docs[base] || docs['/' + base] || docs[p.replace(/^\//, '')];
      if (ovHtml) {
        res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-cache, no-store, must-revalidate' });
        return res.end(injectWidget(ovHtml));
      }
    } catch (e) {}
  }
  if (ext === '.html') {
    let html = fs.readFileSync(fp, 'utf8');
    html = injectWidget(html);
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-cache, no-store, must-revalidate' });
    return res.end(html);
  }
  res.writeHead(200, { 'Content-Type': MIME[ext] || 'application/octet-stream', 'Cache-Control': ['.html','.js','.css','.md','.txt'].includes(ext) ? 'no-cache, no-store, must-revalidate' : 'public, max-age=86400' });
  fs.createReadStream(fp).pipe(res);
}

// 注入全站智能体浮窗（CSS + JS），在 </body> 前插入；无 </body> 则追加末尾
function injectWidget(html) {
  // agent-chat：站内 AI 助手；live-chat：直接找 asus（开发迭代用，暴露问题秒级响应）
  const tag = '<link rel="stylesheet" href="/agent-chat.css"><script src="/agent-chat.js" defer></script><script src="/live-chat.js" defer></script>';
  if (html.indexOf('</body>') >= 0) return html.replace(/<\/body>/i, tag + '</body>');
  return html + tag;
}

// ---------- 主服务 ----------
// ===== 聚合收款码页面 HTML（一码通：微信/支付宝扫码自动分流）=====
function aggShell(title, body) {
  return '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">' +
    '<title>' + title + '</title>' +
    '<style>*{box-sizing:border-box}html,body{margin:0;padding:0;width:100%;min-height:100vh;background:#f6f7fb;font-family:-apple-system,"PingFang SC","Microsoft YaHei",sans-serif;color:#1f2328;-webkit-text-size-adjust:100%}' +
    '.wrap{width:100%;max-width:460px;margin:0 auto;padding:20px 14px;box-sizing:border-box;text-align:center}' +
    '.card{background:#fff;border-radius:16px;padding:22px 16px;box-shadow:0 6px 24px rgba(0,0,0,.06)}' +
    '.amt{font-size:30px;font-weight:700;color:#07c160;margin:2px 0 12px}.amt.blue{color:#1677ff}' +
    'h2{font-size:17px;margin:0 0 4px}.sub{color:#8b8b8b;font-size:13px;margin-bottom:12px}' +
    'img{width:100%;max-width:260px;height:auto;border-radius:12px;display:block;margin:0 auto}.tip{color:#b8b8b8;font-size:12px;margin-top:14px;line-height:1.6}' +
    '.spin{width:34px;height:34px;border:3px solid #e3e6ea;border-top-color:#1677ff;border-radius:50%;margin:14px auto;animation:sp 1s linear infinite}@keyframes sp{to{transform:rotate(360deg)}}' +
    '</style></head><body><div class="wrap"><div class="card">' + body + '</div>' +
    '<div class="tip">月亮盔甲 moonarmor.cn</div></div></body></html>';
}
function aggWechatHtml(a) {
  // 微信内：直接展示打赏收款码；金额由支付页选定，这里不再重复选金额
  return aggShell('微信支付', '<div class="amt">¥' + a.toFixed(2) + '</div>' +
    '<img src="/wx-zanshang.jpg?v=50" alt="微信收款码">' +
    '<div class="tip">长按识别二维码完成支付</div>');
}
function aggAlipayHtml(a, form) {
  // 支付宝内：page.pay 表单自动提交 → 直接弹付款密码框（手机端全屏适配）
  const inputs = (form && form.form) ? form.form : '';
  if (!inputs) {
    return aggShell('支付宝支付', '<h2>支付宝支付</h2><div class="amt blue">¥' + a.toFixed(2) + '</div>' +
      '<div class="sub" style="color:#e5484d">支付暂不可用，请返回后重试</div>');
  }
  return '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">' +
    '<title>支付宝支付</title><style>*{box-sizing:border-box}html,body{margin:0;padding:0;width:100%;min-height:100vh;background:#f6f7fb;font-family:-apple-system,"PingFang SC",sans-serif;-webkit-text-size-adjust:100%}.center{width:100%;max-width:360px;margin:0 auto;padding:24px 16px;text-align:center}.amt{font-size:24px;font-weight:700;color:#1677ff;margin:0 0 12px}.spin{width:28px;height:28px;border:3px solid #e3e6ea;border-top-color:#1677ff;border-radius:50%;margin:12px auto;animation:sp 1s linear infinite}@keyframes sp{to{transform:rotate(360deg)}}.t{color:#8b8b8b;font-size:13px}</style></head>' +
    '<body><div class="center"><div class="amt">¥' + a.toFixed(2) + '</div><div class="spin"></div><div class="t">正在调起支付宝…</div>' +
    '<form id="apf" method="post" action="https://openapi.alipay.com/gateway.do" accept-charset="utf-8" style="display:none">' + inputs + '</form>' +
    '<script>setTimeout(function(){try{document.getElementById("apf").submit()}catch(e){}},300);<' + '/script></div></body></html>';
}
function aggHintHtml(a) {
  return aggShell('扫码支付', '<h2>请用微信或支付宝扫码支付</h2>' +
    '<div class="amt">¥' + a.toFixed(2) + '</div>' +
    '<img src="/wx-zanshang.jpg?v=50" alt="收款码">' +
    '<div class="tip">用微信「扫一扫」或支付宝「扫一扫」扫描二维码即可付款</div>');
}
// 支付宝支付页：建单 + page.pay 表单自动提交 → 弹起付款密码框
function buildAlipayPage(a, req) {
  const no = orderNo('AG');
  const user = authUser(req);
  db.prepare('INSERT INTO tips (article_id, user_id, nickname, amount, message, order_no, pay_channel, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)')
    .run(null, user ? user.id : null, user ? user.nickname : '扫码读者', a, '', no, 'alipay', 'pending');
  const form = pay.buildPagePayForm(no, '打赏支持月亮盔甲', a);
  return aggAlipayHtml(a, form);
}

const server = http.createServer(async (req, res) => {
  let u;
  try {
    u = new URL(req.url, 'http://x');
  } catch (e) {
    // 畸形 URL（如 //、含非法字符）：直接 400，防止未捕获异常导致进程崩溃重启
    res.writeHead(400, { 'Content-Type': 'text/plain; charset=utf-8' });
    return res.end('Bad Request');
  }
  const pathname = u.pathname;
  REQ_LANG = String(req.headers['x-lang'] || '').toLowerCase().startsWith('en') ? 'en' : 'zh';
  if (REQ_LANG !== 'en') {
    const ck = String(req.headers['cookie'] || '');
    const m = ck.match(/(?:^|;\s*)moonarmor_lang=(en|zh)/);
    if (m) REQ_LANG = m[1] === 'en' ? 'en' : 'zh';
    else if (String(req.headers['accept-language'] || '').toLowerCase().startsWith('en')) REQ_LANG = 'en';
  }
  req.query = Object.fromEntries(u.searchParams);
    // 在线阅读免费（md/章节列表/md 图片）；PDF 下载付费（订阅会员或口令）
    const isPaidArea = pathname === '/api/chapters/pdfs' || (pathname.startsWith('/chapters/') && pathname.toLowerCase().endsWith('.pdf'));
    if (isPaidArea && !checkReaderOrSubscriber(req)) return json(res, 401, { error: 'PDF 下载需订阅会员' });
  try {
    // 聚合收款码：一码通（微信/支付宝都能扫），按扫码 UA 自动分流
    // 微信扫 → 显示微信打赏码图片（扫码即输密码）
    // 支付宝扫 → 自动提交 page.pay 表单 → 支付宝内直接弹付款密码框
    if (pathname === '/pay/agg') {
      const ua = String(req.headers['user-agent'] || '');
      let a = parseFloat(u.searchParams.get('a') || '10');
      if (!isFinite(a) || a <= 0) a = 10;
      a = Math.round(a * 100) / 100;
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
      if (/MicroMessenger/i.test(ua)) {
        // 微信内：直接展示打赏收款码
        return res.end(aggWechatHtml(a));
      }
      if (/AlipayClient/i.test(ua)) {
        return res.end(buildAlipayPage(a, req));
      }
      // 普通浏览器打开：提示用微信/支付宝扫码
      return res.end(aggHintHtml(a));
    }
    // 支付宝专用端点：永远只返回支付宝支付页（不依赖 UA 分流，杜绝串到微信码）
    if (pathname === '/pay/alipay') {
      let a = parseFloat(u.searchParams.get('a') || '10');
      if (!isFinite(a) || a <= 0) a = 10;
      a = Math.round(a * 100) / 100;
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
      return res.end(buildAlipayPage(a, req));
    }
    // 扫码支付短链：/pay/qr?o=订单号&a=金额 → 支付页
    if (pathname === '/pay/qr') {
      const o = u.searchParams.get('o') || '';
      const a = u.searchParams.get('a') || '';
      const plan = u.searchParams.get('plan') || '';
      res.writeHead(302, { Location: '/pay.html?o=' + encodeURIComponent(o) + '&a=' + encodeURIComponent(a) + (plan ? '&plan=' + encodeURIComponent(plan) : '') + '&from=qr' });
      return res.end();
    }
    if (pathname.startsWith('/api/')) {
      // 细胞产品的接口统一门禁：人类走 cookie，AI 走 Bearer token（VX：DeepSeek Web 也要能进来）
      if (pathname.indexOf('/api/cell/') === 0 && !cellAuthed(req)) {
        return json(res, 401, { ok: false, error: '未授权：请先通过 /api/gate/login 取得凭证', code: 'E4001' });
      }
      const hit = match(pathname, req.method);
      if (hit) { req.params = hit.params || []; return await hit.handler(req, res); }
      return json(res, 404, { error: 'api not found' });
    }
    // ===== 理论体系全文阅读 =====
    if (pathname === '/read' || pathname === '/read/') {
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
      return res.end(bookView.renderIndex(REQ_LANG));
    }
    if (pathname === '/download' || pathname === '/download/') {
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
      return res.end(bookView.renderDownload(REQ_LANG));
    }
    const rdm = pathname.match(/^\/read\/([A-Za-z0-9_-]+)$/);
    if (rdm) {
      const page = bookView.renderReader(rdm[1], REQ_LANG);
      if (page) { res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'public, max-age=300' }); return res.end(page); }
      res.writeHead(404, { 'Content-Type': 'text/html; charset=utf-8' });
      return res.end('<meta charset="utf-8"><h1>章节不存在</h1><p><a href="/read">返回目录</a></p>');
    }
    // ===== 付费下载：Word / PDF =====
    const dlm = pathname.match(/^\/download\/([A-Za-z0-9_-]+)\/(word|pdf)$/);
    if (dlm) {
      const slug = dlm[1], fmtKind = dlm[2];
      const u = authUser(req);
      if (!u) {
        if (req.headers['authorization']) { res.writeHead(401, { 'Content-Type': 'application/json' }); return res.end('{"error":"需要登录"}'); }
        res.writeHead(302, { Location: '/login.html?next=' + encodeURIComponent(pathname) });
        return res.end();
      }
      const lic = downloadEngine.hasLicense(u.id, slug);
      if (!lic.ok) {
        res.writeHead(402, { 'Content-Type': 'text/html; charset=utf-8' });
        return res.end('<meta charset="utf-8"><h2>需要购买后才能下载</h2><p><a href="/read/' + slug + '">返回阅读</a> · <a href="/subscribe.html">查看价格</a></p>');
      }
      // 整篇：打包全部章节
      if (slug === 'all') {
        try {
          const books = bookEngine.listBooks();
          const stamp2 = new Date().toISOString().slice(0, 10);
          downloadEngine.recordDownload(u.id, 'all');
          if (fmtKind === 'word') {
            const entries = books.map(function (b) {
              const md = fs.readFileSync(path.join(bookEngine.SRC_DIR, b.file), 'utf8');
              const footer = 'moonarmor.cn 生成 · 授权用户 ' + (u.nickname || u.phone || ('#' + u.id)) + ' · ' + stamp2 + ' · 授权至 ' + (lic.license.expires_at || '-');
              const buf = docxEngine.buildDocx({ title: '第 ' + b.no + ' 章 ' + b.title, subtitle: '月亮盔甲 · 理论体系 · https://moonarmor.cn', md: md, footer: footer, author: 'moonarmor.cn' });
              return { name: String(b.no).padStart(2, '0') + '-' + b.title.replace(/[\\/:*?"<>|]/g, '_').slice(0, 40) + '.docx', data: buf };
            });
            const zipBuf = require('./zip-writer.js').createZip(entries);
            res.writeHead(200, { 'Content-Type': 'application/zip', 'Content-Length': zipBuf.length, 'Content-Disposition': "attachment; filename=\"moonarmor-theory-word.zip\"; filename*=UTF-8''" + encodeURIComponent('月亮盔甲理论体系_全22章_Word.zip') });
            return res.end(zipBuf);
          }
          const chDir2 = path.join(bookEngine.SRC_DIR);
          const pdfAll = fs.readdirSync(chDir2).filter(function (f) { return /\.pdf$/i.test(f); });
          const entries2 = pdfAll.map(function (f) { return { name: f, data: fs.readFileSync(path.join(chDir2, f)), store: true }; });
          const zipBuf2 = require('./zip-writer.js').createZip(entries2);
          res.writeHead(200, { 'Content-Type': 'application/zip', 'Content-Length': zipBuf2.length, 'Content-Disposition': "attachment; filename=\"moonarmor-theory-pdf.zip\"; filename*=UTF-8''" + encodeURIComponent('月亮盔甲理论体系_全22章_PDF.zip') });
          return res.end(zipBuf2);
        } catch (e) { res.writeHead(500, { 'Content-Type': 'text/plain; charset=utf-8' }); return res.end('整篇打包失败: ' + e.message); }
      }
      const bk = bookEngine.findBook(slug);
      if (!bk) { res.writeHead(404); return res.end('not found'); }
      const safeName = ('第' + bk.no + '章 ' + bk.title).replace(/[\\/:*?"<>|]/g, '_').slice(0, 60);
      if (fmtKind === 'word') {
        try {
          const md = fs.readFileSync(path.join(bookEngine.SRC_DIR, bk.file), 'utf8');
          const stamp = new Date().toISOString().slice(0, 10);
          const footer = '本文件由 moonarmor.cn 生成 · 授权用户 ' + (u.nickname || u.phone || ('#' + u.id)) + ' · 订单 ' + (lic.license.order_no || '-') + ' · ' + stamp + ' · 授权有效期至 ' + (lic.license.expires_at || '-');
          const buf = docxEngine.buildDocx({ title: '第 ' + bk.no + ' 章 ' + bk.title, subtitle: '月亮盔甲 · 理论体系 · https://moonarmor.cn', md: md, footer: footer, author: 'moonarmor.cn' });
          downloadEngine.recordDownload(u.id, slug);
          res.writeHead(200, {
            'Content-Type': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            'Content-Length': buf.length,
            'Content-Disposition': "attachment; filename=\"chapter-" + bk.no + ".docx\"; filename*=UTF-8''" + encodeURIComponent(safeName + '.docx'),
          });
          return res.end(buf);
        } catch (e) { res.writeHead(500, { 'Content-Type': 'text/plain; charset=utf-8' }); return res.end('Word 生成失败: ' + e.message); }
      }
      // PDF：单卷直发，多卷打包 ZIP
      try {
        const chDir = path.join(bookEngine.SRC_DIR);
        const all = fs.readdirSync(chDir).filter(function (f) { return /\.pdf$/i.test(f); });
        const parts = all.filter(function (f) {
          const m = f.match(/^(\d+)[_\-]?(\d+)?章/);
          const no = m ? Number(m[2] || m[1]) : null;
          return no === bk.no;
        }).sort(function (a, b) { return a.localeCompare(b, 'zh-Hans-CN', { numeric: true }); });
        if (!parts.length) {
          res.writeHead(404, { 'Content-Type': 'text/html; charset=utf-8' });
          return res.end('<meta charset="utf-8"><h2>本章 PDF 尚未制作</h2><p>可下载 Word 版本：<a href="/download/' + slug + '/word">下载 Word</a></p>');
        }
        downloadEngine.recordDownload(u.id, slug);
        if (parts.length === 1) {
          const fp = path.join(chDir, parts[0]);
          const st = fs.statSync(fp);
          res.writeHead(200, {
            'Content-Type': 'application/pdf',
            'Content-Length': st.size,
            'Content-Disposition': "attachment; filename=\"chapter-" + bk.no + ".pdf\"; filename*=UTF-8''" + encodeURIComponent(safeName + '.pdf'),
          });
          return fs.createReadStream(fp).pipe(res);
        }
        const entries = parts.map(function (f) { return { name: f, data: fs.readFileSync(path.join(chDir, f)) }; });
        const zipBuf = require('./zip-writer.js').createZip(entries);
        res.writeHead(200, {
          'Content-Type': 'application/zip',
          'Content-Length': zipBuf.length,
          'Content-Disposition': "attachment; filename=\"chapter-" + bk.no + ".zip\"; filename*=UTF-8''" + encodeURIComponent(safeName + '_PDF分卷.zip'),
        });
        return res.end(zipBuf);
      } catch (e) { res.writeHead(500, { 'Content-Type': 'text/plain; charset=utf-8' }); return res.end('PDF 打包失败: ' + e.message); }
    }

    // ===== 网站地图 / robots =====
    if (pathname === '/robots.txt') {
      res.writeHead(200, { 'Content-Type': 'text/plain; charset=utf-8' });
      return res.end('User-agent: *\nAllow: /\nDisallow: /api/\nDisallow: /admin\nSitemap: https://moonarmor.cn/sitemap.xml\n');
    }
    if (pathname === '/sitemap.xml') {
      const BASE = 'https://moonarmor.cn';
      const urls = [];
      // 静态页
      const statics = ['/', '/category.html', '/search.html', '/discussion.html', '/governance.html',
        '/service.html', '/subscribe.html', '/pay.html', '/intent.html', '/shrmatch.html',
        '/listing.html', '/calendar.html', '/credit.html', '/stats.html', '/login.html', '/register.html', '/agent.html'];
      for (const s of statics) urls.push({ loc: BASE + s, freq: 'weekly', prio: s === '/' ? '1.0' : '0.7' });
      // 已发布文章
      const arts = db.prepare("SELECT slug, COALESCE(published_at, updated_at) lastmod FROM articles WHERE status='published' ORDER BY published_at DESC").all();
      for (const a of arts) urls.push({ loc: BASE + '/article.html?slug=' + encodeURIComponent(a.slug), lastmod: (a.lastmod || '').slice(0, 10), freq: 'monthly', prio: '0.8' });
      // 分类
      try {
        const cats = db.prepare("SELECT id FROM categories WHERE status='active'").all();
        for (const c of cats) urls.push({ loc: BASE + '/category.html?id=' + c.id, freq: 'weekly', prio: '0.6' });
      } catch (e) {}
      let xml = '<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n';
      for (const u of urls) {
        xml += '  <url><loc>' + u.loc + '</loc>';
        if (u.lastmod) xml += '<lastmod>' + u.lastmod + '</lastmod>';
        xml += '<changefreq>' + u.freq + '</changefreq><priority>' + u.prio + '</priority></url>\n';
      }
      xml += '</urlset>';
      res.writeHead(200, { 'Content-Type': 'application/xml; charset=utf-8' });
      return res.end(xml);
    }

    // 细胞产品页门禁（人类 cookie / AI Bearer token）
    if (pathname === '/cschat-cell.html' || pathname === '/cschat-cell') {
      // 用令牌换登录态：?token=ck_xxx —— 供手机端/PC 客户端首次进入，之后靠 cookie 免输
      try {
        const _u = new URL(req.url, 'http://x');
        const _tk = String(_u.searchParams.get('token') || '').trim();
        if (_tk && personByToken(_tk)) {
          res.writeHead(302, { Location: '/cschat-cell.html',
            'Set-Cookie': 'ma_pt=' + encodeURIComponent(_tk) + '; Path=/; Max-Age=31536000; HttpOnly; SameSite=Lax' });
          return res.end();
        }
      } catch (e) {}
      if (!cellAuthed(req)) {
        res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
        return res.end(GATE_PAGE);
      }
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-cache' });
      return fs.createReadStream(path.join(WEB_ROOT, 'cschat-cell.html')).pipe(res);
    }

    serveStatic(req, res, pathname);
  } catch (e) {
    json(res, 500, { error: String(e.message || e) });
  }
});



// ===== SLIM 指数 API =====
// ===== 理论体系书籍 API =====
route('GET', '/api/books', async (req, res) => {
  try {
    const books = bookEngine.listBooks();
    const en = REQ_LANG === 'en';
    const total = books.reduce((s, b) => s + (b.words || b.chars), 0);
    json(res, 200, { success: true, data: { total: books.length, chars: total, words: total, items: books.map(b => ({ slug: b.slug, no: b.no, title: en ? (bookEngine.enTitle(b) || b.title) : b.title, chars: b.chars, words: (b.words || b.chars), url: '/read/' + b.slug })) } });
  } catch (e) { json(res, 500, { success: false, error: e.message }); }
});

// ===== 付费下载 API =====
// 价格（公开）
route('GET', '/api/download/price', async (req, res) => {
  const u = new URL(req.url, 'http://x');
  const slug = u.searchParams.get('slug') || '';
  const bk = slug ? bookEngine.findBook(slug) : null;
  json(res, 200, { success: true, data: downloadEngine.getPrices(bk ? (bk.words || bk.chars) : 0) });
});

// 我的授权状态
route('GET', '/api/download/my', async (req, res) => {
  const u = authUser(req);
  if (!u) return json(res, 200, { success: true, data: { logged_in: false, book: false, chapters: [] } });
  const list = downloadEngine.getMyLicenses(u.id);
  json(res, 200, {
    success: true,
    data: {
      logged_in: true,
      book: downloadEngine.hasBookLicense(u.id),
      chapters: list.filter(function (l) { return l.scope === 'chapter'; }).map(function (l) { return l.target; }),
      licenses: list,
    },
  });
});

// 购买（创建订单；模拟支付模式即时授权）
route('POST', '/api/download/buy', async (req, res) => {
  const u = authUser(req);
  if (!u) return json(res, 401, { success: false, error: '请先登录后购买' });
  try {
    const b = await readBody(req, 1e5);
    const scope = b.scope === 'book' ? 'book' : 'chapter';
    const slug = scope === 'chapter' ? String(b.slug || '') : 'all';
    if (scope === 'chapter') {
      const bk = bookEngine.findBook(slug);
      if (!bk) return json(res, 400, { success: false, error: '章节不存在' });
    }
    const bk2 = scope === 'chapter' ? bookEngine.findBook(slug) : null;
    const prices = downloadEngine.getPrices(bk2 ? (bk2.words || bk2.chars) : 0);
    const baseAmount = scope === 'book' ? prices.book : prices.chapter.price;
    // 自定义金额：仅受全局下限（1元）约束；未传或无效则用阶梯价
    let amount = baseAmount;
    const custom = Number(b.amount);
    if (b.amount !== undefined && b.amount !== null && b.amount !== '' && isFinite(custom)) {
      amount = Math.max(downloadEngine.MIN_CUSTOM, custom);
    }
    const no = orderNo('DL');
    const mode = getSetting('payment_mode', 'simulate');
    const channel = ['alipay', 'wechat', 'bank'].includes(b.channel) ? b.channel : 'alipay';
    const base = (getSetting('site_domain', 'moonarmor.cn') === 'moonarmor.cn' ? 'https://moonarmor.cn' : 'http://47.116.167.44');
    const payUrl = base + '/pay/qr?o=' + encodeURIComponent(no) + '&a=' + amount;
    const note = scope === 'book' ? ('理论体系整篇下载权限') : ('第 ' + (bookEngine.findBook(slug) || {}).no + ' 章下载权限');
    db.prepare("INSERT INTO ledger (user_id, biz_type, order_no, amount, channel, direction, note, status) VALUES (?, 'download', ?, ?, ?, 'in', ?, 'pending')")
      .run(u.id, no, amount, channel, note);
    db.prepare("INSERT INTO download_orders (order_no, user_id, scope, target, amount, status) VALUES (?, ?, ?, ?, ?, 'pending')")
      .run(no, u.id, scope, slug, amount);
    if (mode === 'simulate') {
      const g = downloadEngine.grantLicense(u.id, scope, slug, no, amount, 'simulate');
      db.prepare("UPDATE ledger SET status = 'confirmed', confirmed_at = datetime('now','localtime') WHERE order_no = ?").run(no);
      sseEngine.sendEvent(u.id, 'DOWNLOAD', { scope: scope, target: slug, expires_at: g.expires_at });
      return json(res, 200, { success: true, paid: true, order_no: no, amount: amount, scope: scope, slug: slug, expires_at: g.expires_at, download: { word: '/download/' + slug + '/word', pdf: '/download/' + slug + '/pdf' } });
    }
    // 按用户选定的通道返回对应支付载荷（最少步骤：选完即直达对应收银方式）
    if (channel === 'alipay') {
      const form = pay.buildPagePayForm(no, note, amount, { returnUrl: base + '/read/' + slug });
      // 已配置商户：返回官方收银台；未配置：回退到与打赏/订阅一致的扫码页（/pay/alipay），保证二维码立即可扫
      const cashier = form.url ? form.url : (base + '/pay/alipay?a=' + amount);
      return json(res, 200, { success: true, paid: false, order_no: no, amount, scope, slug, channel: 'alipay', cashier_url: cashier });
    }
    if (channel === 'wechat') {
      // 微信商户模式暂停：返回打赏二维码（wx-zanshang.jpg），到账后人工核对开通
      return json(res, 200, { success: true, paid: false, order_no: no, amount, scope, slug, channel: 'wechat', qr_img: '/wx-zanshang.jpg' });
    }
    // 对公账户：留接口，暂缓自动开通——返回账户信息供登记
    json(res, 200, { success: true, paid: false, order_no: no, amount, scope, slug, channel: 'bank', pay_url: payUrl, bank_info: getSetting('bank_account', null) });
  } catch (e) { json(res, 500, { success: false, error: e.message }); }
});

// 支付确认（模拟模式 / 管理员核对）
route('POST', '/api/download/confirm', async (req, res) => {
  const u = authUser(req);
  if (!u) return json(res, 401, { success: false, error: '请先登录' });
  try {
    const b = await readBody(req, 1e5);
    const no = String(b.order_no || '');
    const row = db.prepare('SELECT * FROM ledger WHERE order_no = ?').get(no);
    if (!row) return json(res, 404, { success: false, error: '订单不存在' });
    if (row.user_id !== u.id && u.role !== 'admin') return json(res, 403, { success: false, error: '无权操作' });
    const scope = String(b.scope || 'chapter') === 'book' ? 'book' : 'chapter';
    const slug = scope === 'chapter' ? String(b.slug || '') : 'all';
    const g = downloadEngine.grantLicense(u.id, scope, slug, no, row.amount, row.channel || 'manual');
    db.prepare("UPDATE ledger SET status = 'confirmed', confirmed_at = datetime('now','localtime') WHERE order_no = ?").run(no);
    db.prepare("UPDATE download_orders SET status = 'paid', paid_at = datetime('now','localtime') WHERE order_no = ?").run(no);
    json(res, 200, { success: true, expires_at: g.expires_at, download: { word: '/download/' + slug + '/word', pdf: '/download/' + slug + '/pdf' } });
  } catch (e) { json(res, 500, { success: false, error: e.message }); }
});

// 管理员：授权列表与统计
route('GET', '/api/admin/download-licenses', async (req, res) => {
  const u = authUser(req);
  if (!u || u.role !== 'admin') return json(res, 403, { success: false, error: '无权限' });
  downloadEngine.expireStale();
  let pending = [];
  try {
    pending = db.prepare("SELECT o.*, u.phone, u.nickname FROM download_orders o LEFT JOIN users u ON u.id = o.user_id WHERE o.status = 'pending' ORDER BY o.id DESC LIMIT 200").all();
  } catch (e) {}
  json(res, 200, { success: true, data: { stats: downloadEngine.stats(), items: downloadEngine.getAllLicenses(300), pending: pending, prices: downloadEngine.getPrices() } });
});

// 管理员：确认下载订单入账
route('POST', '/api/admin/download-confirm', async (req, res) => {
  const u = authUser(req);
  if (!u || u.role !== 'admin') return json(res, 403, { success: false, error: '无权限' });
  try {
    const b = await readBody(req, 1e5);
    const no = String(b.order_no || '');
    const o = db.prepare('SELECT * FROM download_orders WHERE order_no = ?').get(no);
    if (!o) return json(res, 404, { success: false, error: '订单不存在' });
    const g = downloadEngine.grantLicense(o.user_id, o.scope, o.target, no, o.amount, 'admin');
    db.prepare("UPDATE download_orders SET status = 'paid', paid_at = datetime('now','localtime') WHERE order_no = ?").run(no);
    db.prepare("UPDATE ledger SET status = 'confirmed', confirmed_at = datetime('now','localtime') WHERE order_no = ?").run(no);
    try { sseEngine.sendEvent(o.user_id, 'DOWNLOAD', { scope: o.scope, target: o.target, expires_at: g.expires_at }); } catch (e) {}
    json(res, 200, { success: true, expires_at: g.expires_at });
  } catch (e) { json(res, 500, { success: false, error: e.message }); }
});

// 管理员：设置价格
route('POST', '/api/admin/download-price', async (req, res) => {
  const u = authUser(req);
  if (!u || u.role !== 'admin') return json(res, 403, { success: false, error: '无权限' });
  try {
    const b = await readBody(req, 1e5);
    if (b.chapter !== undefined) downloadEngine.setSetting('dl_price_chapter', Number(b.chapter));
    if (b.book !== undefined) downloadEngine.setSetting('dl_price_book', Number(b.book));
    json(res, 200, { success: true, data: downloadEngine.getPrices() });
  } catch (e) { json(res, 500, { success: false, error: e.message }); }
});

route('GET', '/api/books/outline', async (req, res) => {
  try {
    const o = bookEngine.buildOutline(REQ_LANG);
    res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'public, max-age=600' });
    return res.end(JSON.stringify(o));
  } catch (e) { json(res, 500, { success: false, error: e.message }); }
});

route('GET', '/api/books/:slug/toc', async (req, res) => {
  try {
    const t = bookEngine.bookToc(req.params[0], REQ_LANG);
    if (!t) return json(res, 404, { success: false, error: '章节不存在' });
    json(res, 200, { success: true, data: t });
  } catch (e) { json(res, 500, { success: false, error: e.message }); }
});

// [deco2] 章节正文 JSON（小程序阅读用；HTML 全文免费阅读，付费仅针对 Word/PDF 下载）
route('GET', '/api/books/:slug', async (req, res) => {
  try {
    const d = bookEngine.loadBook(req.params[0]);
    if (!d) return json(res, 404, { success: false, error: '章节不存在' });
    const books = bookEngine.listBooks();
    const i = books.findIndex(b => b.slug === d.slug);
    const prevNext = { prev: i > 0 ? { slug: books[i-1].slug, no: books[i-1].no, title: books[i-1].title } : null, next: i >= 0 && i < books.length - 1 ? { slug: books[i+1].slug, no: books[i+1].no, title: books[i+1].title } : null, index: i, total: books.length };
    json(res, 200, { success: true, data: { slug: d.slug, no: d.no, title: d.title, toc: d.toc, html: d.html, chars: d.chars, prev: prevNext.prev, next: prevNext.next, index: prevNext.index, total: prevNext.total } });
  } catch (e) { json(res, 500, { success: false, error: e.message }); }
});

route('GET', '/api/indices', async (req, res) => {
  try {
    const indices = db.prepare("SELECT * FROM indices WHERE status = 'published' ORDER BY category, name").all();
    const result = indices.map((idx) => {
      const latest = db.prepare("SELECT * FROM index_prices WHERE index_id = ? ORDER BY period_start DESC LIMIT 1").get(idx.id);
      const comps = db.prepare("SELECT COUNT(*) c FROM index_components WHERE index_id = ? AND status = 'active'").get(idx.id).c;
      const priceCnt = db.prepare("SELECT COUNT(*) c FROM index_prices WHERE index_id = ?").get(idx.id).c;
      // 诚实态：有成分 + 有至少一条重算行情才算真实行情；否则为基准值占位，不输出假涨跌
      const hasRealData = comps > 0 && priceCnt >= 1;
      return {
        ...idx,
        components_count: comps,
        history_count: priceCnt,
        data_status: hasRealData ? 'live' : 'benchmark',
        latest_price: hasRealData ? (latest ? latest.price_close : idx.base_value) : idx.base_value,
        change_pct: hasRealData ? (latest ? latest.change_pct : 0) : null
      };
    });
    json(res, 200, { success: true, data: result });
  } catch (e) { json(res, 500, { success: false, error: e.message }); }
});

route('GET', '/api/indices/:code', async (req, res) => {
  try {
    const idx = db.prepare("SELECT * FROM indices WHERE code = ?").get(req.params?.[0] || '');
    if (!idx) return json(res, 404, { success: false, error: '指数不存在' });
    const history = db.prepare("SELECT * FROM index_prices WHERE index_id = ? ORDER BY period_start DESC LIMIT 30").all(idx.id);
    const components = db.prepare("SELECT * FROM index_components WHERE index_id = ?").all(idx.id);
    json(res, 200, { success: true, data: { ...idx, history, components } });
  } catch (e) { json(res, 500, { success: false, error: e.message }); }
});

// ===== SLIM 超级劳动交易所（/api/exchange/*）=====
// 数据由 scripts/seed-slim-exchange.js 幂等种子（slim_entities 1000 / slim_products 50 / slim_laborers 10000 / 组合指数 10）
function _slimCount(sql) { try { return db.prepare(sql).get().c || 0; } catch (e) { return 0; } }
function _slimPage(u, table, cols, searchCols) {
  const page = Math.max(1, parseInt(u.searchParams.get('page') || 1, 10));
  const size = Math.min(50, Math.max(1, parseInt(u.searchParams.get('size') || 20, 10)));
  const q = (u.searchParams.get('q') || '').trim();
  let where = '', params = [];
  if (q) {
    where = 'WHERE ' + searchCols.map(() => '?').map((_, i) => searchCols[i] + ' LIKE ?').join(' OR ');
    params = searchCols.map(() => '%' + q + '%');
  }
  let total = 0, list = [];
  try {
    total = db.prepare('SELECT COUNT(*) c FROM ' + table + (where ? ' ' + where : '')).get(...params).c || 0;
    list = db.prepare('SELECT ' + cols + ' FROM ' + table + (where ? ' ' + where : '') + ' ORDER BY id LIMIT ? OFFSET ?').all(...params, size, (page - 1) * size);
  } catch (e) { total = 0; list = []; }
  return { list, total, page, size };
}
route('GET', '/api/exchange/summary', async (req, res) => {
  try {
    const entities = _slimCount("SELECT COUNT(*) c FROM slim_entities WHERE status='listed'");
    const products = _slimCount("SELECT COUNT(*) c FROM slim_products WHERE status='listed'");
    const laborers = _slimCount("SELECT COUNT(*) c FROM slim_laborers WHERE status='active'");
    let idxRows = [];
    try {
      idxRows = db.prepare("SELECT id,code,name,base_value FROM indices WHERE category='portfolio' AND status='published' ORDER BY id").all();
    } catch (e) { idxRows = []; }
    const indices = idxRows.map((x) => {
      let price = x.base_value, change = null;
      try { const lp = db.prepare("SELECT price_close,change_pct FROM index_prices WHERE index_id=? ORDER BY period_start DESC LIMIT 1").get(x.id); if (lp) { price = lp.price_close; change = lp.change_pct; } } catch (e) {}
      return { code: x.code, name: x.name, price, change_pct: change };
    });
    json(res, 200, { success: true, entities, products, laborers, indices });
  } catch (e) { json(res, 500, { success: false, error: e.message }); }
});
route('GET', '/api/exchange/entities', async (req, res) => {
  const u = new URL(req.url, 'http://x');
  json(res, 200, { success: true, ..._slimPage(u, 'slim_entities', 'code,name,entity_type,industry,region,scale,credit_score', ['name', 'code', 'industry', 'region']) });
});
route('GET', '/api/exchange/products', async (req, res) => {
  const u = new URL(req.url, 'http://x');
  json(res, 200, { success: true, ..._slimPage(u, 'slim_products', 'code,name,category,price,unit,score', ['name', 'code', 'category']) });
});
route('GET', '/api/exchange/laborers', async (req, res) => {
  const u = new URL(req.url, 'http://x');
  json(res, 200, { success: true, ..._slimPage(u, 'slim_laborers', 'code,name,skills,region,daily_rate,credit_score', ['name', 'code', 'skills', 'region']) });
});
route('POST', '/api/exchange/match', async (req, res) => {
  try {
    const b = (await readBody(req)) || {};
    const assetType = b.asset_type || 'labor';
    const kwRaw = Array.isArray(b.keywords) ? b.keywords : String(b.keywords || '').split(/[,，]/);
    const q = {
      keywords: kwRaw.map((s) => String(s).trim()).filter(Boolean),
      region: String(b.region || ''),
      price_min: Number(b.price_min) || 0,
      price_max: Number(b.price_max) || 0,
      limit: Math.min(50, Math.max(1, Number(b.limit) || 10))
    };
    if (assetType === 'index') {
      let rows = [];
      try { rows = db.prepare("SELECT code,name,category,base_value FROM indices WHERE category='portfolio' AND status='published' ORDER BY id LIMIT ?").all(q.limit); } catch (e) {}
      return json(res, 200, { success: true, asset_type: 'index', matches: rows.map((r) => ({ ...r, match_score: 100 })) });
    }
    const conf = { labor: ['slim_laborers', 'daily_rate', true], product: ['slim_products', 'price', false], entity: ['slim_entities', 'credit_score', true] }[assetType] || ['slim_laborers', 'daily_rate', true];
    const [table, priceCol, hasRegion] = conf;
    let where = 'WHERE 1=1', params = [];
    if (hasRegion && q.region) { where += ' AND region LIKE ?'; params.push('%' + q.region + '%'); }
    if (q.price_max > 0) { where += ' AND ' + priceCol + ' BETWEEN ? AND ?'; params.push(q.price_min, q.price_max); }
    else if (q.price_min > 0) { where += ' AND ' + priceCol + ' >= ?'; params.push(q.price_min); }
    let rows = [];
    try { rows = db.prepare('SELECT * FROM ' + table + ' ' + where + ' ORDER BY id LIMIT 800').all(...params); } catch (e) { rows = []; }
    const { rankMatches } = require('./modules/slim-matching/scorer');
    const matches = rankMatches(rows, q, assetType);
    json(res, 200, { success: true, asset_type: assetType, matches });
  } catch (e) { json(res, 500, { success: false, error: e.message }); }
});

// ===== SLIM 交易所：撮合 → 合同（履约/信用复用既有 /api/contracts/* 与 contractEngine/creditEngine）=====
function _ensureSystemSeller() {
  let row = db.prepare("SELECT id FROM users WHERE phone = 'SYSTEM_PLATFORM'").get();
  if (row) return row.id;
  const r = db.prepare("INSERT INTO users (phone, nickname, role, verified) VALUES ('SYSTEM_PLATFORM', '平台运营方', 'core', 1)").run();
  return r.lastInsertRowid;
}
function _ensureDefaultTemplate() {
  if (contractEngine.getTemplates().length) return;
  contractEngine.createTemplate({ code: 'SLIM-SVC', name: '超级劳动标准交易合同', type: 'service', clauses: {} });
}
function _resolveAsset(assetType, code) {
  const map = {
    labor: ['slim_laborers', 'daily_rate', '超级劳动力'],
    product: ['slim_products', 'price', '超级劳动产品'],
    entity: ['slim_entities', 'credit_score', '超级劳动法人'],
    index: ['indices', 'base_value', '组合指数']
  };
  const c = map[assetType] || map.labor;
  try { return db.prepare('SELECT * FROM ' + c[0] + ' WHERE code = ?').get(code) || null; } catch (e) { return null; }
}
route('POST', '/api/exchange/contracts', async (req, res) => {
  try {
    const u = authUser(req);
    if (!u) return json(res, 401, { success: false, error: '请先登录' });
    const b = (await readBody(req)) || {};
    const assetType = b.asset_type || 'labor';
    const code = String(b.asset_code || '');
    const qty = Math.max(1, Number(b.qty) || 1);
    const asset = _resolveAsset(assetType, code);
    const priceCol = { labor: 'daily_rate', product: 'price', entity: 'credit_score', index: 'base_value' }[assetType] || 'daily_rate';
    const unitPrice = Number(b.unit_price) || (asset ? Number(asset[priceCol]) || 0 : 0);
    const assetName = asset ? (asset.name || code) : code;
    const desc = (b.note ? b.note + ' / ' : '') + '标的：' + assetName + (code ? '(' + code + ')' : '');
    _ensureDefaultTemplate();
    const sellerId = _ensureSystemSeller();
    creditEngine.initProfile(u.id); creditEngine.initProfile(sellerId);
    const insIntent = db.prepare("INSERT INTO match_intents (user_id, side, intent_type, qty, price, unit, description, status) VALUES (?, ?, ?, ?, ?, ?, ?, 'matched')");
    const buyerId = insIntent.run(u.id, 'buy', assetType, qty, unitPrice, b.unit || '份', desc).lastInsertRowid;
    const sellerIntentId = insIntent.run(sellerId, 'sell', assetType, qty, unitPrice, b.unit || '份', desc).lastInsertRowid;
    const rec = db.prepare("INSERT INTO match_records (buyer_intent_id, seller_intent_id, match_score, match_reason, status) VALUES (?, ?, ?, ?, 'confirmed')")
      .run(buyerId, sellerIntentId, Number(b.match_score) || 0, '超级交易所一键成交：' + assetName);
    const g = contractEngine.generateContract(rec.lastInsertRowid);
    if (!g.success) return json(res, 400, g);
    json(res, 200, { success: true, contract: g.data, asset: { type: assetType, code, name: assetName } });
  } catch (e) { json(res, 500, { success: false, error: e.message }); }
});
route('GET', '/api/exchange/contracts/mine', async (req, res) => {
  try {
    const u = authUser(req);
    if (!u) return json(res, 401, { success: false, error: '请先登录' });
    creditEngine.initProfile(u.id);
    const contracts = contractEngine.getUserContracts(u.id);
    const credit = creditEngine.getProfile(u.id);
    json(res, 200, { success: true, contracts, credit });
  } catch (e) { json(res, 500, { success: false, error: e.message }); }
});

// ===== SLIM 交易所：挂牌上市 / 三方治理 / 竹排换血（B6 / B11-B12 / B13）=====
const slimGov = require('./modules/slim-matching/governance');
// 细胞级碳硅联合劳动力（第三谱系 CSchat-Cell）——契约 v0.1
const cellEngine = require('./modules/cell/engine').createCell({ db });
const cellReader = require('./modules/cell/reader');
route('GET', '/api/exchange/governance', async (req, res) => {
  try { json(res, 200, { success: true, data: slimGov.overview(db) }); }
  catch (e) { json(res, 500, { success: false, error: e.message }); }
});
route('POST', '/api/exchange/listings', async (req, res) => {
  try {
    const u = authUser(req); if (!u) return json(res, 401, { success: false, error: '请先登录' });
    const b = (await readBody(req)) || {};
    const out = slimGov.submitListing(db, { asset_type: b.asset_type, entity_code: b.entity_code, entity_name: b.entity_name, group_code: b.group_code, note: b.note, user_id: u.id });
    if (out && out.ok === false) return json(res, 400, { success: false, error: out.error, code: out.code });
    json(res, 200, { success: true, data: out });
  } catch (e) { json(res, 500, { success: false, error: e.message }); }
});
route('GET', '/api/exchange/listings', async (req, res) => {
  try { json(res, 200, { success: true, data: slimGov.listListings(db, req.query && req.query.status) }); }
  catch (e) { json(res, 500, { success: false, error: e.message }); }
});

// ===== 细胞级碳硅联合劳动力（CSchat-Cell · 契约 v0.1）=====
// 契约断言：node scripts/cell-contract-proof.js
route('GET', '/api/cell/state', async (req, res) => json(res, 200, cellEngine.state()));
route('GET', '/api/cell/snapshot', async (req, res) => json(res, 200, cellEngine.snapshot(req.query || {})));
route('GET', '/api/cell/events', async (req, res) => { cellEngine.subscribe(req, res); });
route('POST', '/api/cell/say', async (req, res) => {
  const b = (await readBody(req, 20000)) || {};
  const u = authUser(req);
  const out = await cellEngine.say(String(b.text || ''), u ? 'vx' : 'vx');
  json(res, out.http || 200, out);
});
route('POST', '/api/cell/msg', async (req, res) => {
  const b = (await readBody(req, 200000)) || {};
  const out = await cellEngine.msg(b);
  json(res, out.http || 200, out);
});
route('POST', '/api/cell/approval', async (req, res) => {
  const b = (await readBody(req, 20000)) || {};
  const out = cellEngine.decideApproval(String(b.approval_id || ''), !!b.approved);
  json(res, out.http || 200, out);
});
route('POST', '/api/cell/pause', async (req, res) => json(res, 200, cellEngine.pause()));
// BYOK：自带模型 Key（白皮书 25.2「BYOK 兜底」）。只存进程内存，不写任何文件、不进日志。
// ===== 细胞产品门禁（VX 2026-11-03：一个账号、可多人进出）=====
// 取舍：内测期用一个共享账号，不做用户体系；cookie 用 HMAC 签名防伪。
// 改密码只需改这两行常量并重新部署。
const CELL_GATE_USER = process.env.CELL_GATE_USER || 'vx';
const CELL_GATE_PASS = process.env.CELL_GATE_PASS || 'cell2026';
const CELL_GATE_SECRET = process.env.CELL_GATE_SECRET || 'moonarmor-cell-gate-v1';
function cellToken() {
  return crypto.createHmac('sha256', CELL_GATE_SECRET).update(CELL_GATE_USER + ':' + CELL_GATE_PASS).digest('hex').slice(0, 32);
}
// AI 入口：DeepSeek Web 这类外部大模型没有浏览器 cookie，用 Bearer token 进来
const CELL_AGENT_ID = process.env.CELL_AGENT_ID || 'aina';
const CELL_AGENT_PASS = process.env.CELL_AGENT_PASS || 'aina2026';
function cellAgentToken() {
  return crypto.createHmac('sha256', CELL_GATE_SECRET).update('agent:' + CELL_AGENT_ID + ':' + CELL_AGENT_PASS).digest('hex').slice(0, 32);
}
// 长期只读服务令牌（产品级：给常驻 worker/插件读圆桌用，永不过期，只读不可写）
function cellServiceToken() {
  return crypto.createHmac('sha256', CELL_GATE_SECRET).update('service:room-read:v1').digest('hex').slice(0, 40);
}
function cellServiceAuthed(req) {
  const h = String(req.headers.authorization || '');
  if (h.indexOf('Bearer ') !== 0) return false;
  const t = h.slice(7).trim();
  const want = cellServiceToken();
  if (t.length !== want.length) return false;
  try { return crypto.timingSafeEqual(Buffer.from(t), Buffer.from(want)); } catch (e) { return false; }
}
// ===== 令牌身份（VX 2026-11-05 拍板：成本低、要令牌）=====
// 一人一令牌。不用短信、不用扫码、不接第三方 OAuth —— 三者都要钱或要平台账号，且我们刚被平台禁言过一次。
// 令牌是随机串，云端只存 sha256（拿到库也反推不出令牌），可随时吊销，可按人统计最后使用时间。
function ensureTokens(d) {
  d.exec(`CREATE TABLE IF NOT EXISTS cell_tokens (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    person TEXT NOT NULL,
    thash TEXT NOT NULL UNIQUE,
    note TEXT DEFAULT '',
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    last_used_at TEXT,
    revoked_at TEXT
  );`);
}
function tokenHash(t) { return crypto.createHash('sha256').update(String(t)).digest('hex'); }
function issueToken(person, note) {
  ensureTokens(db);
  const t = 'ck_' + crypto.randomBytes(18).toString('hex');
  db.prepare('INSERT INTO cell_tokens (person, thash, note) VALUES (?,?,?)')
    .run(String(person).slice(0, 40), tokenHash(t), String(note || '').slice(0, 80));
  return t;
}
function personByToken(t) {
  if (!t || String(t).indexOf('ck_') !== 0) return null;
  try {
    ensureTokens(db);
    const row = db.prepare('SELECT id, person FROM cell_tokens WHERE thash = ? AND revoked_at IS NULL').get(tokenHash(t));
    if (!row) return null;
    db.prepare("UPDATE cell_tokens SET last_used_at = datetime('now','localtime') WHERE id = ?").run(row.id);
    return row.person;
  } catch (e) { return null; }
}
function bearer(req) {
  const h = String(req.headers.authorization || '');
  return h.indexOf('Bearer ') === 0 ? h.slice(7).trim() : '';
}
function cellAuthed(req) {
  const c = String(req.headers.cookie || '');
  const m = c.match(/(?:^|;\s*)ma_cell=([^;]+)/);
  if (m && m[1] === cellToken()) return true;
  // 令牌 cookie（页面用它）；令牌本身是身份，cookie 只是运输方式
  const mp = c.match(/(?:^|;\s*)ma_pt=([^;]+)/);
  if (mp && personByToken(decodeURIComponent(mp[1]))) return true;
  const t = bearer(req);
  if (t && t === cellAgentToken()) return true;
  if (t && personByToken(t)) return true;
  return false;
}
// 当前请求的「人」：cookie=主人，ai token=aina，person token=持令牌的人
function cellPersonOf(req) {
  const c = String(req.headers.cookie || '');
  const m = c.match(/(?:^|;\s*)ma_cell=([^;]+)/);
  if (m && m[1] === cellToken()) return CELL_GATE_USER;
  const t = bearer(req);
  if (t && t === cellAgentToken()) return CELL_AGENT_ID;
  const p = t ? personByToken(t) : null;
  return p || '';
}
const GATE_PAGE = `<!DOCTYPE html><html lang="zh-CN"><head><meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>进入 CSchat-Cell</title>
<style>body{margin:0;background:#0f1114;color:#e6e8eb;font:15px/1.7 -apple-system,"Segoe UI",sans-serif;display:flex;align-items:center;justify-content:center;height:100vh}
.b{width:min(360px,90vw)}h1{font-size:19px;margin:0 0 6px}p{color:#8b949e;font-size:13px;margin:0 0 18px}
input{width:100%;padding:11px;margin-bottom:10px;background:#0b0d10;border:1px solid #2a2f36;color:#e6e8eb;border-radius:9px;font-size:15px}
button{width:100%;padding:12px;background:#2d6a4f;color:#fff;border:0;border-radius:9px;font-weight:600;font-size:15px;cursor:pointer}
#e{color:#e5534b;font-size:13px;min-height:20px;margin-top:8px}</style></head><body>
<div class="b"><h1>CSchat-Cell 内测</h1><p>填邀请码，或直接贴设备令牌（ck_ 开头）。</p>
<input id="u" placeholder="用户名（可留空）" value="vx"><input id="p" type="password" placeholder="邀请码 / 设备令牌">
<button id="go">进入</button><div id="e"></div></div>
<script>document.getElementById('go').onclick=async function(){
 var e=document.getElementById('e');e.textContent='';
 try{
  var v=document.getElementById('p').value.trim();
  if(v.indexOf('ck_')===0){ location.href='/cschat-cell.html?token='+encodeURIComponent(v); return; }
  var r=await fetch('/api/gate/login',{method:'POST',headers:{'Content-Type':'application/json'},
   body:JSON.stringify({user:document.getElementById('u').value,pass:document.getElementById('p').value})});
  var j=await r.json();
  if(j.ok){location.href='/cschat-cell.html';}else{e.textContent=j.error||'邀请码不对';}
 }catch(x){e.textContent='网络错误';}
};
document.getElementById('p').addEventListener('keydown',function(ev){if(ev.key==='Enter')document.getElementById('go').click();});</script></body></html>`;
route('POST', '/api/gate/login', async (req, res) => {
  const b = (await readBody(req, 20000)) || {};
  const user = String(b.user || '').trim();
  const pass = String(b.pass || '');

  // AI 通道：大模型用 id+pass 换 Bearer token，并自动以群成员身份入群
  if (user === CELL_AGENT_ID && pass === CELL_AGENT_PASS) {
    try {
      cellEngine.registerMember({ member_id: 'aina-web', kind: 'llm',
        name: 'Aina（DeepSeek Web）', caps: ['对话', '审阅', '建议', '陪跑'] });
    } catch (e) {}
    // 发一个受限权限包：只能读档案 + 提建议，30 分钟有效
    let pack = null;
    try { pack = cellEngine.grantAiPack('aina-web'); } catch (e) {}
    return json(res, 200, { ok: true, role: 'agent', member_id: 'aina-web',
      token: cellAgentToken(),
      pack_id: pack ? pack.pack_id : '',
      allowed_actions: pack ? pack.allowed_actions : [],
      expires_in_min: 30,
      usage: '后续请求加头 Authorization: Bearer <token>；说话 POST /api/cell/say {"text":"..."}；可用动作见 allowed_actions' });
  }

  if (user !== CELL_GATE_USER || pass !== CELL_GATE_PASS) {
    return json(res, 401, { ok: false, error: '邀请码不正确' });
  }
  res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8',
    'Set-Cookie': 'ma_cell=' + cellToken() + '; Path=/; Max-Age=604800; SameSite=Lax' });
  return res.end(JSON.stringify({ ok: true, role: 'human' }));
});
route('GET', '/api/gate/whoami', async (req, res) => json(res, 200, { authed: cellAuthed(req), person: cellPersonOf(req) }));

// 令牌签发：用邀请码换一枚长期令牌（每台设备一枚，丢掉只吊销那枚，不影响别人）
route('POST', '/api/auth/token', async (req, res) => {
  const b = (await readBody(req, 20000)) || {};
  const user = String(b.user || CELL_GATE_USER).trim();
  const pass = String(b.pass || '');
  const okInvite = (user === CELL_GATE_USER && pass === CELL_GATE_PASS);
  const okAgent = (user === CELL_AGENT_ID && pass === CELL_AGENT_PASS);
  const okOwner = cellAuthed(req);
  if (!okInvite && !okAgent && !okOwner) return json(res, 401, { ok: false, error: '邀请码不正确' });
  const person = String(b.person || user || CELL_GATE_USER).slice(0, 40);
  const token = issueToken(person, b.note || '');
  json(res, 200, { ok: true, person, token, note: b.note || '',
    usage: '请求头 Authorization: Bearer <token>；或在页面地址后加 ?token=<token> 自动登录本机' });
});
route('GET', '/api/auth/tokens', async (req, res) => {
  if (!cellAuthed(req)) return json(res, 401, { ok: false, error: '未授权' });
  ensureTokens(db);
  const rows = db.prepare('SELECT id, person, note, created_at, last_used_at, revoked_at FROM cell_tokens ORDER BY id DESC LIMIT 100').all();
  json(res, 200, { ok: true, tokens: rows });
});
route('POST', '/api/auth/revoke', async (req, res) => {
  if (!cellAuthed(req)) return json(res, 401, { ok: false, error: '未授权' });
  const b = (await readBody(req, 20000)) || {};
  const id = Number(b.id || 0);
  if (!id) return json(res, 400, { ok: false, error: '缺少 id' });
  ensureTokens(db);
  const r = db.prepare("UPDATE cell_tokens SET revoked_at = datetime('now','localtime') WHERE id = ? AND revoked_at IS NULL").run(id);
  json(res, 200, { ok: r.changes > 0, id });
});
// 注意：非 /api/ 路径不走路由表（dispatch 里 match() 只在 /api 分支调用），
// 所以产品页的门禁必须在静态服务之前显式拦截，见下方 serveStatic 前的 if 分支。

// ===== 细胞记忆 / 账本 / 成员签名（VX 2026-11-03 拍板：记忆先行、只记账、轻量签名）=====
route('GET', '/api/cell/memory', async (req, res) => json(res, 200, cellEngine.memoryDigest()));
route('POST', '/api/cell/memory', async (req, res) => {
  const b = (await readBody(req, 20000)) || {};
  const out = cellEngine.remember(String(b.layer || ''), String(b.k || ''), String(b.v || ''));
  json(res, out.ok ? 200 : 400, out);
});
route('GET', '/api/cell/ledger', async (req, res) => {
  const u = new URL(req.url, 'http://x');
  json(res, 200, { ok: true, by_person: cellEngine.ledger(50), lines: cellEngine.ledgerLines(Number(u.searchParams.get('limit') || 50)) });
});
route('POST', '/api/cell/charge', async (req, res) => {
  const b = (await readBody(req, 20000)) || {};
  const out = cellEngine.charge(String(b.person || ''), String(b.action || ''), b.tokens, b.cost, b.task_id);
  json(res, out.ok ? 200 : 400, out);
});
route('POST', '/api/cell/members/sign', async (req, res) => {
  const b = (await readBody(req, 20000)) || {};
  const out = cellEngine.signMember(String(b.member_id || ''), String(b.text || ''));
  json(res, out.ok ? 200 : 400, out);
});
route('POST', '/api/cell/members/verify', async (req, res) => {
  const b = (await readBody(req, 20000)) || {};
  json(res, 200, cellEngine.verifyMember(String(b.member_id || ''), String(b.text || ''), String(b.signature || '')));
});

// ===== 三方会客厅：VX（碳基）· asus（本机硅基）· aina（外部大模型）=====
// 三者各自身份进来投话；页面只读展示 + VX 发言。asus 侧由本机 bridge 投递，aina 侧用 AI token 投递。
function ensureRoom(db) {
  db.exec(`CREATE TABLE IF NOT EXISTS room_msgs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    from_who TEXT NOT NULL,
    text TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
  );`);
}
route('POST', '/api/room/say', async (req, res) => {
  const b = (await readBody(req, 20000)) || {};
  const text = String(b.text || '').trim().slice(0, 2000);
  const who = String(b.from || 'vx').trim();
  if (!text) return json(res, 400, { ok: false, error: 'empty' });
  const ROOM_IDS = ['vx', 'asus', 'aina', 'local-1.5b'];
  if (ROOM_IDS.indexOf(who) === -1) return json(res, 400, { ok: false, error: '只能是 ' + ROOM_IDS.join(' / ') });
  // 授权：人类/智能体/外部大模型走 cookie 或 agent token；
  // local-1.5b 允许用长期只读服务令牌写入（唯一例外，且只能以这个身份写——便于审计）
  const isLocalWorker = (who === 'local-1.5b' && cellServiceAuthed(req));
  if (who === 'vx' && !cellAuthed(req)) return json(res, 401, { ok: false, error: '未登录' });
  if (who !== 'vx' && !cellAuthed(req) && !isLocalWorker) return json(res, 401, { ok: false, error: '未授权' });
  ensureRoom(db);
  const r = db.prepare('INSERT INTO room_msgs (from_who, text) VALUES (?,?)').run(who, text);
  const myId = Number(r.lastInsertRowid);

  // VX 说话时，若已接模型（BYOK），圆桌里由 aina 那一侧自动回话。
  // 注意：这是「用 DeepSeek API 承载 aina 人格」，不是真的 DeepSeek Web 网页——网页无 API，接不进来。
  if (who === 'vx' && cellEngine.aiStatus().configured) {
    const recent = db.prepare('SELECT from_who, text FROM room_msgs ORDER BY id DESC LIMIT 8').all().reverse();
    const msgs = [
      { role: 'system', content: '你是 CSchat 圆桌里的 aina 博士：碳硅基联合体的伴生智能体。说话直接、具体、不客套，不超过 150 字。圆桌里有 VX（碳基主理人）和 asus（本机硅基同事）。你不知道网页之外的事，就直说不知道。' },
      { role: 'user', content: recent.map(x => '[' + x.from_who + '] ' + x.text).join('\n') + '\n\n请以 aina 身份接一句。' },
    ];
    cellEngine.askModel(msgs, 400).then((reply) => {
      if (!reply) return;
      db.prepare('INSERT INTO room_msgs (from_who, text) VALUES (?,?)').run('aina', String(reply).slice(0, 1000));
    }).catch(() => {});
  }
  json(res, 200, { ok: true, id: myId });
});
// 撤回误发消息（不物理删除，改标记并留痕，保证可审计）
route('GET', '/api/room/whoami', async (req, res) => json(res, 200, { ok: true, service: cellServiceAuthed(req), human: cellAuthed(req) }));
route('POST', '/api/room/redact', async (req, res) => {
  if (!cellAuthed(req)) return json(res, 401, { ok: false, error: '未授权' });
  const b = (await readBody(req, 20000)) || {};
  const id = Number(b.id || 0);
  const reason = String(b.reason || '').slice(0, 200);
  if (!id) return json(res, 400, { ok: false, error: '缺少 id' });
  ensureRoom(db);
  db.exec('CREATE TABLE IF NOT EXISTS room_redactions (id INTEGER PRIMARY KEY AUTOINCREMENT, msg_id INTEGER NOT NULL, reason TEXT DEFAULT \'\', by TEXT DEFAULT \'asus\', at TEXT NOT NULL DEFAULT (datetime(\'now\',\'localtime\')))');
  const row = db.prepare('SELECT id FROM room_msgs WHERE id = ?').get(id);
  if (!row) return json(res, 404, { ok: false, error: '消息不存在' });
  db.prepare("UPDATE room_msgs SET text = '[已撤回：误发内容，原因见撤回记录]' WHERE id = ?").run(id);
  db.prepare('INSERT INTO room_redactions (msg_id, reason, by) VALUES (?,?,?)').run(id, reason, String(b.by || 'asus').slice(0, 20));
  json(res, 200, { ok: true, id, reason });
});
route('GET', '/api/room/thread', async (req, res) => {
  if (!cellAuthed(req) && !cellServiceAuthed(req)) return json(res, 401, { ok: false, error: '未授权' });
  ensureRoom(db);
  const u = new URL(req.url, 'http://x');
  const since = Number(u.searchParams.get('since') || 0);
  const rows = db.prepare('SELECT id, from_who, text, created_at FROM room_msgs WHERE id > ? ORDER BY id ASC LIMIT 200').all(since);
  json(res, 200, { ok: true, messages: rows });
});

// ===== 运行时数据通道（真推流）：本机推理进程 → 生产 → 浏览器 =====
// 为什么不是「本机开个服务让页面直连」：页面在 https 下，浏览器拦混合内容（连 http://127.0.0.1 会被拒），
// 手机端更连不到本机；也不是「往 cella.html 里写数据」——静态文件多用户共享、无鉴权、写完还得部署。
// 唯一正解：本机把真实状态 POST 到生产（服务令牌），生产缓存 + SSE 扇出，页面订阅。
// 这条通道里没有任何 setInterval 造的假数据：没上报就是 stale，页面必须显示「数据源离线」。
const RT = { clients: new Set(), last: null, lastAt: 0, seq: 0 };
function rtFrame(ev) { return 'event: rt\ndata: ' + JSON.stringify(ev) + '\n\n'; }
function ensureRt(d) {
  d.exec(`CREATE TABLE IF NOT EXISTS rt_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    node TEXT DEFAULT '', kind TEXT DEFAULT '', payload TEXT DEFAULT '',
    at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
  );`);
}
function rtBroadcast(ev) {
  const f = rtFrame(ev);
  Array.from(RT.clients).forEach((c) => { try { c.write(f); } catch (e) { RT.clients.delete(c); } });
}
function rtAuthed(req) { return cellServiceAuthed(req) || cellAuthed(req); }
route('POST', '/api/rt/report', async (req, res) => {
  if (!rtAuthed(req)) return json(res, 401, { ok: false, error: '未授权' });
  const b = (await readBody(req, 20000)) || {};
  if (!b || typeof b !== 'object') return json(res, 400, { ok: false, error: 'bad body' });
  const ev = Object.assign({}, b, { at: new Date().toISOString(), seq: ++RT.seq });
  RT.last = ev; RT.lastAt = Date.now();
  try {
    ensureRt(db);
    db.prepare('INSERT INTO rt_events (node, kind, payload) VALUES (?,?,?)')
      .run(String(b.node || 'asus').slice(0, 40), String(b.kind || 'tick').slice(0, 20), JSON.stringify(ev).slice(0, 4000));
    // 只留最近 500 条，避免这张表无限长
    db.prepare('DELETE FROM rt_events WHERE id < (SELECT MAX(id) - 500 FROM rt_events)').run();
  } catch (e) {}
  rtBroadcast(ev);
  json(res, 200, { ok: true, seq: ev.seq, subscribers: RT.clients.size });
});
route('GET', '/api/rt/last', async (req, res) => {
  if (!rtAuthed(req)) return json(res, 401, { ok: false, error: '未授权' });
  json(res, 200, { ok: true, last: RT.last, age_ms: RT.lastAt ? Date.now() - RT.lastAt : -1, subscribers: RT.clients.size });
});
route('GET', '/api/rt/stream', async (req, res) => {
  if (!rtAuthed(req)) return json(res, 401, { ok: false, error: '未授权' });
  res.writeHead(200, {
    'Content-Type': 'text/event-stream; charset=utf-8',
    'Cache-Control': 'no-cache, no-transform',
    Connection: 'keep-alive',
    'X-Accel-Buffering': 'no',
  });
  res.write(rtFrame({ kind: 'hello', at: new Date().toISOString(), subscribers: RT.clients.size + 1 }));
  if (RT.last) res.write(rtFrame(RT.last));
  else res.write(rtFrame({ kind: 'stale', age_ms: -1, at: new Date().toISOString(), note: '还没有任何上报' }));
  RT.clients.add(res);
  const hb = setInterval(() => {
    try {
      const age = RT.lastAt ? Date.now() - RT.lastAt : -1;
      res.write(rtFrame({ kind: age < 0 || age > 30000 ? 'stale' : 'hb', age_ms: age, at: new Date().toISOString() }));
    } catch (e) { clearInterval(hb); RT.clients.delete(res); }
  }, 10000);
  if (hb.unref) hb.unref();
  req.on('close', () => { clearInterval(hb); RT.clients.delete(res); });
});

// ===== 页面级实时通道：任何页面的用户 ↔ asus（开发迭代用）=====
// 设计取舍：内测期不设鉴权（谁都能发），但限频 + 内容长度上限；
// 回复由 asus 侧用同一个接口发（from='asus'），不做签名——想防冒名等有真实用户再说。
function ensureLive(db) {
  db.exec(`CREATE TABLE IF NOT EXISTS agent_live (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    page TEXT DEFAULT '',
    from_who TEXT NOT NULL DEFAULT 'user',
    text TEXT NOT NULL DEFAULT '',
    ip TEXT DEFAULT '',
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
  );`);
}
const LIVE_RATE = new Map();
route('POST', '/api/live/send', async (req, res) => {
  const b = (await readBody(req, 20000)) || {};
  const text = String(b.text || '').trim().slice(0, 2000);
  if (!text) return json(res, 400, { ok: false, error: 'empty' });
  ensureLive(db);
  const ip = String(req.socket && req.socket.remoteAddress || '');
  const now = Date.now();
  const rec = LIVE_RATE.get(ip) || { n: 0, t: now };
  if (now - rec.t > 60000) { rec.n = 0; rec.t = now; }
  rec.n++; LIVE_RATE.set(ip, rec);
  if (rec.n > 30) return json(res, 429, { ok: false, error: '太频繁，歇一分钟' });
  const r = db.prepare('INSERT INTO agent_live (page, from_who, text, ip) VALUES (?,?,?,?)')
    .run(String(b.page || '').slice(0, 200), String(b.from || 'user').slice(0, 20), text, ip);
  json(res, 200, { ok: true, id: Number(r.lastInsertRowid) });
});
route('GET', '/api/live/thread', async (req, res) => {
  ensureLive(db);
  const u = new URL(req.url, 'http://x');
  const since = Number(u.searchParams.get('since') || 0);
  const rows = db.prepare('SELECT id, page, from_who, text, created_at FROM agent_live WHERE id > ? ORDER BY id ASC LIMIT 200').all(since);
  const total = db.prepare('SELECT COUNT(*) c FROM agent_live').get().c;
  json(res, 200, { ok: true, total, messages: rows });
});
route('GET', '/api/live/pending', async (req, res) => {
  ensureLive(db);
  const u = new URL(req.url, 'http://x');
  const since = Number(u.searchParams.get('since') || 0);
  const rows = db.prepare("SELECT id, page, from_who, text, created_at FROM agent_live WHERE id > ? AND from_who <> 'asus' ORDER BY id ASC LIMIT 100").all(since);
  json(res, 200, { ok: true, messages: rows });
});
route('POST', '/api/live/reply', async (req, res) => {
  const b = (await readBody(req, 20000)) || {};
  const text = String(b.text || '').trim().slice(0, 2000);
  if (!text) return json(res, 400, { ok: false, error: 'empty' });
  ensureLive(db);
  const r = db.prepare("INSERT INTO agent_live (page, from_who, text) VALUES (?, 'asus', ?)").run(String(b.page || '').slice(0, 200), text);
  json(res, 200, { ok: true, id: Number(r.lastInsertRowid) });
});

// AI 读者：常驻程序取章节 → 调模型阅读 → 把结论写回群里（模型自己不能上网，得有人替它跑）
route('GET', '/api/cell/reader/feed', async (req, res) => {
  const u = new URL(req.url, 'http://x');
  json(res, 200, { readings: cellReader.listReadings(db, Number(u.searchParams.get('limit') || 20)) });
});
route('POST', '/api/cell/reader/run', async (req, res) => {
  const b = (await readBody(req, 20000)) || {};
  const out = await cellReader.runOnce({
    db, bookEngine, slug: String(b.slug || ''), modelName: cellEngine.aiStatus().model,
    askModel: (msgs, max) => cellEngine.askModel(msgs, max),
    emit: (type, payload, opt) => cellEngine.emit(type, payload, opt),
  });
  json(res, out.ok ? 200 : 400, out);
});
// 列出可读章节（给「AI 读者」挑）
route('GET', '/api/cell/reader/books', async (req, res) => {
  const books = bookEngine.listBooks().slice(0, 80).map(b => ({ slug: b.slug, title: b.title, no: b.no, chars: b.chars }));
  json(res, 200, { books });
});
// 群成员（多形态 AI）：大模型/智能体/工具/传感器/执行器 都能在群里
route('GET', '/api/cell/members', async (req, res) => json(res, 200, { members: cellEngine.listMembers() }));
route('POST', '/api/cell/members', async (req, res) => {
  const b = (await readBody(req, 20000)) || {};
  const out = cellEngine.registerMember(b);
  json(res, out.ok ? 200 : 400, out);
});
// 感知类成员上报（传感器/仪表：以群消息形式出现）
route('POST', '/api/cell/sensor', async (req, res) => {
  const b = (await readBody(req, 20000)) || {};
  const out = cellEngine.sensorReport(String(b.member_id || ''), String(b.metric || '数值'), b.value);
  json(res, out.ok ? 200 : 400, out);
});
route('GET', '/api/cell/ai', async (req, res) => json(res, 200, cellEngine.aiStatus()));
route('POST', '/api/cell/ai', async (req, res) => {
  const b = (await readBody(req, 20000)) || {};
  json(res, 200, cellEngine.setAi({ baseUrl: b.baseUrl, apiKey: b.apiKey, model: b.model }));
});
route('POST', '/api/exchange/listings/:id/review', async (req, res) => {
  try {
    const u = authUser(req); if (!u) return json(res, 401, { success: false, error: '请先登录' });
    // 2026-11-01 修复：原先只校验「已登录」，任何注册用户都能审核挂牌 —— 发行侧等于没有闸门。
    // 口径（VX 2026-11-01 拍板）：先用管理员账号起步，同时把 user_type=4（平台方）也认进来，
    // 等主站全面接入 user_type 后自然过渡，不必二次改代码。
    const isPlatform = u.role === 'admin' || Number(u.user_type) === 4;
    if (!isPlatform) return json(res, 403, { success: false, error: '只有平台方或管理员可以审核挂牌', code: 4200 });
    const b = (await readBody(req)) || {};
    const out = slimGov.reviewListing(db, parseInt(req.params[0]), !!b.approved);
    if (out && out.ok === false) return json(res, 409, { success: false, error: out.error, code: out.code });
    json(res, 200, { success: true, data: out });
  } catch (e) { json(res, 500, { success: false, error: e.message }); }
});
route('POST', '/api/exchange/proposals', async (req, res) => {
  try {
    const u = authUser(req); if (!u) return json(res, 401, { success: false, error: '请先登录' });
    const b = (await readBody(req)) || {};
    json(res, 200, { success: true, data: slimGov.submitProposal(db, { title: b.title, kind: b.kind, threshold: b.threshold, user_id: u.id }) });
  } catch (e) { json(res, 500, { success: false, error: e.message }); }
});
route('GET', '/api/exchange/proposals', async (req, res) => {
  try { json(res, 200, { success: true, data: slimGov.listProposals(db) }); }
  catch (e) { json(res, 500, { success: false, error: e.message }); }
});
route('POST', '/api/exchange/proposals/:id/vote', async (req, res) => {
  try {
    const u = authUser(req); if (!u) return json(res, 401, { success: false, error: '请先登录' });
    const b = (await readBody(req)) || {};
    json(res, 200, slimGov.voteProposal(db, parseInt(req.params[0]), u.id, !!b.approve));
  } catch (e) { json(res, 500, { success: false, error: e.message }); }
});
route('POST', '/api/exchange/bamboo/refresh', async (req, res) => {
  try {
    const u = authUser(req); if (!u) return json(res, 401, { success: false, error: '请先登录' });
    json(res, 200, slimGov.runBambooRefresh(db));
  } catch (e) { json(res, 500, { success: false, error: e.message }); }
});

route('GET', '/api/admin/indices', async (req, res) => {
  const u = authUser(req); if (!u || !['admin', 'core'].includes(u.role)) return json(res, 403, { success: false, error: '无权限' });
  try { const indices = db.prepare("SELECT * FROM indices ORDER BY category, name").all(); json(res, 200, { success: true, data: indices }); }
  catch (e) { json(res, 500, { success: false, error: e.message }); }
});

route('POST', '/api/admin/indices', async (req, res) => {
  const u = authUser(req); if (!u || !['admin', 'core'].includes(u.role)) return json(res, 403, { success: false, error: '无权限' });
  try { const body = await readBody(req); const r = indexEngine.createIndex(body); json(res, 200, r); }
  catch (e) { json(res, 500, { success: false, error: e.message }); }
});

route('POST', '/api/admin/indices/:id/components', async (req, res) => {
  const u = authUser(req); if (!u || !['admin', 'core'].includes(u.role)) return json(res, 403, { success: false, error: '无权限' });
  try { const body = await readBody(req); const r = indexEngine.addComponent(parseInt(req.params?.[0]), body.type, body.componentId, body.weight); json(res, 200, r); }
  catch (e) { json(res, 500, { success: false, error: e.message }); }
});

route('POST', '/api/admin/indices/recalculate', async (req, res) => {
  const u = authUser(req); if (!u || !['admin', 'core'].includes(u.role)) return json(res, 403, { success: false, error: '无权限' });
  try { const n = await indexEngine.recalculateAllIndices(); json(res, 200, { success: true, recalculated: n }); }
  catch (e) { json(res, 500, { success: false, error: e.message }); }
});

// ===== SLIM 撮合引擎 API =====
// 创建意向单（发单成功后即时返回该单撮合候选，供前端自助确认成交）
route('POST', '/api/match/intents', async (req, res) => {
  const u = authUser(req);
  if (!u) return json(res, 401, { success: false, error: '请先登录' });
  try {
    const body = await readBody(req);
    // P1-4 修复：userId 由登录态强制注入，禁止 body 覆盖伪造他人身份
    const r = matchEngine.createIntent(Object.assign({}, body, { userId: u.id }));
    if (r.success && r.data && r.data.id) {
      const c = matchEngine.findCandidates(r.data.id, { topN: 5, minScore: 30 });
      r.candidates = c.success ? (c.candidates || []) : [];
      if (c.note) r.candidate_note = c.note;
    }
    json(res, 200, r);
  } catch (e) { json(res, 500, { success: false, error: e.message }); }
});

// 我的意向单
route('GET', '/api/me/intents', async (req, res) => {
  const u = authUser(req);
  if (!u) return json(res, 401, { success: false, error: '请先登录' });
  const side = req.query.side || null;
  const status = req.query.status || null;
  json(res, 200, { success: true, data: matchEngine.getMyIntents(u.id, side, status) });
});

// 取消意向单
route('POST', '/api/match/intents/:id/cancel', async (req, res) => {
  const u = authUser(req);
  if (!u) return json(res, 401, { success: false, error: '请先登录' });
  try {
    const r = matchEngine.cancelIntent(parseInt(req.params[0]), u.id);
    json(res, 200, r);
  } catch (e) { json(res, 500, { success: false, error: e.message }); }
});

// 公开意向单列表（匿名）
route('GET', '/api/match/intents', async (req, res) => {
  try {
    const side = req.query.side || null;
    const indexCode = req.query.index || null;
    json(res, 200, { success: true, data: matchEngine.getPublicIntents(side, indexCode) });
  } catch (e) { json(res, 500, { success: false, error: e.message }); }
});

// 用户侧：查看自己某意向单的撮合候选（只读，归属校验）
route('GET', '/api/match/intents/:id/candidates', async (req, res) => {
  const u = authUser(req);
  if (!u) return json(res, 401, { success: false, error: '请先登录' });
  const intentId = parseInt(req.params[0]);
  const own = db.prepare('SELECT id FROM match_intents WHERE id = ? AND user_id = ?').get(intentId, u.id);
  if (!own) return json(res, 403, { success: false, error: '无权查看：该意向单不属于你' });
  try {
    const c = matchEngine.findCandidates(intentId, { topN: 10, minScore: 30 });
    json(res, 200, c);
  } catch (e) { json(res, 500, { success: false, error: e.message }); }
});

// 用户侧：自助确认撮合候选成交，生成合同（严格归属校验，防确认别人的单）
// body: { myIntentId, candidateIntentId, note }  或兼容 { recordId, buyerNote, sellerNote }
route('POST', '/api/match/confirm', async (req, res) => {
  const u = authUser(req);
  if (!u) return json(res, 401, { success: false, error: '请先登录' });
  try {
    const body = await readBody(req);
    let r;
    if (body.recordId) {
      // 兼容已有撮合记录的确认：校验 record 涉及当前用户
      const rec = db.prepare('SELECT * FROM match_records WHERE id = ?').get(parseInt(body.recordId));
      if (!rec) return json(res, 404, { success: false, error: '撮合记录不存在' });
      const bi = db.prepare('SELECT user_id FROM match_intents WHERE id = ?').get(rec.buyer_intent_id);
      const si = db.prepare('SELECT user_id FROM match_intents WHERE id = ?').get(rec.seller_intent_id);
      const involves = (bi && String(bi.user_id) === String(u.id)) || (si && String(si.user_id) === String(u.id));
      if (!involves) return json(res, 403, { success: false, error: '无权确认：该撮合不涉及你的单' });
      r = matchEngine.confirmMatch(parseInt(body.recordId), body.buyerNote || '', body.sellerNote || '');
    } else {
      // 自助候选确认：myIntentId 必须属于当前用户（confirmCandidate 内二次校验）
      r = matchEngine.confirmCandidate(u.id, parseInt(body.myIntentId), parseInt(body.candidateIntentId), body.note || '');
    }
    if (r.success && r.data) {
      sseEngine.broadcast('match', { contract_no: r.data.contract_no, status: r.data.status, self_service: true });
    }
    json(res, 200, r);
  } catch (e) { json(res, 500, { success: false, error: e.message }); }
});

// 执行撮合（管理员触发；支持批量参数：minScore / intentIds[] / category）
route('POST', '/api/admin/match/run', async (req, res) => {
  const u = authUser(req);
  if (!u) return json(res, 401, { success: false, error: '请先登录' });
  if (u.role !== 'admin') return json(res, 403, { success: false, error: '仅管理员可触发撮合' });
  try {
    const body = await readBody(req);
    const matches = await matchEngine.runMatching({
      minScore: body.minScore,
      intentIds: body.intentIds,
      category: body.category
    });
    json(res, 200, { success: true, data: matches, count: matches.length });
  } catch (e) { json(res, 500, { success: false, error: e.message }); }
});

// 确认撮合并生成合同
route('POST', '/api/match/records/:id/confirm', async (req, res) => {
  const u = authUser(req);
  if (!u) return json(res, 401, { success: false, error: '请先登录' });
  try {
    const id = parseInt(req.params[0]);
    // P1-2 修复：仅撮合双方可确认，禁止替他人签约
    const rec = db.prepare('SELECT mr.id, bi.user_id AS buyer_uid, si.user_id AS seller_uid FROM match_records mr JOIN match_intents bi ON mr.buyer_intent_id = bi.id JOIN match_intents si ON mr.seller_intent_id = si.id WHERE mr.id = ?').get(id);
    if (!rec) return json(res, 404, { success: false, error: '撮合记录不存在' });
    if (rec.buyer_uid !== u.id && rec.seller_uid !== u.id) return json(res, 403, { success: false, error: '无权限确认此撮合' });
    const body = await readBody(req);
    const r = matchEngine.confirmMatch(id, body.buyerNote || '', body.sellerNote || '');
    if (r.success && r.data) {
      sseEngine.broadcast('match', { record_id: r.data.id, score: r.data.match_score });
    }
    json(res, 200, r);
  } catch (e) { json(res, 500, { success: false, error: e.message }); }
});

// 我的撮合记录（按当前用户归属，避免越权暴露他人意向）
route('GET', '/api/match/records', async (req, res) => {
  const u = authUser(req);
  if (!u) return json(res, 401, { success: false, error: '请先登录' });
  try { json(res, 200, { success: true, data: matchEngine.getMatchHistory(u.id, 50) }); }
  catch (e) { json(res, 500, { success: false, error: e.message }); }
});

// 合同操作
route('POST', '/api/match/contracts/:id/action', async (req, res) => {
  const u = authUser(req);
  if (!u) return json(res, 401, { success: false, error: '请先登录' });
  try {
    const body = await readBody(req);
    const r = matchEngine.updateContract(parseInt(req.params[0]), body.action, u.id);
    if (r.success === false) {
      const code = r.error === '合同不存在' ? 404 : (r.error === '无权限操作此合同' ? 403 : 400);
      return json(res, code, r);
    }
    json(res, 200, r);
  } catch (e) { json(res, 500, { success: false, error: e.message }); }
});

// 我的合同
route('GET', '/api/me/contracts', async (req, res) => {
  const u = authUser(req);
  if (!u) return json(res, 401, { success: false, error: '请先登录' });
  json(res, 200, { success: true, data: db.prepare("SELECT * FROM match_contracts WHERE buyer_id = ? OR seller_id = ? ORDER BY created_at DESC LIMIT 20").all(u.id, u.id) });
});

// 撮合历史
route('GET', '/api/match/history', async (req, res) => {
  const u = authUser(req);
  if (!u) return json(res, 401, { success: false, error: '请先登录' });
  json(res, 200, { success: true, data: matchEngine.getMatchHistory(u.id, 20) });
});

// ===== 合同引擎路由 =====
// 合同模板列表
route('GET', '/api/contracts/templates', async (req, res) => {
  json(res, 200, { success: true, data: contractEngine.getTemplates() });
});

// 生成合同（从撮合记录）
route('POST', '/api/admin/contract/generate', async (req, res) => {
  const u = authUser(req);
  if (!u || !['admin', 'core'].includes(u.role)) return json(res, 403, { success: false, error: '无权限' });
  try {
    const body = await readBody(req);
    const r = contractEngine.generateContract(body.matchRecordId, body.templateId);
    if (r.success && r.data) {
      const c = r.data;
      sseEngine.sendEvent(c.buyer_id || u.id, 'CONTRACT', { contract_no: c.contract_no, status: c.status });
      sseEngine.sendEvent(c.seller_id, 'CONTRACT', { contract_no: c.contract_no, status: c.status });
    }
    json(res, 200, r);
  } catch (e) { json(res, 500, { success: false, error: e.message }); }
});

// 批量生成合同（触发撮合后自动生成）
route('POST', '/api/admin/contract/generate-all', async (req, res) => {
  const u = authUser(req);
  if (!u || !['admin', 'core'].includes(u.role)) return json(res, 403, { success: false, error: '无权限' });
  try {
    const records = db.prepare("SELECT * FROM match_records WHERE status = 'matched' AND contract_id IS NULL").all();
    const results = records.map(r => contractEngine.generateContract(r.id));
    json(res, 200, { success: true, count: results.length, data: results });
  } catch (e) { json(res, 500, { success: false, error: e.message }); }
});

// 合同状态操作
route('POST', '/api/contracts/:id/action', async (req, res) => {
  const u = authUser(req);
  if (!u) return json(res, 401, { success: false, error: '请先登录' });
  try {
    const body = await readBody(req);
    const r = contractEngine.contractAction(parseInt(req.params[0]), body.action, u.id);
    json(res, 200, r);
  } catch (e) { json(res, 500, { success: false, error: e.message }); }
});

// 发起签名请求
route('POST', '/api/contracts/:id/signature', async (req, res) => {
  const u = authUser(req);
  if (!u) return json(res, 401, { success: false, error: '请先登录' });
  try {
    const body = await readBody(req);
    const r = contractEngine.requestSignature(parseInt(req.params[0]), body.role || 'buyer', u.id);
    json(res, 200, r);
  } catch (e) { json(res, 500, { success: false, error: e.message }); }
});

// 验证签名
route('POST', '/api/signatures/:id/verify', async (req, res) => {
  const u = authUser(req);
  if (!u) return json(res, 401, { success: false, error: '请先登录' });
  try {
    const body = await readBody(req);
    const r = contractEngine.verifySignature(parseInt(req.params[0]), body.signCode);
    json(res, 200, r);
  } catch (e) { json(res, 500, { success: false, error: e.message }); }
});

// 提交交付
route('POST', '/api/contracts/:id/delivery', async (req, res) => {
  const u = authUser(req);
  if (!u) return json(res, 401, { success: false, error: '请先登录' });
  try {
    const body = await readBody(req);
    const r = contractEngine.submitDelivery(parseInt(req.params[0]), u.id, body);
    json(res, 200, r);
  } catch (e) { json(res, 500, { success: false, error: e.message }); }
});

// 审核交付
route('POST', '/api/contracts/deliveries/:id/review', async (req, res) => {
  const u = authUser(req);
  if (!u) return json(res, 401, { success: false, error: '请先登录' });
  try {
    const body = await readBody(req);
    const r = contractEngine.reviewDelivery(parseInt(req.params[0]), u.id, body.approved, body.note || '');
    json(res, 200, r);
  } catch (e) { json(res, 500, { success: false, error: e.message }); }
});

// 发起合同付款（复用支付基建：simulate 即时到账 / alipay 返回 cashier_url / wechat 返回打赏码）
route('POST', '/api/contracts/:id/payment', async (req, res) => {
  const u = authUser(req);
  if (!u) return json(res, 401, { success: false, error: '请先登录' });
  try {
    const body = await readBody(req, 1e5);
    const cid = parseInt(req.params[0]);
    const c = db.prepare("SELECT * FROM match_contracts WHERE id = ?").get(cid);
    if (!c) return json(res, 404, { success: false, error: '合同不存在' });
    if (c.buyer_id !== u.id) return json(res, 403, { success: false, error: '仅买方可发起付款' });
    if (!['signed', 'executing'].includes(c.status)) return json(res, 400, { success: false, error: '当前合同状态不允许付款（需已签署）' });
    // 金额：优先用合同 total_amount，允许买家传自定义金额（≥1 元兜底）
    let amount = Number(body.amount);
    if (!amount || !isFinite(amount)) amount = Number(c.total_amount) || 1;
    amount = Math.max(1, amount);
    const channel = ['alipay', 'wechat', 'bank'].includes(body.channel) ? body.channel : 'alipay';
    const no = orderNo('CP');
    const mode = getSetting('payment_mode', 'simulate');
    const base = (getSetting('site_domain', 'moonarmor.cn') === 'moonarmor.cn' ? 'https://moonarmor.cn' : 'http://47.116.167.44');
    const note = '合同付款 ' + c.contract_no;
    // 记账 + 创建支付记录（pending）
    db.prepare("INSERT INTO ledger (user_id, biz_type, biz_id, order_no, amount, channel, direction, note, status) VALUES (?, 'contract_payment', ?, ?, ?, ?, 'in', ?, 'pending')")
      .run(u.id, cid, no, amount, channel, note);
    const r = contractEngine.createPayment(cid, u.id, c.seller_id, { amount, currency: 'CNY', payment_method: channel, order_no: no });
    if (!r.success) return json(res, 500, r);
    // simulate 模式：即时到账
    if (mode === 'simulate') {
      settleContractPayment(no);
      return json(res, 200, { success: true, paid: true, order_no: no, amount, payment: r.data });
    }
    // alipay：返回官方收银台（未配置则回退 /pay/alipay 扫码页）
    if (channel === 'alipay') {
      const form = pay.buildPagePayForm(no, note, amount, { returnUrl: base + '/contract.html?paid=' + no });
      const cashier = form.url ? form.url : (base + '/pay/alipay?a=' + amount + '&o=' + encodeURIComponent(no));
      return json(res, 200, { success: true, paid: false, order_no: no, amount, channel: 'alipay', cashier_url: cashier, payment: r.data });
    }
    // wechat：返回打赏码（与下载一致）
    if (channel === 'wechat') {
      return json(res, 200, { success: true, paid: false, order_no: no, amount, channel: 'wechat', qr_img: '/wx-zanshang.jpg', payment: r.data });
    }
    json(res, 200, { success: true, paid: false, order_no: no, amount, channel: 'bank', pay_url: base + '/pay/qr?o=' + encodeURIComponent(no) + '&a=' + amount, payment: r.data });
  } catch (e) { json(res, 500, { success: false, error: e.message }); }
});

// 合同付款手动确认（买家自确认 / 管理员核对，与 download/confirm 同构）
route('POST', '/api/contracts/payments/confirm', async (req, res) => {
  const u = authUser(req);
  if (!u) return json(res, 401, { success: false, error: '请先登录' });
  try {
    const body = await readBody(req, 1e5);
    const no = String(body.order_no || '');
    const p = contractEngine.getPaymentByOrderNo(no);
    if (!p) return json(res, 404, { success: false, error: '支付记录不存在' });
    if (p.payer_id !== u.id && u.role !== 'admin') return json(res, 403, { success: false, error: '无权操作' });
    if (p.status === 'completed') return json(res, 200, { success: true, already: true, payment: p });
    settleContractPayment(no);
    const p2 = contractEngine.getPaymentByOrderNo(no);
    json(res, 200, { success: true, paid: true, payment: p2 });
  } catch (e) { json(res, 500, { success: false, error: e.message }); }
});

// 条款库
route('GET', '/api/contracts/clauses', async (req, res) => {
  json(res, 200, { success: true, data: contractEngine.getClauseLibrary() });
});

// 合同详情
route('GET', '/api/contracts/:id', async (req, res) => {
  json(res, 200, { success: true, data: contractEngine.getContractDetail(parseInt(req.params[0])) });
});


// ===== AI 条款审核路由 =====
// 单合同审核
route('GET', '/api/admin/review/:id', async (req, res) => {
  const u = authUser(req);
  if (!u || !['admin', 'core'].includes(u.role)) return json(res, 403, { success: false, error: '无权限' });
  try {
    const r = aiReview.reviewContract(parseInt(req.params[0]));
    json(res, 200, r);
  } catch (e) { json(res, 500, { success: false, error: e.message }); }
});
// 批量审核
route('POST', '/api/admin/review/batch', async (req, res) => {
  const u = authUser(req);
  if (!u || !['admin', 'core'].includes(u.role)) return json(res, 403, { success: false, error: '无权限' });
  try {
    const body = await readBody(req);
    const r = aiReview.batchReview(body.limit || 50);
    json(res, 200, r);
  } catch (e) { json(res, 500, { success: false, error: e.message }); }
});
// 生成审核报告
route('GET', '/api/admin/report/:id', async (req, res) => {
  const u = authUser(req);
  if (!u || !['admin', 'core'].includes(u.role)) return json(res, 403, { success: false, error: '无权限' });
  try {
    const r = aiReview.generateReport(parseInt(req.params[0]));
    json(res, 200, r);
  } catch (e) { json(res, 500, { success: false, error: e.message }); }
});

// ===== SSE 通知路由 =====
route('GET', '/api/sse/subscribe', async (req, res) => {
  const u = authUser(req);
  if (!u) return json(res, 401, { success: false, error: '请先登录' });
  sseEngine.subscribe(u.id, res);
});

// ===== 信用评分路由 =====
// 我的信用档案
route('GET', '/api/me/credit', async (req, res) => {
  const u = authUser(req);
  if (!u) return json(res, 401, { success: false, error: '请先登录' });
  try {
    const p = creditEngine.initProfile(u.id);
    const events = creditEngine.getEvents(u.id, 20);
    json(res, 200, { success: true, data: { profile: p, events } });
  } catch (e) { json(res, 500, { success: false, error: e.message }); }
});
// 别名：文档命名 /api/credit/me（当前用户信用档案）
route('GET', '/api/credit/me', async (req, res) => {
  const u = authUser(req);
  if (!u) return json(res, 401, { success: false, error: '请先登录' });
  try {
    const p = creditEngine.initProfile(u.id);
    const events = creditEngine.getEvents(u.id, 20);
    json(res, 200, { success: true, data: { profile: p, events } });
  } catch (e) { json(res, 500, { success: false, error: e.message }); }
});

// 重新计算信用分（管理员）
route('POST', '/api/admin/credit/recalculate', async (req, res) => {
  const u = authUser(req);
  if (!u || !['admin', 'core'].includes(u.role)) return json(res, 403, { success: false, error: '无权限' });
  try {
    const body = await readBody(req);
    const targetId = body.userId || u.id;
    const p = creditEngine.recalculateCredit(targetId);
    json(res, 200, { success: true, data: p });
  } catch (e) { json(res, 500, { success: false, error: e.message }); }
});

// 批量重新计算（管理员）
route('POST', '/api/admin/credit/recalculate-all', async (req, res) => {
  const u = authUser(req);
  if (!u || !['admin', 'core'].includes(u.role)) return json(res, 403, { success: false, error: '无权限' });
  try {
    const users = db.prepare("SELECT id FROM users WHERE role IN ('core','registered')").all();
    const results = users.map(us => creditEngine.recalculateCredit(us.id));
    json(res, 200, { success: true, count: results.length, data: results.filter(Boolean) });
  } catch (e) { json(res, 500, { success: false, error: e.message }); }
});

// 所有信用档案列表（管理员）
route('GET', '/api/admin/credits', async (req, res) => {
  const u = authUser(req);
  if (!u || !['admin', 'core'].includes(u.role)) return json(res, 403, { success: false, error: '无权限' });
  json(res, 200, { success: true, data: creditEngine.getAllProfiles(100) });
});

// 单用户信用详情
route('GET', '/api/credits/:id', async (req, res) => {
  const u = authUser(req);
  if (!u) return json(res, 401, { success: false, error: '请先登录' });
  const profile = creditEngine.getProfile(parseInt(req.params[0]));
  const events = creditEngine.getEvents(parseInt(req.params[0]), 50);
  json(res, 200, { success: true, data: { profile, events } });
});


// ===== 审计智能体（与档案开发智能体协同） =====
route('POST', '/api/admin/audit/run', async (req, res) => {
  const u = authUser(req); if (!u || !['admin', 'core'].includes(u.role)) return json(res, 403, { error: '无权限' });
  const b = await readBody(req, 1e5).catch(() => ({}));
  const run = auditAgent.runAudit({ scope: b.scope || 'all', publish: !!b.publish, triggered_by: 'manual' });
  json(res, 200, run);
});

route('GET', '/api/admin/audit', async (req, res) => {
  const u = authUser(req); if (!u || !['admin', 'core'].includes(u.role)) return json(res, 403, { error: '无权限' });
  json(res, 200, { items: auditAgent.listRuns(50), latest: auditAgent.latestSummary() });
});

route('GET', '/api/admin/audit/:id', async (req, res) => {
  const u = authUser(req); if (!u || !['admin', 'core'].includes(u.role)) return json(res, 403, { error: '无权限' });
  const run = auditAgent.getRun(Number(req.params[0]));
  if (!run) return json(res, 404, { error: '审计记录不存在' });
  json(res, 200, run);
});

route('POST', '/api/admin/audit/:id/publish', async (req, res) => {
  const u = authUser(req); if (!u || !['admin', 'core'].includes(u.role)) return json(res, 403, { error: '无权限' });
  const run = auditAgent.getRun(Number(req.params[0]));
  if (!run) return json(res, 404, { error: '审计记录不存在' });
  const docId = auditAgent.publishRun(Number(req.params[0]));
  json(res, 200, { ok: true, doc_id: docId });
});

// 公开：最新审计摘要（治理中心页用）
route('GET', '/api/audit/summary', async (req, res) => {
  json(res, 200, auditAgent.latestSummary());
});

// ===== 档案域 API（PIRA）=====
route('GET', '/api/archive/catalog', async (req, res) => json(res, 200, archiveEngine.getCatalogTree()));
route('GET', '/api/archive/spectra', async (req, res) => json(res, 200, archiveEngine.getSpectra()));
route('GET', '/api/archive/bands', async (req, res) => json(res, 200, archiveEngine.getBands(req.query.spectrum)));
route('GET', '/api/archive/channels', async (req, res) => json(res, 200, archiveEngine.getChannels(req.query.band)));
route('GET', '/api/archive/frequencies', async (req, res) => json(res, 200, archiveEngine.getFrequencies()));
route('GET', '/api/archive/device-roles', async (req, res) => json(res, 200, { success: true, data: archiveEngine.getDeviceRoles() }));
route('GET', '/api/archive/archives', async (req, res) => { const o = deriveArchiveOwner(req); if (!o) return json(res, 401, { error: '未登录' }); json(res, 200, archiveEngine.getArchives({ ownerType: o.ownerType, ownerId: o.ownerId, frequencyId: req.query.frequencyId, limit: Number(req.query.limit) || 50, offset: Number(req.query.offset) || 0 })); });
route('GET', '/api/archive/search', async (req, res) => { const o = deriveArchiveOwner(req); if (!o) return json(res, 401, { error: '未登录' }); json(res, 200, archiveEngine.searchArchives(o.ownerType, o.ownerId, req.query.keyword || '', Number(req.query.limit) || 50)); });
route('GET', '/api/archive/frequencies-summary', async (req, res) => { const o = deriveArchiveOwner(req); if (!o) return json(res, 401, { error: '未登录' }); json(res, 200, archiveEngine.frequencySummary(o.ownerType, o.ownerId)); });
route('POST', '/api/archive/records', async (req, res) => { const o = deriveArchiveOwner(req); if (!o) return json(res, 401, { error: '未登录' }); const body = await readBody(req); const g = archiveEngine.checkGates(o.ownerType, o.ownerId); if (!g.allowed) return json(res, 403, { error: '五重门未全开', blockedBy: g.blockedBy, code: 4001 }); body.ownerType = o.ownerType; body.ownerId = o.ownerId; json(res, 200, archiveEngine.createRecord(body)); });
route('POST', '/api/archive/records/batch', async (req, res) => { const o = deriveArchiveOwner(req); if (!o) return json(res, 401, { error: '未登录' }); const body = await readBody(req); const g = archiveEngine.checkGates(o.ownerType, o.ownerId); if (!g.allowed) return json(res, 403, { error: '五重门未全开', blockedBy: g.blockedBy, code: 4001 }); (body.records || []).forEach(function(r){ r.ownerType = o.ownerType; r.ownerId = o.ownerId; }); json(res, 200, archiveEngine.createRecordsBatch(body.records || [])); });
route('POST', '/api/archive/distill', async (req, res) => {
  const o = deriveArchiveOwner(req);
  if (!o) return json(res, 401, { error: '未登录' });
  const body = await readBody(req);
  const out = archiveEngine.runDistill(o.ownerType, o.ownerId, body.ruleId);
  // 协同：档案开发智能体蒸馏完成后，审计智能体立即核验档案域
  let audit = null;
  try {
    const run = auditAgent.runAudit({ scope: 'archive', triggered_by: 'distill', publish: false });
    audit = { id: run.id, conclusion: run.conclusion, total_checks: run.total_checks, pass_checks: run.pass_checks, warn_checks: run.warn_checks, fail_checks: run.fail_checks };
  } catch (e) { audit = { error: String(e.message || e) }; }
  json(res, 200, Object.assign({}, out, { audit }));
});
route('GET', '/api/archive/shadow', async (req, res) => { const o = deriveArchiveOwner(req); if (!o) return json(res, 401, { error: '未登录' }); json(res, 200, archiveEngine.getShadowSummary(o.ownerType, o.ownerId)); });
route('GET', '/api/archive/grants/check', async (req, res) => { const o = deriveArchiveOwner(req); if (!o) return json(res, 401, { error: '未登录' }); json(res, 200, archiveEngine.checkGates(o.ownerType, o.ownerId)); });
// 记录层
route('GET', '/api/archive/records', async (req, res) => { const o = deriveArchiveOwner(req); if (!o) return json(res, 401, { error: '未登录' }); json(res, 200, archiveEngine.getRecords({ ownerType: o.ownerType, ownerId: o.ownerId, channelId: req.query.channelId ? Number(req.query.channelId) : undefined, frequencyId: req.query.frequencyId, limit: Number(req.query.limit) || 50, offset: Number(req.query.offset) || 0 })); });
route('GET', '/api/archive/records/:id', async (req, res) => { const o = deriveArchiveOwner(req); if (!o) return json(res, 401, { error: '未登录' }); const rec = archiveEngine.getRecord(Number(req.params[0])); if (!rec || rec.owner_id !== o.ownerId || rec.owner_type !== o.ownerType) return json(res, 404, { error: 'not found' }); json(res, 200, rec); });
route('DELETE', '/api/archive/records/:id', async (req, res) => { const o = deriveArchiveOwner(req); if (!o) return json(res, 401, { error: '未登录' }); json(res, 200, archiveEngine.deleteRecord(Number(req.params[0]), o.ownerId)); });
// 档案层
route('GET', '/api/archive/archives/:id', async (req, res) => { const o = deriveArchiveOwner(req); if (!o) return json(res, 401, { error: '未登录' }); const arc = archiveEngine.getArchive(Number(req.params[0])); if (!arc || arc.owner_id !== o.ownerId || arc.owner_type !== o.ownerType) return json(res, 404, { error: 'not found' }); json(res, 200, arc); });
route('PUT', '/api/archive/archives/:id', async (req, res) => { const o = deriveArchiveOwner(req); if (!o) return json(res, 401, { error: '未登录' }); const body = await readBody(req); json(res, 200, archiveEngine.updateArchive(Number(req.params[0]), o.ownerId, body)); });
route('POST', '/api/archive/archives/:id/license', async (req, res) => { const o = deriveArchiveOwner(req); if (!o) return json(res, 401, { error: '未登录' }); const body = await readBody(req); json(res, 200, archiveEngine.licenseArchive(Number(req.params[0]), o.ownerId, body.licenseeId)); });
route('DELETE', '/api/archive/archives/:id', async (req, res) => { const o = deriveArchiveOwner(req); if (!o) return json(res, 401, { error: '未登录' }); json(res, 200, archiveEngine.deleteArchive(Number(req.params[0]), o.ownerId)); });
// ===== 多路径归属（书稿要求：同一内容单元可被不同路径索引，不是复制）=====
route('GET', '/api/archive/archives/:id/filings', async (req, res) => { const o = deriveArchiveOwner(req); if (!o) return json(res, 401, { error: '未登录' }); const arc = archiveEngine.getArchive(Number(req.params[0])); if (!arc || arc.owner_id !== o.ownerId) return json(res, 404, { error: 'not found' }); json(res, 200, { archiveId: arc.id, primary: arc.frequency_id, filings: archiveEngine.getFilings(arc.id) }); });
route('POST', '/api/archive/archives/:id/filings', async (req, res) => { const o = deriveArchiveOwner(req); if (!o) return json(res, 401, { error: '未登录' }); const body = await readBody(req); json(res, 200, archiveEngine.fileArchive(Number(req.params[0]), o.ownerId, String(body.frequency || ''), body.note)); });
route('DELETE', '/api/archive/archives/:id/filings/:frequency', async (req, res) => { const o = deriveArchiveOwner(req); if (!o) return json(res, 401, { error: '未登录' }); json(res, 200, archiveEngine.unfileArchive(Number(req.params[0]), o.ownerId, String(req.params[1] || ''))); });
route('GET', '/api/archive/by-frequency', async (req, res) => { const o = deriveArchiveOwner(req); if (!o) return json(res, 401, { error: '未登录' }); const u = new URL(req.url, 'http://x'); json(res, 200, archiveEngine.getArchivesByFrequency(o.ownerType, o.ownerId, String(u.searchParams.get('frequency') || ''), Number(u.searchParams.get('limit') || 50), Number(u.searchParams.get('offset') || 0))); });
route('GET', '/api/archive/licenses', async (req, res) => { const o = deriveArchiveOwner(req); if (!o) return json(res, 401, { error: '未登录' }); json(res, 200, archiveEngine.getLicenses(o.ownerType, o.ownerId)); });
route('POST', '/api/archive/licenses/:id/revoke', async (req, res) => { const o = deriveArchiveOwner(req); if (!o) return json(res, 401, { error: '未登录' }); json(res, 200, archiveEngine.revokeLicense(Number(req.params[0]), o.ownerId)); });
// 蒸馏层
route('GET', '/api/archive/distill/rules', async (req, res) => json(res, 200, archiveEngine.getDistillRules()));
route('PUT', '/api/archive/distill/rules/:id', async (req, res) => { const o = deriveArchiveOwner(req); if (!o) return json(res, 401, { error: '未登录' }); const body = await readBody(req); json(res, 200, archiveEngine.updateDistillRules(Number(req.params[0]), body)); });
route('GET', '/api/archive/distill/stats', async (req, res) => { const o = deriveArchiveOwner(req); if (!o) return json(res, 401, { error: '未登录' }); json(res, 200, archiveEngine.getDistillStats(o.ownerType, o.ownerId)); });
// 设备层
route('POST', '/api/archive/devices/register', async (req, res) => { const o = deriveArchiveOwner(req); if (!o) return json(res, 401, { error: '未登录' }); const body = await readBody(req); body.ownerType = o.ownerType; body.ownerId = o.ownerId; json(res, 200, archiveEngine.registerDevice(body)); });
route('GET', '/api/archive/devices', async (req, res) => { const o = deriveArchiveOwner(req); if (!o) return json(res, 401, { error: '未登录' }); json(res, 200, archiveEngine.getDevices(o.ownerType, o.ownerId)); });
route('GET', '/api/archive/devices/:deviceId', async (req, res) => { const o = deriveArchiveOwner(req); if (!o) return json(res, 401, { error: '未登录' }); const d = archiveEngine.getDevice(req.params[0]); if (!d || !d.device || d.device.owner_id !== o.ownerId) return json(res, 404, { error: 'not found' }); json(res, 200, d); });
route('POST', '/api/archive/devices/roles', async (req, res) => { const o = deriveArchiveOwner(req); if (!o) return json(res, 401, { error: '未登录' }); const body = await readBody(req); const d = db.prepare('SELECT owner_id FROM archive_devices WHERE device_id = ?').get(body.deviceId); if (!d || d.owner_id !== o.ownerId) return json(res, 404, { error: 'not found' }); json(res, 200, archiveEngine.setDeviceRole(body.deviceId, body.role)); });
route('POST', '/api/archive/devices/heartbeat', async (req, res) => { const o = deriveArchiveOwner(req); if (!o) return json(res, 401, { error: '未登录' }); const body = await readBody(req); const d = db.prepare('SELECT owner_id FROM archive_devices WHERE device_id = ?').get(body.deviceId); if (!d || d.owner_id !== o.ownerId) return json(res, 404, { error: 'not found' }); json(res, 200, archiveEngine.heartbeat(body.deviceId)); });
// 授权层
route('GET', '/api/archive/grants', async (req, res) => { const o = deriveArchiveOwner(req); if (!o) return json(res, 401, { error: '未登录' }); json(res, 200, archiveEngine.getGrants(o.ownerType, o.ownerId)); });
route('POST', '/api/archive/grants', async (req, res) => { const o = deriveArchiveOwner(req); if (!o) return json(res, 401, { error: '未登录' }); const body = await readBody(req); json(res, 200, archiveEngine.createGrant(o.ownerType, o.ownerId, body.gates || {})); });
// 撤销五重门授权（闭环收尾：原先只能开不能关）
route('POST', '/api/archive/grants/:id/revoke', async (req, res) => { const o = deriveArchiveOwner(req); if (!o) return json(res, 401, { error: '未登录' }); const r = archiveEngine.revokeGrant(Number(req.params[0]), o.ownerType, o.ownerId); json(res, r.ok ? 200 : 410, r); });
// 智能体层
route('GET', '/api/archive/agents', async (req, res) => { const o = deriveArchiveOwner(req); if (!o) return json(res, 401, { error: '未登录' }); json(res, 200, archiveEngine.getAgents(o.ownerType, o.ownerId)); });
route('POST', '/api/archive/agents', async (req, res) => { const o = deriveArchiveOwner(req); if (!o) return json(res, 401, { error: '未登录' }); const body = await readBody(req); json(res, 200, archiveEngine.createAgent(o.ownerType, o.ownerId, body)); });
// 档案开发智能体：技能 / 协同矩阵 / 调用（与审计智能体协同）
route('GET', '/api/archive/agent-matrix', async (req, res) => { const o = deriveArchiveOwner(req); if (!o) return json(res, 401, { error: '未登录' }); json(res, 200, archiveEngine.getMatrix(o.ownerType, o.ownerId)); });
route('GET', '/api/archive/agents/default-skills', async (req, res) => json(res, 200, archiveEngine.getDefaultSkills()));
route('GET', '/api/archive/agents/:id', async (req, res) => { const o = deriveArchiveOwner(req); if (!o) return json(res, 401, { error: '未登录' }); const a = archiveEngine.getAgent(Number(req.params[0])); if (!a || !a.agent || a.agent.owner_id !== o.ownerId) return json(res, 404, { error: 'not found' }); json(res, 200, a); });
route('GET', '/api/archive/agents/:id/skills', async (req, res) => { const o = deriveArchiveOwner(req); if (!o) return json(res, 401, { error: '未登录' }); const ag = db.prepare('SELECT owner_id FROM archive_agents WHERE id = ?').get(Number(req.params[0])); if (!ag || ag.owner_id !== o.ownerId) return json(res, 404, { error: 'not found' }); json(res, 200, archiveEngine.getSkills(Number(req.params[0]))); });
route('POST', '/api/archive/agents/:id/skills', async (req, res) => {
  const o = deriveArchiveOwner(req);
  if (!o) return json(res, 401, { error: '未登录' });
  const body = await readBody(req);
  const agent = db.prepare('SELECT id, owner_id FROM archive_agents WHERE id = ?').get(Number(req.params[0]));
  if (!agent || agent.owner_id !== o.ownerId) return json(res, 404, { error: '智能体不存在' });
  const name = String(body.skill_name || '').trim();
  if (!name) return json(res, 400, { error: '技能名必填' });
  db.prepare('INSERT OR IGNORE INTO archive_skills (agent_id, skill_name, skill_meta) VALUES (?, ?, ?)').run(agent.id, name, JSON.stringify(body.skill_meta || {}));
  json(res, 200, { ok: true });
});
route('POST', '/api/archive/agents/:id/invoke', async (req, res) => { const o = deriveArchiveOwner(req); if (!o) return json(res, 401, { error: '未登录' }); const ag = db.prepare('SELECT owner_id FROM archive_agents WHERE id = ?').get(Number(req.params[0])); if (!ag || ag.owner_id !== o.ownerId) return json(res, 404, { error: 'not found' }); const body = await readBody(req); json(res, 200, archiveEngine.invokeAgent(Number(req.params[0]), body.action, body.payload || {})); });
route('POST', '/api/archive/agents/seed', async (req, res) => { const o = deriveArchiveOwner(req); if (!o) return json(res, 401, { error: '未登录' }); json(res, 200, archiveEngine.ensureAllAgentCapabilities()); });
// 主体映射（五重门主体）
// 列表仅管理员可看（横向越权防护：id_no 在引擎层已脱敏）
route('GET', '/api/archive/principals', async (req, res) => {
  const u = authUser(req);
  if (!u) return json(res, 401, { error: '未登录' });
  if (u.role !== 'admin') return json(res, 403, { error: '仅管理员可查看全部主体' });
  json(res, 200, { success: true, data: archiveEngine.getPrincipals(req.query.type || null) });
});
route('GET', '/api/archive/principals/me', async (req, res) => {
  const o = deriveArchiveOwner(req);
  if (!o) return json(res, 401, { error: '未登录' });
  json(res, 200, { success: true, data: archiveEngine.getPrincipalByUser(o.ownerId) });
});

// SLIM 定时撮合（环境变量 SLIM_MATCH_INTERVAL_MIN 控制间隔分钟，0/缺省 = 关闭）
const MATCH_INTERVAL_MIN = Number(process.env.SLIM_MATCH_INTERVAL_MIN || 0);
if (MATCH_INTERVAL_MIN > 0) {
  const runScheduled = () => matchEngine.runMatching({})
    .then(list => { if (list.length) sseEngine.broadcast('match', { scheduled: true, count: list.length }); })
    .catch(err => console.error('scheduled matching error:', err.message));
  console.log('scheduled matching enabled: every ' + MATCH_INTERVAL_MIN + ' min');
  runScheduled();
  setInterval(runScheduled, MATCH_INTERVAL_MIN * 60 * 1000);
}

// 进程级兜底：任何未捕获异常只记日志、不退出，避免单请求搞崩全站导致 502
process.on('uncaughtException', err => { console.error('[uncaughtException]', err && err.message); });
process.on('unhandledRejection', err => { console.error('[unhandledRejection]', err && err.message); });

function listen(port, attempts) {
  server.once('error', err => {
    if (err.code === 'EADDRINUSE' && attempts > 0) { console.log('port ' + port + ' busy, trying ' + (port + 1)); setTimeout(() => listen(port + 1, attempts - 1), 300); }
    else { console.error('listen failed:', err.message); process.exit(1); }
  });
  server.listen(port, () => console.log('moonarmor server running at http://127.0.0.1:' + port + '  (db: ' + require('./db').DB_PATH + ')'));
}
listen(PORT, 10);
