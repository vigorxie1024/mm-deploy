'use strict';
// modules/chat/chat.js —— 自建 chat：直连模型 API（BYOK），不经任何平台网页
// 为什么：2026-11-05 平台禁言事件证明「抓网页代发」是死路。这里只走官方 API，
// 页面、密钥、历史全在我们自己的库和域名里，任何人禁言都禁不到这条路上。
// 安全：Key 用 AES-256-GCM 加密后存库，密钥由 CELL_GATE_SECRET 派生；接口只回「有没有配」，永不回 Key 原文。

const https = require('https');
const http = require('http');
const crypto = require('crypto');

const PROVIDERS = {
  deepseek: {
    base: process.env.CHAT_BASE_DEEPSEEK || 'https://api.deepseek.com',
    models: ['deepseek-chat', 'deepseek-reasoner'],
    defaultModel: 'deepseek-chat',
    label: 'DeepSeek 官方 API',
  },
};

function create(deps) {
  const db = deps.db, route = deps.route, json = deps.json, readBody = deps.readBody;
  const personOf = deps.personOf, owner = deps.owner, secret = deps.secret || 'moonarmor-cell-gate-v1';
  const keyOf = () => crypto.createHash('sha256').update(secret + ':chat-key:v1').digest();

  db.exec("CREATE TABLE IF NOT EXISTS chat_msgs (id INTEGER PRIMARY KEY AUTOINCREMENT, person TEXT NOT NULL, role TEXT NOT NULL, text TEXT NOT NULL, provider TEXT DEFAULT '', model TEXT DEFAULT '', created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')));");
  db.exec("CREATE INDEX IF NOT EXISTS idx_chat_person ON chat_msgs(person, id);");
  db.exec("CREATE TABLE IF NOT EXISTS chat_keys (id INTEGER PRIMARY KEY AUTOINCREMENT, provider TEXT NOT NULL UNIQUE, enc TEXT NOT NULL, iv TEXT NOT NULL, tag TEXT NOT NULL, hint TEXT DEFAULT '', created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')));");

  function sealKey(raw) {
    const iv = crypto.randomBytes(12);
    const c = crypto.createCipheriv('aes-256-gcm', keyOf(), iv);
    const enc = Buffer.concat([c.update(String(raw), 'utf8'), c.final()]);
    return { enc: enc.toString('base64'), iv: iv.toString('base64'), tag: c.getAuthTag().toString('base64') };
  }
  function openKey(row) {
    const d = crypto.createDecipheriv('aes-256-gcm', keyOf(), Buffer.from(row.iv, 'base64'));
    d.setAuthTag(Buffer.from(row.tag, 'base64'));
    return Buffer.concat([d.update(Buffer.from(row.enc, 'base64')), d.final()]).toString('utf8');
  }
  function keyRow(provider) {
    try { return db.prepare('SELECT * FROM chat_keys WHERE provider = ?').get(provider) || null; } catch (e) { return null; }
  }
  // 给同进程的其它模块用（cell 引擎的 aina 就靠它拿到 Key）：只取不解密回显，绝不进日志
  try { global.__dshChatKey = (provider) => { try { const r = keyRow(provider || 'deepseek'); return r ? openKey(r) : ''; } catch (e) { return ''; } }; } catch (e) {}

  function who(req) {
    let p = '';
    try { p = personOf(req) || ''; } catch (e) { p = ''; }
    return p;
  }
  function isOwner(req) { const p = who(req); return !!p && p === owner; }

  // ---- 密钥管理（只有 owner 能写；任何人都只能看「配没配」）----
  route('GET', '/api/chat/status', async (req, res) => {
    const p = who(req);
    const out = { ok: true, person: p, owner: p === owner, providers: [] };
    for (const name of Object.keys(PROVIDERS)) {
      const r = keyRow(name);
      out.providers.push({ provider: name, label: PROVIDERS[name].label, models: PROVIDERS[name].models, ready: !!r, hint: r ? r.hint : '', model: PROVIDERS[name].defaultModel });
    }
    json(res, 200, out);
  });
  route('POST', '/api/chat/key', async (req, res) => {
    if (!isOwner(req)) return json(res, 403, { ok: false, error: '只有主人能配模型 Key' });
    const b = (await readBody(req, 4000)) || {};
    const provider = String(b.provider || 'deepseek');
    const key = String(b.key || '').trim();
    if (!PROVIDERS[provider]) return json(res, 400, { ok: false, error: '未知服务商' });
    if (key.length < 8) return json(res, 400, { ok: false, error: 'Key 太短，没存' });
    // 2026-11-06 事故：用户把「身份令牌 ck_…」当 Key 贴了，页面回「已接通」，一说话就 401。
    // 教训：存之前先验，验不过就不许说成功。所有"看起来对"的确认都是骗人。
    if (key.indexOf('ck_') === 0) return json(res, 400, { ok: false, code: 'E-WRONG-KIND',
      error: '这是身份令牌（ck_…），不是 API Key。API Key 是 sk- 开头，在 platform.deepseek.com 的 API keys 页创建。' });
    if (key.indexOf('sk-') !== 0) return json(res, 400, { ok: false, code: 'E-NOT-SK',
      error: '这段不是 DeepSeek 的 API Key（应以 sk- 开头）。身份令牌 ck_… 请贴在地址栏 ?token= 后面，不要贴在这里。' });
    const probe = await upstream(provider, key, { model: PROVIDERS[provider].defaultModel, messages: [{ role: 'user', content: 'ping' }], max_tokens: 1, stream: false }, () => {});
    if (!probe.ok) {
      const why = String(probe.error || '');
      let hint = '这把 Key 连不上，所以没保存。';
      if (probe.status === 401) hint = 'DeepSeek 说这枚 Key 无效（401）。常见原因：Key 被删了、复制少了几位、或者这是别家平台的 Key。请到 platform.deepseek.com → API keys 重新创建一枚。';
      else if (probe.status === 402 || /balance|quota|insufficient/i.test(why)) hint = 'Key 有效但账户余额不足（402）。充值后再贴。';
      else if (/timeout|ENOTFOUND|ECONN|连不上上游/.test(why)) hint = '服务器连不上 DeepSeek（网络问题，不是 Key 的问题），稍后再试。';
      return json(res, probe.status === 401 ? 401 : 400, { ok: false, code: 'E-VERIFY', error: hint, upstream: why.slice(0, 200), status: probe.status || 0 });
    }
    const s = sealKey(key);
    const hint = key.slice(0, 3) + '…' + key.slice(-4);
    db.prepare('INSERT INTO chat_keys (provider, enc, iv, tag, hint) VALUES (?,?,?,?,?) ON CONFLICT(provider) DO UPDATE SET enc=excluded.enc, iv=excluded.iv, tag=excluded.tag, hint=excluded.hint').run(provider, s.enc, s.iv, s.tag, hint);
    json(res, 200, { ok: true, provider, hint, verified: true, note: '已实测连通并加密入库；接口不会回显原文' });
  });
  route('POST', '/api/chat/key/revoke', async (req, res) => {
    if (!isOwner(req)) return json(res, 403, { ok: false, error: '只有主人能删 Key' });
    const b = (await readBody(req, 4000)) || {};
    db.prepare('DELETE FROM chat_keys WHERE provider = ?').run(String(b.provider || 'deepseek'));
    json(res, 200, { ok: true });
  });

  // ---- 历史 ----
  function historyQs(person, limit) {
    const n = Math.max(1, Math.min(200, Number(limit) || 40));
    return db.prepare('SELECT id, role, text, model, created_at FROM chat_msgs WHERE person = ? ORDER BY id DESC LIMIT ?').all(person, n).reverse();
  }
  route('GET', '/api/chat/history', async (req, res) => {
    const p = who(req); if (!p) return json(res, 401, { ok: false, error: '未授权' });
    const u = new URL(req.url, 'http://x');
    json(res, 200, { ok: true, person: p, messages: historyQs(p, u.searchParams.get('limit')) });
  });
  route('POST', '/api/chat/clear', async (req, res) => {
    const p = who(req); if (!p) return json(res, 401, { ok: false, error: '未授权' });
    db.prepare('DELETE FROM chat_msgs WHERE person = ?').run(p);
    json(res, 200, { ok: true });
  });

  // ---- 会话（SSE 逐字回）----
  function upstream(provider, key, payload, onDelta) {
    return new Promise((resolve) => {
      const P = PROVIDERS[provider];
      let u;
      try { u = new URL(P.base.replace(/\/+$/, '') + '/chat/completions'); } catch (e) { return resolve({ ok: false, error: '上游地址非法' }); }
      const body = JSON.stringify(payload);
      const lib = u.protocol === 'http:' ? http : https;
      const q = lib.request({
        host: u.hostname, port: u.port || (u.protocol === 'http:' ? 80 : 443), path: u.pathname + (u.search || ''), method: 'POST',
        timeout: 120000,
        headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body), Authorization: 'Bearer ' + key, Accept: 'text/event-stream' },
      }, (s) => {
        let buf = '', text = '', usage = null, errBody = '';
        if (s.statusCode !== 200) {
          s.setEncoding('utf8');
          s.on('data', (c) => { errBody += c; if (errBody.length > 4000) s.destroy(); });
          s.on('end', () => {
            let msg = errBody.slice(0, 300);
            try { const j = JSON.parse(errBody); msg = (j.error && (j.error.message || j.error)) || j.message || msg; } catch (e) {}
            resolve({ ok: false, status: s.statusCode, error: String(msg).slice(0, 300) });
          });
          return;
        }
        s.setEncoding('utf8');
        s.on('data', (c) => {
          buf += c;
          let idx;
          while ((idx = buf.indexOf('\n')) > -1) {
            const line = buf.slice(0, idx).trim();
            buf = buf.slice(idx + 1);
            if (!line || line.indexOf('data:') !== 0) continue;
            const data = line.slice(5).trim();
            if (data === '[DONE]') continue;
            let j = null; try { j = JSON.parse(data); } catch (e) { continue; }
            if (j.usage) usage = j.usage;
            const ch = j.choices && j.choices[0];
            const d = ch && ch.delta ? ch.delta : null;
            if (d) {
              const piece = (d.content || '') + (d.reasoning_content || '');
              if (piece) { text += piece; try { onDelta(piece, d.reasoning_content ? 'reason' : 'text'); } catch (e) {} }
            }
          }
        });
        s.on('end', () => resolve({ ok: true, text, usage }));
        s.on('error', (e) => resolve({ ok: false, error: '上游中断：' + e.message }));
      });
      q.on('error', (e) => resolve({ ok: false, error: '连不上上游：' + e.code + ' ' + e.message }));
      q.on('timeout', () => { q.destroy(); resolve({ ok: false, error: '上游超时' }); });
      q.write(body);
      q.end();
    });
  }

  route('POST', '/api/chat/say', async (req, res) => {
    const p = who(req);
    if (!p) return json(res, 401, { ok: false, error: '未授权：先带令牌入网' });
    const b = (await readBody(req, 8000)) || {};
    const text = String(b.text || '').trim().slice(0, 4000);
    if (!text) return json(res, 400, { ok: false, error: '空消息' });
    const provider = String(b.provider || 'deepseek');
    if (!PROVIDERS[provider]) return json(res, 400, { ok: false, error: '未知服务商' });
    const row = keyRow(provider);
    if (!row) return json(res, 428, { ok: false, error: '还没接模型', code: 'E-NOKEY', hint: '主人在页面「接模型」里贴一次 Key 即可，之后所有设备共用' });
    let key = '';
    try { key = openKey(row); } catch (e) { return json(res, 500, { ok: false, error: 'Key 解不开（可能换了服务器密钥），请重贴一次' }); }

    const model = String(b.model || PROVIDERS[provider].defaultModel).slice(0, 60);
    const past = historyQs(p, 20).filter((m) => m.role === 'user' || m.role === 'assistant')
      .map((m) => ({ role: m.role, content: m.text }));
    const payload = { model, messages: past.concat([{ role: 'user', content: text }]), stream: true, max_tokens: 2048 };

    res.writeHead(200, { 'Content-Type': 'text/event-stream; charset=utf-8', 'Cache-Control': 'no-cache, no-transform', Connection: 'keep-alive', 'X-Accel-Buffering': 'no' });
    const send = (o) => { try { res.write('data: ' + JSON.stringify(o) + '\n\n'); } catch (e) {} };
    send({ kind: 'start', person: p, model, at: new Date().toISOString() });
    const hb = setInterval(() => { try { res.write(': hb\n\n'); } catch (e) {} }, 15000);
    if (hb.unref) hb.unref();

    const t0 = Date.now();
    const out = await upstream(provider, key, payload, (piece, kind) => send({ delta: piece, k: kind }));
    clearInterval(hb);
    const ms = Date.now() - t0;
    if (out.ok) {
      db.prepare('INSERT INTO chat_msgs (person, role, text, provider, model) VALUES (?,?,?,?,?)').run(p, 'user', text, provider, model);
      db.prepare('INSERT INTO chat_msgs (person, role, text, provider, model) VALUES (?,?,?,?,?)').run(p, 'assistant', out.text || '', provider, model);
      send({ kind: 'done', ms, chars: (out.text || '').length, usage: out.usage || null });
    } else {
      send({ kind: 'error', error: out.error, status: out.status || 0 });
    }
    try { res.end(); } catch (e) {}
  });

  return { ok: true, providers: Object.keys(PROVIDERS) };
}

module.exports = { create, PROVIDERS };
