'use strict';
// 细胞级碳硅联合劳动力引擎（第三谱系 CSchat-Cell）
// 严格实现 docs 契约 CONTRACT v0.1；不含任何 HTTP 细节，由 server.js 接线。
//
// 铁律（写死在这里，不接受调用方覆盖）：
//   1. 任务拆解权唯一归 nucleus；aina 只能复述意图
//   2. 审批超时 → 按拒绝处理（fail-closed），节点判 failed，不放行
//   3. progress 只许单调不减
//   4. 工具调用无 auth_token → 403
const crypto = require('node:crypto');
const https = require('node:https');

const CONTRACT_V = '0.1';
const BUDGET = Number(process.env.CELL_BUDGET || 200000);
const APPROVAL_TOKENS = Number(process.env.CELL_APPROVAL_TOKENS || 20000);
const APPROVAL_TTL = Number(process.env.CELL_APPROVAL_TTL || 1800);

function createCell(opts) {
  const DB = (opts && opts.db) || null;
  // 三层记忆 + 到人头的账本 + 成员密钥（VX 2026-11-03 拍板：记忆先行、只记账不转账、轻量签名）
  if (DB) {
    DB.exec(`CREATE TABLE IF NOT EXISTS cell_memory (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      layer TEXT NOT NULL,            -- session(会话) | project(项目) | profile(个人画像)
      k TEXT NOT NULL,
      v TEXT NOT NULL DEFAULT '',
      hits INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
      UNIQUE(layer, k)
    );`);
    DB.exec(`CREATE TABLE IF NOT EXISTS cell_ledger (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      person TEXT NOT NULL,           -- 结算到人头（自然人原子），中间层不可作为归属
      action TEXT NOT NULL,
      tokens INTEGER NOT NULL DEFAULT 0,
      cost REAL NOT NULL DEFAULT 0,
      task_id TEXT DEFAULT '',
      at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
    );`);
    DB.exec(`CREATE TABLE IF NOT EXISTS cell_member_keys (
      member_id TEXT PRIMARY KEY,
      pubkey TEXT NOT NULL,
      created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
    );`);
  }
  // ===== 持久化：重启不丢（3 人稳定体验的前提）=====
  if (DB) {
    DB.exec(`CREATE TABLE IF NOT EXISTS cell_state (
      k TEXT PRIMARY KEY,
      v TEXT NOT NULL DEFAULT ''
    );`);
    DB.exec(`CREATE TABLE IF NOT EXISTS cell_msgs (
      seq INTEGER PRIMARY KEY,
      env TEXT NOT NULL
    );`);
    DB.exec(`CREATE TABLE IF NOT EXISTS cell_tasks (
      task_id TEXT PRIMARY KEY,
      data TEXT NOT NULL,
      updated_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
    );`);
    DB.exec(`CREATE TABLE IF NOT EXISTS cell_packs (
      pack_id TEXT PRIMARY KEY,
      data TEXT NOT NULL
    );`);
  }
  const S = {
    // BYOK（自带 Key）——白皮书 25.2「BYOK 兜底」：
    // 平台没算力时让使用者带自己的 Key；**只放内存，绝不写盘、绝不进日志**。
    ai: { baseUrl: '', apiKey: '', model: 'deepseek-chat' },
    // 多模型成员：任何 OpenAI 兼容接口的大模型都可以作为群成员接进来（VX：大模型能进群不 → 能，且不止一个）
    aiMembers: new Map(),
    seq: 0, log: [], idemp: new Map(), tasks: new Map(), approvals: new Map(),
    energy: { used_tokens: 0, budget_tokens: BUDGET },
    subs: new Set(),
    // 群成员：AI 不止一种形态（白皮书第10单元：纯信息态/泛在感知态/物理执行态/混合态）
    // kind: llm(大模型) | agent(智能体) | tool(工具) | sensor(感知) | device(执行) | plugin(插件) | human(碳基)
    members: new Map(),
    packs: new Map(),   // JIT 权限包（白皮书 15.4）：意图触发、时间受限、范围受限
  };
  // 默认成员：一个细胞里同时有大脑、眼睛、手脚
  [['nucleus', 'llm', '中枢（大模型）', ['拆解', '调度']],
   ['aina', 'llm', 'Aina 伴生', ['复述意图', '状态播报', '陪聊']],
   ['crawler', 'agent', 'crawler 抓取', ['抓取', '整理']],
   ['writer', 'agent', 'writer 交付', ['写作', '成稿']],
   ['weather', 'tool', '天气工具', ['查天气']],
   ['greenhouse', 'sensor', '温室传感器', ['温度', '湿度']],
   ['arm', 'device', '机械臂（示例）', ['抓取物体']],
  ].forEach(function (m) {
    S.members.set(m[0], { member_id: m[0], kind: m[1], name: m[2], caps: m[3], status: 'idle', joined_at: Date.now() });
  });

  const nowIso = () => new Date().toISOString().replace('Z', '+08:00');
  const rid = (p, n) => p + '-' + crypto.randomBytes(6).toString('hex').slice(0, n || 12);

  function emit(type, payload, opt) {
    const o = opt || {};
    S.seq += 1;
    const env = {
      v: CONTRACT_V, seq: S.seq, msg_id: rid('m'), ts: nowIso(),
      from: o.from || 'nucleus', to: o.to || 'all', type,
      trace_id: o.trace_id || rid('t', 8), payload,
    };
    S.log.push(env);
    if (S.log.length > 5000) S.log.splice(0, 1000);
    // 落盘（失败不影响主流程：宁可少一条历史，也不让消息发不出去）
    if (DB) { try { DB.prepare('INSERT OR REPLACE INTO cell_msgs (seq, env) VALUES (?,?)').run(env.seq, JSON.stringify(env)); } catch (e) {} }
    for (const res of S.subs) { try { res.write('data: ' + JSON.stringify(env) + '\n\n'); } catch (e) {} }
    return env;
  }
  const fail = (code, message, ref, trace) => emit('system.error', { code, message, ref }, { from: 'system', trace_id: trace });

  function energy() {
    const pct = Math.round((S.energy.used_tokens / Math.max(1, S.energy.budget_tokens)) * 1000) / 10;
    return { used_tokens: S.energy.used_tokens, budget_tokens: S.energy.budget_tokens, pct,
             level: pct >= 90 ? 'exhausted' : (pct >= 70 ? 'low' : 'ok') };
  }

  function requestApproval(taskId, nodeId, reason, cost, trace) {
    const aid = rid('ap', 6);
    S.approvals.set(aid, { status: 'pending', task_id: taskId, node_id: nodeId, reason,
                           cost_estimate: cost, expires_at: Date.now() + APPROVAL_TTL * 1000 });
    const t = S.tasks.get(taskId);
    if (t && t.nodes[nodeId]) t.nodes[nodeId].status = 'blocked';   // 契约 §6：挂起不是 running
    emit('approval.request', { approval_id: aid, task_id: taskId, node_id: nodeId, reason,
                               cost_estimate: cost, expires_at: new Date(Date.now() + APPROVAL_TTL * 1000).toISOString() },
         { from: 'nucleus', to: 'vx', trace_id: trace });
    return aid;
  }

  function markFailed(ap, code, msg) {
    const t = S.tasks.get(ap.task_id);
    if (t && t.nodes[ap.node_id]) { t.nodes[ap.node_id].status = 'failed'; t.nodes[ap.node_id].error = code; }
    fail(code, msg);
  }

  // ===== 群成员（多形态 AI 可入群）=====
  function listMembers() { return Array.from(S.members.values()); }
  function registerMember(m) {
    const id = String((m && m.member_id) || '').trim() || ('mb-' + crypto.randomBytes(4).toString('hex'));
    const kind = String((m && m.kind) || '').trim();
    const KINDS = ['llm', 'agent', 'tool', 'sensor', 'device', 'plugin', 'human'];
    if (!KINDS.includes(kind)) return { ok: false, code: 'E4001', error: '不支持的成员形态：' + kind };
    const rec = { member_id: id, kind, name: String((m && m.name) || id), caps: Array.isArray(m && m.caps) ? m.caps : [], status: 'idle', joined_at: Date.now() };
    S.members.set(id, rec);
    saveMember(rec);
    emit('member.registered', rec, { from: 'system' });
    return { ok: true, member: rec };
  }
  function setMemberStatus(id, status) {
    const m = S.members.get(id);
    if (!m) return { ok: false, error: '成员不存在' };
    m.status = status;
    emit('agent.status', { agent_id: id, state: status, since: Date.now() }, { from: id });
    return { ok: true };
  }
  // 感知类成员主动上报（白皮书：传感器在群里以“系统消息/报警”形式出现）
  function sensorReport(id, metric, value, trace) {
    const m = S.members.get(id);
    if (!m) return { ok: false, error: '成员不存在' };
    emit('chat.agent', { text: '【' + m.name + '】' + metric + ' = ' + value, kind: 'sensor', metric, value },
         { from: id, trace_id: trace });
    return { ok: true };
  }

  // 模型配置：页面里 BYOK 优先；没填就用「接模型」存进库的那把（global.__dshChatKey 由 chat 模块提供）
  // 这样 aina 不用每条会话都重贴 Key，也不会因为「页面没填」就永远是个复读机。
  function aiCfg() {
    if (S.ai && S.ai.baseUrl && S.ai.apiKey) return { baseUrl: S.ai.baseUrl, apiKey: S.ai.apiKey, model: S.ai.model, source: 'byok' };
    let k = '';
    try { if (typeof global.__dshChatKey === 'function') k = global.__dshChatKey('deepseek') || ''; } catch (e) { k = ''; }
    if (k) return { baseUrl: 'https://api.deepseek.com', apiKey: k, model: (S.ai && S.ai.model) || 'deepseek-chat', source: 'stored' };
    return null;
  }

  // —— 通用模型调用（BYOK，OpenAI 兼容）——
  function callModel(messages, maxTokens, cb) {
    const cfg = aiCfg();
    if (!cfg) return cb(null);
    const body = JSON.stringify({ model: cfg.model, temperature: 0.6, messages, max_tokens: maxTokens || 400 });
    let url;
    try { url = new URL(cfg.baseUrl.replace(/\/$/, '') + '/chat/completions'); } catch (e) { return cb(null); }
    const req = https.request({ hostname: url.hostname, path: url.pathname, method: 'POST', timeout: 45000,
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body), Authorization: 'Bearer ' + cfg.apiKey } }, (res) => {
      let d = ''; res.setEncoding('utf8');
      res.on('data', (c) => { d += c; });
      res.on('end', () => {
        try {
          const j = JSON.parse(d);
          const txt = (j.choices && j.choices[0] && j.choices[0].message && j.choices[0].message.content) || '';
          cb(txt.trim() || null);
        } catch (e) { cb(null); }
      });
    });
    req.on('error', () => cb(null));
    req.on('timeout', () => { req.destroy(); cb(null); });
    req.end(body);
  }

  // 大模型作为「群成员」在群里说话（不只是干活）
  function speakAsAI(text, trace) {
    return new Promise((resolve) => {
      callModel([
        { role: 'system', content: '你是群里的伴生智能体 Aina。用中文、简短、直接地回答群主，不超过 120 字。不要客套。' },
        { role: 'user', content: text },
      ], 400, (reply) => {
        const out = reply || ('我听到了：「' + String(text).slice(0, 40) + '」。没接模型时我只能复述，接上模型后我能真正回答。');
        emit('chat.agent', { text: out, kind: 'llm', member_id: 'aina' }, { from: 'aina', trace_id: trace });
        resolve(out);
      });
    });
  }

  // 已注册的硅基成员用 stored key 在群里说话（VX 2026-11-07：智能体常驻群聊、持续响应，不再说一句就跑）
  function agentSpeak(memberId, userText) {
    return new Promise((resolve) => {
      const mid = String(memberId || '').trim();
      if (!mid || !S.members.has(mid)) return resolve({ ok: false, code: 'E2004', error: '发言成员未注册', http: 403 });
      const m = S.members.get(mid);
      const cfg = aiCfg();
      if (!cfg) return resolve({ ok: false, code: 'E4007', error: '未配置模型', http: 503 });
      const caps = (m.caps && m.caps.length) ? m.caps.join('、') : '智能体';
      const sys = '你是细胞群里的硅基智能体成员「' + (m.name || mid) + '」（member_id=' + mid + '，专长：' + caps + '）。' +
        '群里有碳基人类群主 vx、伴生智能体 Aina，还有你。用中文、简短、直接地回应群主刚说的话，不超过 100 字。' +
        '体现你的专长视角，别客套，别复读 Aina 的话，别自称 Aina。';
      setMemberStatus(mid, 'busy');
      callModel([
        { role: 'system', content: sys },
        { role: 'user', content: String(userText || '') },
      ], 300, (reply) => {
        const out = reply || '（我这边模型暂时没回）';
        emit('chat.agent', { text: out, kind: 'agent', member_id: mid }, { from: mid });
        setMemberStatus(mid, 'idle');
        resolve({ ok: true, text: out });
      });
    });
  }

  // —— BYOK 设置（页面里填一次即可，不上磁盘）——
  function setAi(cfg) {
    const c = cfg || {};
    S.ai.baseUrl = String(c.baseUrl || '').trim();
    S.ai.apiKey = String(c.apiKey || '').trim();
    S.ai.model = String(c.model || 'deepseek-chat').trim();
    return { ok: true, configured: !!(S.ai.baseUrl && S.ai.apiKey), model: S.ai.model };
  }
  function aiStatus() {
    const cfg = aiCfg();
    return { restored: RESTORED, configured: !!cfg, model: cfg ? cfg.model : S.ai.model, source: cfg ? cfg.source : 'none',
             baseUrlHost: cfg ? cfg.baseUrl.replace(/^https?:\/\//, '').split('/')[0] : '',
             keyMasked: cfg ? ('****' + cfg.apiKey.slice(-4)) : '' };
  }

  // 调模型把一句话拆成任务树（OpenAI 兼容）。失败必须回 E4007 并退回规则拆解，不许静默。
  function planByModel(text) {
    return new Promise((resolve) => {
      const cfg = aiCfg();
      if (!cfg) return resolve(null);
      const sys = '你是任务拆解中枢。把用户的一句话拆成 2-4 个子任务，只输出 JSON，不要任何解释。格式：{"title":"主任务名","nodes":[{"title":"子任务","agent":"crawler|writer|analyst"}]}';
      const body = JSON.stringify({ model: cfg.model, temperature: 0.3,
        messages: [{ role: 'system', content: sys }, { role: 'user', content: text }],
        max_tokens: 500 });
      let url;
      try { url = new URL(cfg.baseUrl.replace(/\/$/, '') + '/chat/completions'); } catch (e) { return resolve(null); }
      const req = https.request({ hostname: url.hostname, path: url.pathname, method: 'POST', timeout: 45000,
        headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body),
                   Authorization: 'Bearer ' + cfg.apiKey } }, (res) => {
        let d = ''; res.setEncoding('utf8');
        res.on('data', (c) => { d += c; });
        res.on('end', () => {
          try {
            const j = JSON.parse(d);
            const txt = (j.choices && j.choices[0] && j.choices[0].message && j.choices[0].message.content) || '';
            const m = txt.match(/\{[\s\S]*\}/);
            if (!m) return resolve(null);
            const plan = JSON.parse(m[0]);
            if (!plan || !Array.isArray(plan.nodes) || plan.nodes.length === 0) return resolve(null);
            resolve(plan);
          } catch (e) { resolve(null); }
        });
      });
      req.on('error', () => resolve(null));
      req.on('timeout', () => { req.destroy(); resolve(null); });
      req.end(body);
    });
  }

  function buildNodes(text, plan) {
    const root = 'n1';
    if (!plan) {
      // 规则拆解（无 Key 或模型失败时的兜底，明确标注 source=mock）
      return {
        source: 'mock',
        nodes: {
          n1: { node_id: 'n1', parent_id: null, title: text.trim().slice(0, 40), owner: 'nucleus', status: 'running', progress: 10, depends_on: [] },
          n2: { node_id: 'n2', parent_id: root, title: '抓取与整理数据', owner: 'agent:crawler', status: 'done', progress: 100, depends_on: [], output_ref: 'out-1' },
          n3: { node_id: 'n3', parent_id: root, title: '生成交付物', owner: 'agent:writer', status: 'pending', progress: 0, depends_on: ['n2'] },
        },
      };
    }
    const nodes = { [root]: { node_id: root, parent_id: null, title: String(plan.title || text).slice(0, 40), owner: 'nucleus', status: 'running', progress: 10, depends_on: [] } };
    plan.nodes.slice(0, 4).forEach((n, i) => {
      const id = 'n' + (i + 2);
      const agent = ['crawler', 'writer', 'analyst'].includes(String(n.agent)) ? String(n.agent) : 'writer';
      nodes[id] = { node_id: id, parent_id: root, title: String(n.title || '子任务').slice(0, 40), owner: 'agent:' + agent,
                    status: i === 0 ? 'running' : 'pending', progress: i === 0 ? 20 : 0, depends_on: i === 0 ? [] : ['n' + (i + 1)] };
    });
    return { source: 'model', nodes };
  }

  async function planTask(text, trace) {
    if (!text || text.trim().length < 2) { fail('E4007', '中枢拆解失败：指令太短', null, trace); return null; }
    let plan = null;
    try { plan = await planByModel(text); } catch (e) { plan = null; }
    if (!plan && aiCfg()) fail('E4007', '中枢拆解失败：模型未返回合法任务树，已退回规则拆解', null, trace);
    const built = buildNodes(text, plan);
    const taskId = rid('tk', 6);
    const nodes = built.nodes;
    S.tasks.set(taskId, { title: text.trim().slice(0, 40), root_node_id: 'n1', nodes, trace_id: trace });
    saveTask(taskId);
    emit('task.plan', { task_id: taskId, root_node_id: 'n1', nodes: Object.values(nodes), source: built.source }, { trace_id: trace });
    emit('energy.update', energy(), { from: 'system', trace_id: trace });
    // 任务拆解后按「节点需要什么」发最小权限包（不是预装权限）
    issuePack({ task_id: taskId, granted_to: 'agent:crawler', allowed_actions: ['weather'], data_scope: 'public',
                max_cost: 1000, expires_at: Date.now() + 10 * 60 * 1000 });
    const cost = Math.max(500, Math.round(text.length * 180));
    if (cost > APPROVAL_TOKENS) requestApproval(taskId, 'n3', '预计消耗 ' + cost + ' tokens，超过单节点阈值 ' + APPROVAL_TOKENS, cost, trace);
    // 演示/单机模式：没有外部执行端推 task.node.update 时，服务端自己把节点跑完出结果。
    autoKick(taskId, 500);
    return taskId;
  }

  // ===== 服务端自动执行器（VX 2026-11-07：3 台机器执行端用不了，节点卡死，演示必须自己跑）=====
  // env CELL_AUTO_RUN=0 关闭，回到「等外部 POST /api/cell/msg 推进」的契约原状。
  // 检测到外部真正推进（10s 内有 task.node.update）就自动让位，不抢活。
  const AUTO_RUN = String(process.env.CELL_AUTO_RUN || '1') !== '0';
  const autoRunning = new Set();
  let externalTouch = 0;
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  function autoKick(taskId, delay) {
    if (!AUTO_RUN || autoRunning.has(taskId)) return;
    const t = setTimeout(() => { try { autoRun(taskId); } catch (e) {} }, delay || 400);
    if (t.unref) t.unref();
  }

  function gatherOutputs(t) {
    return Object.values(t.nodes).filter(n => n.output).map(n => '【' + (n.title || n.node_id) + '】\n' + n.output).join('\n\n');
  }

  function httpGet(urlStr, timeoutMs) {
    return new Promise((resolve) => {
      let u; try { u = new URL(urlStr); } catch (e) { return resolve(''); }
      const req = https.request({ hostname: u.hostname, path: u.pathname + u.search, method: 'GET', timeout: timeoutMs || 8000,
        headers: { 'User-Agent': 'Mozilla/5.0 CSchat-Cell' } }, (res) => {
        let d = ''; res.setEncoding('utf8');
        res.on('data', (c) => { d += c; if (d.length > 300000) { req.destroy(); } });
        res.on('end', () => resolve(d));
      });
      req.on('error', () => resolve(''));
      req.on('timeout', () => { req.destroy(); resolve(''); });
      req.end();
    });
  }
  function stripHtml(html) {
    return String(html || '').replace(/<script[\s\S]*?<\/script>/gi, ' ').replace(/<style[\s\S]*?<\/style>/gi, ' ')
      .replace(/<[^>]+>/g, ' ').replace(/&nbsp;/g, ' ').replace(/\s+/g, ' ').trim();
  }

  async function runCrawler(t, n) {
    const text = (t.title || '') + ' ' + (n.title || '');
    const m = text.match(/https?:\/\/[^\s，。、）)\]】]+/i);
    if (m) {
      const raw = await httpGet(m[0], 8000);
      const txt = stripHtml(raw).slice(0, 8000);
      if (txt.length > 80) {
        const sum = await askModel([
          { role: 'system', content: '你是 crawler 抓取整理员。把抓到的网页内容整理成 3-5 条中文要点，简洁，不要客套。' },
          { role: 'user', content: '任务：' + (n.title || t.title) + '\n\n网页内容：\n' + txt },
        ], 700);
        return '已抓取 ' + m[0] + '\n' + (sum || txt.slice(0, 700));
      }
    }
    const sum = await askModel([
      { role: 'system', content: '你是 crawler 抓取整理员。根据任务主题，整理出 3-5 条关键信息中文要点，像刚从公开资料抓到的。直接给要点，不要说「模拟」「假设」。' },
      { role: 'user', content: '任务：' + (n.title || t.title) },
    ], 600);
    return sum || '（未抓到可用内容）';
  }
  async function runAnalyst(t, n) {
    const ctx = gatherOutputs(t);
    const out = await askModel([
      { role: 'system', content: '你是 analyst 分析师。基于已有材料做结构化分析，输出中文要点，条理清晰，不要客套。' },
      { role: 'user', content: '主任务：' + (t.title || '') + '\n当前节点：' + (n.title || '') + '\n\n已有材料：\n' + (ctx || '（暂无材料）') },
    ], 900);
    return out || '（分析完成）';
  }
  async function runWriter(t, n) {
    const ctx = gatherOutputs(t);
    const out = await askModel([
      { role: 'system', content: '你是 writer 交付员。基于前面节点的材料，产出可直接交付的中文成果，结构清晰、可直接使用，不要客套。控制在 600 字以内。' },
      { role: 'user', content: '主任务：' + (t.title || '') + '\n交付物：' + (n.title || '') + '\n\n已有材料：\n' + (ctx || '（请基于主任务直接产出）') },
    ], 1200);
    return out || '（交付完成）';
  }
  async function runGeneric(t, n) {
    const ctx = gatherOutputs(t);
    const out = await askModel([
      { role: 'system', content: '你是执行节点。完成本子任务，输出中文结果，简洁。' },
      { role: 'user', content: '主任务：' + (t.title || '') + '\n子任务：' + (n.title || '') + '\n\n已有材料：\n' + (ctx || '（无）') },
    ], 800);
    return out || '（完成）';
  }

  function nextRunnable(t) {
    for (const n of Object.values(t.nodes)) {
      if (n.status === 'done' || n.status === 'failed' || n.status === 'skipped') continue;
      if (n.status === 'blocked') continue;                         // 等审批
      if (String(n.owner) === 'nucleus') continue;                  // 根节点最后收尾
      const deps = n.depends_on || [];
      if (deps.every(d => t.nodes[d] && t.nodes[d].status === 'done')) return n;
    }
    return null;
  }

  async function autoRun(taskId) {
    if (autoRunning.has(taskId)) return;
    const t = S.tasks.get(taskId);
    if (!t) return;
    if (externalTouch && Date.now() - externalTouch < 10000) return;   // 真执行端在动，让位
    autoRunning.add(taskId);
    try {
      let guard = 0;
      while (guard++ < 12) {
        const t2 = S.tasks.get(taskId);
        if (!t2) break;
        const n = nextRunnable(t2);
        if (!n) break;                                                // 跑完或都卡在审批
        const owner = String(n.owner || '').replace(/^agent:/, '');
        if (n.status !== 'running') nodeUpdate(taskId, n.node_id, 'running', Math.max(n.progress || 0, 25));
        await sleep(350);
        let out = '';
        if (owner === 'crawler') out = await runCrawler(t2, n);
        else if (owner === 'analyst') out = await runAnalyst(t2, n);
        else if (owner === 'writer') out = await runWriter(t2, n);
        else out = await runGeneric(t2, n);
        if (out) n.output = String(out).slice(0, 4000);
        nodeUpdate(taskId, n.node_id, 'done', 100);
        if (out) {
          charge('vx', 'auto.' + owner, 1500, 0.0001, taskId);
          emit('chat.agent', { text: '【' + (n.title || owner) + '】' + String(out).slice(0, 1500),
            kind: owner === 'writer' ? 'llm' : 'agent', member_id: owner }, { from: owner, trace_id: t2.trace_id });
          emit('energy.update', energy(), { from: 'system', trace_id: t2.trace_id });
        }
        await sleep(250);
      }
    } catch (e) { /* 自动执行出错不崩主流程 */ }
    finally {
      autoRunning.delete(taskId);
      const t3 = S.tasks.get(taskId);
      if (t3) {
        const rest = Object.values(t3.nodes).filter(n => String(n.owner) !== 'nucleus');
        const restDone = rest.length > 0 && rest.every(n => n.status === 'done' || n.status === 'failed' || n.status === 'skipped');
        if (restDone && t3.nodes['n1'] && t3.nodes['n1'].status !== 'done') nodeUpdate(taskId, 'n1', 'done', 100);
      }
    }
  }

  function nodeUpdate(taskId, nodeId, status, progress, note, trace) {
    const t = S.tasks.get(taskId);
    if (!t) { fail('E4002', '任务不存在', null, trace); return { ok: false, code: 'E4002', http: 404 }; }
    const n = t.nodes[nodeId];
    if (!n) { fail('E4002', '节点不存在', null, trace); return { ok: false, code: 'E4002', http: 404 }; }
    if (progress != null && progress < (n.progress || 0)) {
      fail('E4003', 'progress 不允许回退（' + (n.progress || 0) + ' → ' + progress + '）', null, trace);
      return { ok: false, code: 'E4003', http: 409 };
    }
    if (status) {
      if (!['pending', 'running', 'done', 'failed', 'blocked', 'skipped'].includes(status)) {
        fail('E4003', '非法状态：' + status, null, trace);
        return { ok: false, code: 'E4003', http: 409 };
      }
      n.status = status;
    }
    if (progress != null) n.progress = progress;
    if (note) n.note = note;
    saveTask(taskId);
    emit('task.node.update', { task_id: taskId, node_id: nodeId, status: n.status, progress: n.progress || 0 }, { trace_id: trace });
    return { ok: true, node: n, http: 200 };
  }

  function decideApproval(aid, approved) {
    const ap = S.approvals.get(aid);
    if (!ap) return { ok: false, code: 'E4002', error: '审批不存在', http: 404 };
    if (ap.status !== 'pending') return { ok: true, already: true, status: ap.status, http: 200 };
    if (Date.now() > ap.expires_at) {
      ap.status = 'expired';
      markFailed(ap, 'E4004', '审批超时，按拒绝处理');
      return { ok: true, status: 'expired', http: 200 };
    }
    ap.status = approved ? 'approved' : 'denied';
    const t = S.tasks.get(ap.task_id);
    if (t && t.nodes[ap.node_id]) {
      if (approved) { t.nodes[ap.node_id].status = 'running'; saveTask(ap.task_id); autoKick(ap.task_id, 300); }
      else markFailed(ap, 'E4004', '碳基主理人拒绝');
    }
    emit('approval.decision', { approval_id: aid, approved: !!approved, by: 'vx', at: nowIso() }, { from: 'vx', to: 'nucleus' });
    return { ok: true, status: ap.status, http: 200 };
  }

  // ===== JIT 权限包（白皮书 15.4 + 委派链衰减 NIST 准则）=====
  // 铁律：权限不是预装的，是任务触发时按需发的；委派只能衰减不能放大。
  function issuePack(o) {
    const pack = {
      pack_id: rid('pk', 6), task_id: o.task_id, granted_to: o.granted_to,
      allowed_actions: (o.allowed_actions || []).slice(), data_scope: o.data_scope || '',
      max_cost: Number(o.max_cost || 0), used_cost: 0,
      expires_at: o.expires_at || (Date.now() + 30 * 60 * 1000),
      delegated_from: o.delegated_from || null, chain: (o.chain || []).slice(),
    };
    if (pack.delegated_from) pack.chain = pack.chain.concat([pack.delegated_from]);
    S.packs.set(pack.pack_id, pack);
    savePack(pack);
    emit('auth.pack.issued', { pack_id: pack.pack_id, task_id: pack.task_id, granted_to: pack.granted_to,
                               allowed_actions: pack.allowed_actions, max_cost: pack.max_cost,
                               expires_at: new Date(pack.expires_at).toISOString(),
                               delegated_from: pack.delegated_from, chain: pack.chain }, { from: 'nucleus' });
    return pack;
  }
  function getPack(id) { return S.packs.get(id) || null; }
  function packStatus(p) {
    if (!p) return 'missing';
    if (Date.now() > p.expires_at) return 'expired';
    return 'active';
  }
  // 委派：子权限必须是父权限子集，时间与预算都不许放大
  function delegatePack(parentId, o) {
    const parent = S.packs.get(parentId);
    if (!parent) return { ok: false, code: 'E4001', error: '父权限包不存在', http: 404 };
    if (packStatus(parent) !== 'active') return { ok: false, code: 'E4009', error: '父权限包已过期', http: 403 };
    const want = Array.isArray(o && o.allowed_actions) ? o.allowed_actions : [];
    const extra = want.filter(a => parent.allowed_actions.indexOf(a) === -1);
    if (extra.length) {
      fail('E4008', '委派越权：请求了父权限没有的动作 ' + extra.join(','), 'pack:' + parentId);
      return { ok: false, code: 'E4008', error: '委派越权', extra, http: 403 };
    }
    if (Number((o && o.max_cost) || 0) > parent.max_cost) {
      fail('E4008', '委派越权：预算不得放大（父 ' + parent.max_cost + ' < 子 ' + o.max_cost + '）', 'pack:' + parentId);
      return { ok: false, code: 'E4008', error: '委派越权（预算放大）', http: 403 };
    }
    if (o && o.expires_at && o.expires_at > parent.expires_at) {
      fail('E4008', '委派越权：有效期不得超过父权限', 'pack:' + parentId);
      return { ok: false, code: 'E4008', error: '委派越权（时间放大）', http: 403 };
    }
    const child = issuePack({
      task_id: parent.task_id, granted_to: (o && o.granted_to) || 'agent:child', allowed_actions: want,
      data_scope: parent.data_scope, max_cost: Number((o && o.max_cost) || 0),
      expires_at: (o && o.expires_at) || parent.expires_at, delegated_from: parentId, chain: parent.chain,
    });
    return { ok: true, pack: child, http: 200 };
  }

  function toolCall(name, args, token, packId, cost) {
    // 白皮书 15.4：调用工具必须持有 JIT 权限包；没有包 = 无权限
    const pack = packId ? S.packs.get(packId) : null;
    if (!pack) {
      fail('E4001', '工具调用缺少权限包（pack_id）', 'tool:' + name);
      return { ok: false, code: 'E4001', http: 403 };
    }
    if (packStatus(pack) === 'expired') {
      fail('E4009', '权限包已过期', 'pack:' + packId);
      return { ok: false, code: 'E4009', http: 403 };
    }
    if (pack.allowed_actions.indexOf(name) === -1) {
      fail('E4001', '权限包不含该动作：' + name, 'pack:' + packId);
      return { ok: false, code: 'E4001', http: 403 };
    }
    const c = Number(cost || 0);
    if (pack.used_cost + c > pack.max_cost) {
      fail('E4010', '超出权限包预算（已用 ' + pack.used_cost + '，本次 ' + c + '，上限 ' + pack.max_cost + '）', 'pack:' + packId);
      return { ok: false, code: 'E4010', http: 403 };
    }
    pack.used_cost += c;
    if (!token) { fail('E4001', '工具调用缺少 auth_token', 'tool:' + name); return { ok: false, code: 'E4001', http: 403 }; }

    // —— AI 可用动作（只读 + 写建议，不碰资金与外部副作用）——
    if (name === 'archive.search') {
      if (!DB) return { ok: false, code: 'E4002', http: 500 };
      const q = String((args && args.q) || '').slice(0, 50);
      const kw = '%' + q + '%';
      const rows = DB.prepare("SELECT id, title, summary, frequency_id FROM archive_archives WHERE title LIKE ? OR summary LIKE ? ORDER BY distill_score DESC LIMIT 5").all(kw, kw);
      return { ok: true, tool: name, q, hits: rows.length, rows, http: 200 };
    }
    if (name === 'archive.suggest') {
      const text = String((args && args.text) || '').slice(0, 500);
      if (!text) return { ok: false, code: 'E4002', http: 400 };
      emit('chat.agent', { text: '【AI 建议】' + text, kind: 'llm', member_id: pack.granted_to || 'aina-web' }, { from: pack.granted_to || 'aina-web' });
      if (DB) DB.prepare("INSERT INTO cell_memory (layer, k, v) VALUES ('project', 'ai_suggestion', ?) ON CONFLICT(layer, k) DO UPDATE SET v = excluded.v").run(text);
      return { ok: true, tool: name, accepted: true, http: 200 };
    }
    // —— 明确禁止：资金与物理动作，AI 永远拿不到 ——
    if (name === 'fund.transfer' || name === 'device.actuate') {
      fail('E4001', '该动作需要人类审批，AI 权限包不可包含：' + name, 'tool:' + name);
      return { ok: false, code: 'E4001', http: 403 };
    }
    if (name === 'weather') return { ok: true, tool: 'weather', city: (args && args.city) || '上海', result: '小雨', mock: true, http: 200 };
    if (name === 'notify') { emit('chat.agent', { text: '[通知] ' + String((args && args.text) || '').slice(0, 60) }, { from: 'tool:notify' }); return { ok: true, tool: 'notify', sent: true, mock: true, http: 200 }; }
    fail('E4002', '未知工具：' + name);
    return { ok: false, code: 'E4002', http: 404 };
  }

  // 一句话到底是「闲聊」还是「活儿」：闲聊不该生成任务树，更不该弹「待拍板」。
  // 2026-11-05 实测：用户说「asus智能体在不，你开发的」被拆成 3 节点任务树 + 待拍板，纯噪音。
  function isChatOnly(t) {
    const s = String(t).trim();
    if (!s) return true;
    if (s.length > 60) return false;
    if (/[?？]$/.test(s)) return true;
    if (/^(在不|在吗|在么|你好|嗨|hi|hello|收到|好的|谢谢|辛苦|厉害|早|晚安)/i.test(s)) return true;
    if (/(在不在|在不|在吗|你是谁|你叫什么|介绍一下|介绍下|能听见|能听到|听得到|看一下状态|状态如何|进展如何|人呢)/.test(s)) return true;
    const act = /做|写|出|生成|分析|整理|拉取|去找|找一|查一|报告|方案|计划|报价|拆分|竞品|文档|PPT|汇报|梳理|总结|对比|改成|修改|修一下|上线|部署|建个|搭个/;
    if (!act.test(s) && s.length <= 24) return true;
    return false;
  }

  async function say(text, from) {
    const t = String(text || '').trim();
    if (!t) return { ok: false, error: 'empty', http: 400 };
    emit('chat.user', { text: t }, { from: from || 'vx' });
    // 寒暄/问状态：只回一句人话，不下发任务树、不记账、不弹拍板。
    // 没接模型时也不再复述用户原话（那是噪音），直接说明能做什么。
    if (t.length < 2 || isChatOnly(t)) {
      remember('session', 'last_intent', t.slice(0, 200));
      setMemberStatus('aina', 'thinking');
      const hasModel = !!aiCfg();
      if (hasModel) await speakAsAI(t, null);
      else emit('chat.agent', {
        text: '在。我是群里那位要接模型的——现在还没接，所以只能回这一句。接上之后就能真回答：页面右上角「接模型」贴一次 Key，或者让 asus 走本地 1.5B 代答。',
        kind: 'hint', member_id: 'aina' }, { from: 'aina' });
      setMemberStatus('aina', 'idle');
      return { ok: true, chat: true, http: 200 };
    }
    // ① 碳基协议：先把「情绪 + 意图强度」解出来（只影响 Aina 的建议口吻，不动任务树）
    const carbon = parseCarbon(t);
    emit('carbon.parsed', carbon, { from: 'aina', to: 'vx' });
    // ② 会话记忆 + 画像记忆（养成的地基：第二次来要认识这个人）
    remember('session', 'last_intent', t.slice(0, 200));
    remember('profile', 'mood:' + carbon.mood, String(Date.now()));
    if (carbon.mood !== 'neutral') remember('profile', 'recent_mood', carbon.mood);
    // ③ Aina 只复述，不拆解（契约铁律），但复述要带上情绪判断
    const tone = carbon.suggestion === 'conservative' ? '你现在像是累了，我先给你最稳的一版'
      : (carbon.suggestion === 'fastest' ? '你着急，我走最快路径' : '你是要我：');
    emit('task.proposed', { precheck_id: rid('pc', 6), restatement: tone + t.slice(0, 60),
                            intent: t.slice(0, 60), carbon }, { from: 'aina', to: 'vx' });
    // ① 大模型成员先在群里回一句（人话）
    setMemberStatus('aina', 'thinking');
    await speakAsAI(t, null);
    setMemberStatus('aina', 'idle');
    // ② 中枢再拆解成任务树
    setMemberStatus('nucleus', 'thinking');
    const taskId = await planTask(t, null);
    setMemberStatus('nucleus', 'idle');
    // ④ 记账到人头（只记账不转账）：中枢拆解 + 一次模型调用
    charge('vx', 'nucleus.plan', Math.round(t.length * 1.5), 0.0001, taskId);
    remember('project', 'last_task', taskId);
    return { ok: true, task_id: taskId, http: 200 };
  }

  async function msg(env) {
    if (!env || env.v !== CONTRACT_V) { fail('E4006', '契约版本不符：期望 ' + CONTRACT_V + '，收到 ' + (env && env.v)); return { ok: false, code: 'E4006', http: 400 }; }
    if (env.msg_id && S.idemp.has(env.msg_id)) return Object.assign({ http: 200 }, S.idemp.get(env.msg_id));
    let out;
    const p = env.payload || {};
    if (env.type === 'chat.user') out = await say(p.text, env.from);
    else if (env.type === 'chat.agent') {
      // 硅基成员直接在群里发话（VX 2026-11-07：多智能体接入聊天，演示核心）。from 必须是已注册成员。
      const fid = String(env.from || '');
      if (!fid || !S.members.has(fid)) { fail('E2004', '发言成员未注册：' + fid); return { ok: false, code: 'E2004', http: 403 }; }
      const payload = { text: String(p.text || ''), kind: String(p.kind || 'agent'), member_id: fid };
      if (p.note) payload.note = p.note;
      emit('chat.agent', payload, { from: fid, trace_id: env.trace_id });
      out = { ok: true, http: 200 };
    }
    else if (env.type === 'task.node.update') { externalTouch = Date.now(); const r = nodeUpdate(p.task_id, p.node_id, p.status, p.progress, p.note, env.trace_id); out = { ok: r.ok, code: r.code, http: r.http }; }
    else if (env.type === 'approval.decision') { const r = decideApproval(p.approval_id, !!p.approved); out = { ok: r.ok, status: r.status, http: r.http }; }
    else if (env.type === 'tool.call') { const r = toolCall(p.name, p.args, p.auth_token, p.pack_id, p.cost); out = { ok: r.ok, code: r.code, http: r.http, result: r }; }
    else if (env.type === 'auth.delegate') { const r = delegatePack(p.pack_id, p); out = { ok: r.ok, code: r.code, http: r.http, pack: r.pack }; }
    else out = { ok: true, ignored: env.type, http: 200 };   // 未知类型：忽略不崩（契约 §3）
    if (env.msg_id) S.idemp.set(env.msg_id, out);
    return out;
  }

  function pause() {
    for (const t of S.tasks.values()) for (const n of Object.values(t.nodes)) if (n.status === 'running') n.status = 'blocked';
    emit('energy.update', energy(), { from: 'system' });
    return { ok: true, paused: true };
  }

  function state() {
    const tasks = {};
    for (const [id, t] of S.tasks) tasks[id] = { title: t.title, nodes: Object.values(t.nodes) };
    const approvals = {};
    for (const [id, a] of S.approvals) approvals[id] = a;
    return { energy: energy(), seq: S.seq, tasks, approvals };
  }

  function snapshot(q) {
    const trace = (q && q.trace_id) || '';
    const upto = Number((q && q.upto_seq) || 999999999);
    return { readonly: true, messages: S.log.filter(m => m.seq <= upto && (!trace || m.trace_id === trace)) };
  }

  function subscribe(req, res) {
    const since = Number((req && req.query && req.query.since_seq) || 0);
    res.writeHead(200, { 'Content-Type': 'text/event-stream; charset=utf-8', 'Cache-Control': 'no-cache', 'Connection': 'keep-alive', 'X-Accel-Buffering': 'no' });
    for (const m of S.log) if (m.seq > since) res.write('data: ' + JSON.stringify(m) + '\n\n');
    S.subs.add(res);
    const ka = setInterval(() => { try { res.write(': ka\n\n'); } catch (e) {} }, 25000);
    if (ka.unref) ka.unref();
    const drop = () => { clearInterval(ka); S.subs.delete(res); };
    req.on('close', drop); req.on('error', drop);
  }

  // 后台扫过期审批
  const sweeper = setInterval(() => {
    const now = Date.now();
    for (const ap of S.approvals.values()) {
      if (ap.status === 'pending' && now > ap.expires_at) { ap.status = 'expired'; markFailed(ap, 'E4004', '审批超时，按拒绝处理'); }
    }
  }, 1000);
  if (sweeper.unref) sweeper.unref();

  // ===== 多模型成员 =====
  function addAiMember(o) {
    const id = String((o && o.member_id) || '').trim() || ('ai-' + crypto.randomBytes(3).toString('hex'));
    const baseUrl = String((o && o.baseUrl) || '').trim();
    const apiKey = String((o && o.apiKey) || '').trim();
    const model = String((o && o.model) || 'deepseek-chat').trim();
    if (!baseUrl || !apiKey) return { ok: false, error: '需要 baseUrl 与 apiKey' };
    S.aiMembers.set(id, { member_id: id, name: String((o && o.name) || id), baseUrl, apiKey, model, calls: 0 });
    // 同时注册成群成员：形态 llm
    if (!S.members.has(id)) {
      S.members.set(id, { member_id: id, kind: 'llm', name: String((o && o.name) || id),
        caps: ['对话', '建议'], status: 'idle', joined_at: Date.now() });
      emit('member.registered', S.members.get(id), { from: 'system' });
    }
    return { ok: true, member_id: id, name: String((o && o.name) || id), model, baseUrlHost: baseUrl.replace(/^https?:\/\//, '').split('/')[0] };
  }
  function listAiMembers() {
    return Array.from(S.aiMembers.values()).map(m => ({ member_id: m.member_id, name: m.name, model: m.model,
      baseUrlHost: m.baseUrl.replace(/^https?:\/\//, '').split('/')[0], keyMasked: '****' + m.apiKey.slice(-4), calls: m.calls }));
  }
  function removeAiMember(id) { const ok = S.aiMembers.delete(id); if (ok) S.members.delete(id); return { ok }; }

  // 让指定模型成员说一句（OpenAI 兼容）
  function askAiMember(id, messages, maxTokens) {
    return new Promise((resolve) => {
      const m = S.aiMembers.get(id);
      if (!m) return resolve({ ok: false, error: '该模型成员不存在' });
      m.calls += 1;
      const body = JSON.stringify({ model: m.model, temperature: 0.7, messages, max_tokens: maxTokens || 400 });
      let url; try { url = new URL(m.baseUrl.replace(/\/$/, '') + '/chat/completions'); } catch (e) { return resolve({ ok: false, error: 'baseUrl 不合法' }); }
      const req = https.request({ hostname: url.hostname, path: url.pathname, method: 'POST', timeout: 60000,
        headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body), Authorization: 'Bearer ' + m.apiKey } }, (res) => {
        let d = ''; res.setEncoding('utf8');
        res.on('data', (c) => { d += c; });
        res.on('end', () => {
          try {
            const j = JSON.parse(d);
            const txt = (j.choices && j.choices[0] && j.choices[0].message && j.choices[0].message.content) || '';
            if (!txt) return resolve({ ok: false, error: (j.error && (j.error.message || j.error.code)) || '模型无返回' });
            resolve({ ok: true, text: txt.trim(), model: m.model, name: m.name });
          } catch (e) { resolve({ ok: false, error: '返回不是 JSON：' + d.slice(0, 80) }); }
        });
      });
      req.on('error', (e) => resolve({ ok: false, error: e.code || e.message }));
      req.on('timeout', () => { req.destroy(); resolve({ ok: false, error: '超时' }); });
      req.end(body);
    });
  }

  // 给外部 AI（aina-web）发受限权限包：能读档案、能提建议，不能碰工具/资金/设备
  function grantAiPack(memberId) {
    return issuePack({ task_id: 'ai-session', granted_to: memberId || 'aina-web',
      allowed_actions: ['archive.search', 'archive.suggest'],
      data_scope: 'archive.readonly', max_cost: 5000,
      expires_at: Date.now() + 30 * 60 * 1000 });
  }

  // 任务落盘 / 权限包落盘
  function saveTask(taskId) {
    if (!DB) return;
    const t = S.tasks.get(taskId);
    if (!t) return;
    try {
      DB.prepare('INSERT INTO cell_tasks (task_id, data) VALUES (?,?) ON CONFLICT(task_id) DO UPDATE SET data = excluded.data, updated_at = datetime(\'now\',\'localtime\')')
        .run(taskId, JSON.stringify(t));
    } catch (e) {}
  }
  function savePack(pack) {
    if (!DB || !pack) return;
    try { DB.prepare('INSERT OR REPLACE INTO cell_packs (pack_id, data) VALUES (?,?)').run(pack.pack_id, JSON.stringify(pack)); } catch (e) {}
  }
  function saveMember(member) {
    if (!DB || !member || !member.member_id) return;
    try { DB.prepare('INSERT OR REPLACE INTO cell_state (k, v) VALUES (?,?)').run('member:' + member.member_id, JSON.stringify(member)); } catch (e) {}
  }
  function restore() {
    if (!DB) return { tasks: 0, msgs: 0, packs: 0 };
    let tasks = 0, msgs = 0, packs = 0, members = 0;
    try {
      const rows = DB.prepare('SELECT task_id, data FROM cell_tasks').all();
      for (const r of rows) { try { S.tasks.set(r.task_id, JSON.parse(r.data)); tasks++; } catch (e) {} }
      const mrows = DB.prepare('SELECT seq, env FROM cell_msgs ORDER BY seq DESC LIMIT 2000').all();
      const list = mrows.reverse().map(r => { try { return JSON.parse(r.env); } catch (e) { return null; } }).filter(Boolean);
      S.log = list; msgs = list.length;
      if (list.length) S.seq = Math.max(S.seq, list[list.length - 1].seq || 0);
      const prows = DB.prepare('SELECT pack_id, data FROM cell_packs').all();
      for (const r of prows) { try { S.packs.set(r.pack_id, JSON.parse(r.data)); packs++; } catch (e) {} }
      try {
        const mrows = DB.prepare("SELECT k, v FROM cell_state WHERE k LIKE 'member:%' ESCAPE '\\'").all();
        for (const r of mrows) { try { const mm = JSON.parse(r.v); if (mm && mm.member_id) { S.members.set(mm.member_id, mm); members++; } } catch (e) {} }
      } catch (e) {}
    } catch (e) {}
    return { tasks, msgs, packs, members };
  }

  // ===== 三层记忆（会话 / 项目 / 个人画像）=====
  // 为什么要三层：会话层记「这次聊了什么」，项目层记「这个群在干什么」，画像层记「这个人是什么样」。
  // 没有画像层，"养成"就不成立——每次回来都是陌生人。
  function remember(layer, k, v) {
    if (!DB) return { ok: false, error: '未接数据库' };
    if (!['session', 'project', 'profile'].includes(layer)) return { ok: false, error: '非法层：' + layer };
    DB.prepare(`INSERT INTO cell_memory (layer, k, v) VALUES (?,?,?)
      ON CONFLICT(layer, k) DO UPDATE SET v = excluded.v`).run(layer, String(k), String(v).slice(0, 2000));
    return { ok: true };
  }
  function recall(layer, limit) {
    if (!DB) return [];
    const rows = DB.prepare('SELECT layer, k, v, created_at FROM cell_memory WHERE layer = ? ORDER BY id DESC LIMIT ?')
      .all(layer, limit || 20);
    return rows;
  }
  function memoryDigest() {
    if (!DB) return { session: [], project: [], profile: [] };
    return { session: recall('session', 10), project: recall('project', 10), profile: recall('profile', 10) };
  }

  // ===== 碳基协议（VX 拍板：做，但只影响 Aina 的回话与建议，不动任务树）=====
  // 「随便」不是两个字，它带着情绪与意图强度。提取出来，才知道该给保守建议还是激进建议。
  const MOOD_WORDS = { tired: ['累', '困', '疲', '没劲', '算了'], annoyed: ['烦', '随便', '都行', '你定', '别问了'],
                       urgent: ['马上', '立刻', '急', '今天之内', '赶'], excited: ['太棒', '牛', '厉害', '惊喜'] };
  function parseCarbon(text) {
    const t = String(text || '');
    let mood = 'neutral';
    for (const k of Object.keys(MOOD_WORDS)) {
      if (MOOD_WORDS[k].some(w => t.indexOf(w) > -1)) { mood = k; break; }
    }
    let intent = 'act';
    if (/什么|怎么|为什么|吗|？|\?/.test(t)) intent = 'ask';
    if (/随便|都行|你定|看着办/.test(t)) intent = 'delegate';
    const suggestion = mood === 'tired' || mood === 'annoyed' ? 'conservative'
      : (mood === 'urgent' ? 'fastest' : (mood === 'excited' ? 'bold' : 'balanced'));
    return { intent, mood, suggestion, raw_len: t.length };
  }

  // ===== 账本：只记账，不转账（真付钱留给 AP2 / V2）=====
  function charge(person, action, tokens, cost, taskId) {
    if (!DB) return { ok: false, error: '未接数据库' };
    if (!person) return { ok: false, code: 'E4001', error: '账必须记到自然人头上（中间层不可作为归属）' };
    DB.prepare('INSERT INTO cell_ledger (person, action, tokens, cost, task_id) VALUES (?,?,?,?,?)')
      .run(String(person), String(action), Number(tokens || 0), Number(cost || 0), String(taskId || ''));
    return { ok: true };
  }
  function ledger(limit) {
    if (!DB) return [];
    return DB.prepare('SELECT person, SUM(tokens) tokens, SUM(cost) cost, COUNT(*) calls FROM cell_ledger GROUP BY person ORDER BY tokens DESC LIMIT ?')
      .all(limit || 20);
  }
  function ledgerLines(limit) {
    if (!DB) return [];
    return DB.prepare('SELECT * FROM cell_ledger ORDER BY id DESC LIMIT ?').all(limit || 50);
  }

  // ===== 成员签名（轻量，不叫 DID）=====
  function signMember(memberId, text) {
    if (!DB) return { ok: false, error: '未接数据库' };
    const { publicKey, privateKey } = crypto.generateKeyPairSync('ed25519');
    const pub = publicKey.export({ type: 'spki', format: 'pem' });
    const signature = crypto.sign(null, Buffer.from(String(text || '')), privateKey).toString('base64');
    DB.prepare('INSERT OR REPLACE INTO cell_member_keys (member_id, pubkey) VALUES (?,?)').run(memberId, pub);
    return { ok: true, member_id: memberId, signature, pubkey: pub };
  }
  function verifyMember(memberId, text, signature) {
    if (!DB) return { ok: false, error: '未接数据库' };
    const row = DB.prepare('SELECT pubkey FROM cell_member_keys WHERE member_id = ?').get(memberId);
    if (!row) return { ok: false, verified: false, error: '该成员没有公钥，先签名注册' };
    try {
      const ok2 = crypto.verify(null, Buffer.from(String(text || '')), row.pubkey, Buffer.from(String(signature || ''), 'base64'));
      return { ok: true, verified: ok2 };
    } catch (e) { return { ok: true, verified: false, error: String(e.message) }; }
  }

  // 启动即恢复（重启不丢的关键）：任务、消息、权限包
  const RESTORED = restore();

  // 对外统一入口：谁要用模型就调它（读者模块、未来的审核员都复用这一个出口）
  function askModel(messages, maxTokens) {
    return new Promise((resolve) => { callModel(messages, maxTokens, resolve); });
  }
  return { CONTRACT_V, emit, say, msg, nodeUpdate, decideApproval, toolCall, pause, state, snapshot, subscribe, energy, setAi, aiStatus,
           listMembers, registerMember, setMemberStatus, sensorReport, speakAsAI, askModel, agentSpeak,
           issuePack, delegatePack, getPack, packStatus, grantAiPack,
           addAiMember, listAiMembers, removeAiMember, askAiMember,
           remember, recall, memoryDigest, parseCarbon, charge, ledger, ledgerLines,
           signMember, verifyMember, restore, saveTask, _S: S };
}

module.exports = { createCell, CONTRACT_V };
