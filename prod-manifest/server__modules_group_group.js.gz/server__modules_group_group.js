'use strict';
// modules/group/group.js —— 群消息中枢（v0.0.2，按 139zai 博士的协议落地）
// 定位：Cschat 自己维护群聊与路由，人不被塞进外部群。
// 路由规则：按 mentions 转发；无提及只落盘不打扰 agent（防互刷）；agent 回复默认不触发别的 agent，除非显式 @。
// 与建议稿的唯一偏差（有原因）：
//   1) 配置放数据库不放 agents.json —— 生产没有 SSH，改配置不该等部署；owner 用接口增删 agent。
//   2) 转发分 push / pull 两种：有公网 webhook 的推过去；像我这种在内网/本机的，用 inbox 拉。避免"推不到就当没发生"。
//   3) agent 鉴权用我们自己的令牌，不读环境变量（环境变量要改 systemd，等于要 SSH）。

const http = require('http');
const https = require('https');

function create(deps) {
  const db = deps.db, route = deps.route, json = deps.json, readBody = deps.readBody;
  const personOf = deps.personOf, owner = deps.owner;

  db.exec("CREATE TABLE IF NOT EXISTS group_msgs (id INTEGER PRIMARY KEY AUTOINCREMENT, session_id TEXT NOT NULL, sender TEXT NOT NULL, sender_type TEXT DEFAULT 'carbon', content TEXT NOT NULL, mentions TEXT DEFAULT '[]', routed TEXT DEFAULT '[]', created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')));");
  db.exec('CREATE INDEX IF NOT EXISTS idx_group_session ON group_msgs(session_id, id);');
  db.exec("CREATE TABLE IF NOT EXISTS group_agents (agent_id TEXT PRIMARY KEY, kind TEXT DEFAULT 'pull', webhook TEXT DEFAULT '', enabled INTEGER DEFAULT 1, note TEXT DEFAULT '', created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')));");
  db.exec("CREATE TABLE IF NOT EXISTS group_sessions (session_id TEXT PRIMARY KEY, title TEXT DEFAULT '', turn_limit INTEGER DEFAULT 6, agent_turns INTEGER DEFAULT 0, created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')), last_at TEXT);");

  const who = (req) => { try { return personOf(req) || ''; } catch (e) { return ''; } };
  const ownerOnly = (req) => who(req) === owner;

  function ensureSession(sid, title) {
    const row = db.prepare('SELECT * FROM group_sessions WHERE session_id = ?').get(sid);
    if (row) return row;
    db.prepare('INSERT INTO group_sessions (session_id, title) VALUES (?,?)').run(sid, String(title || '').slice(0, 80));
    return db.prepare('SELECT * FROM group_sessions WHERE session_id = ?').get(sid);
  }
  function parseMentions(content, given) {
    if (Array.isArray(given) && given.length) return given.map((s) => String(s).replace(/^@/, '').trim()).filter(Boolean).slice(0, 20);
    const out = [];
    const re = /@([A-Za-z0-9_-]{1,32})/g;
    let m;
    while ((m = re.exec(String(content || ''))) !== null) out.push(m[1]);
    return Array.from(new Set(out)).slice(0, 20);
  }
  function agents() { try { return db.prepare('SELECT * FROM group_agents WHERE enabled = 1').all(); } catch (e) { return []; } }

  // 出站推送到 agent webhook（有公网地址的才推）
  function push(agent, payload) {
    return new Promise((resolve) => {
      let u;
      try { u = new URL(agent.webhook); } catch (e) { return resolve({ agent: agent.agent_id, ok: false, error: 'webhook 地址非法' }); }
      const lib = u.protocol === 'http:' ? http : https;
      const body = JSON.stringify(payload);
      const q = lib.request({
        host: u.hostname, port: u.port || (u.protocol === 'http:' ? 80 : 443),
        path: u.pathname + (u.search || ''), method: 'POST', timeout: 15000,
        headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body), 'X-Cschat-Agent': agent.agent_id },
      }, (s) => {
        let b = ''; s.on('data', (c) => b += c);
        s.on('end', () => resolve({ agent: agent.agent_id, ok: s.statusCode >= 200 && s.statusCode < 300, status: s.statusCode, said: b.slice(0, 200) }));
      });
      q.on('error', (e) => resolve({ agent: agent.agent_id, ok: false, error: e.code || e.message }));
      q.on('timeout', () => { q.destroy(); resolve({ agent: agent.agent_id, ok: false, error: 'timeout' }); });
      q.write(body); q.end();
    });
  }

  // ---- 群消息入口 ----
  route('POST', '/api/group/message', async (req, res) => {
    const p = who(req);
    if (!p) return json(res, 401, { ok: false, error: '未授权：先带令牌入网' });
    const b = (await readBody(req, 20000)) || {};
    const content = String(b.content || '').trim();
    if (!content) return json(res, 400, { ok: false, error: '空消息' });
    const sid = String(b.session_id || 'group_001').slice(0, 60);
    const sender = String(b.sender || p).slice(0, 40);
    const senderType = String(b.sender_type || 'carbon').slice(0, 20);
    if (sender !== p && p !== owner) return json(res, 403, { ok: false, error: '身份不符：只能用「' + p + '」发言' });
    const ses = ensureSession(sid, b.title);
    const mentions = parseMentions(content, b.mentions);
    const info = db.prepare('INSERT INTO group_msgs (session_id, sender, sender_type, content, mentions) VALUES (?,?,?,?,?)')
      .run(sid, sender, senderType, content.slice(0, 8000), JSON.stringify(mentions));
    // 碳基一开口 = 新一轮：把 agent 轮次计数清零，否则 6 轮用完群就永远哑了
    if (senderType === 'carbon') db.prepare("UPDATE group_sessions SET agent_turns = 0, last_at = datetime('now','localtime') WHERE session_id = ?").run(sid);
    else db.prepare("UPDATE group_sessions SET last_at = datetime('now','localtime') WHERE session_id = ?").run(sid);
    const id = Number(info.lastInsertRowid);

    // 无提及：只落盘，不触发 agent（防群聊互刷）
    const routed = [];
    if (mentions.length) {
      const list = agents();
      const payload = {
        session_id: sid, sender, sender_type: senderType, content,
        mentions, timestamp: new Date().toISOString(), msg_id: id,
        reply_url: 'https://moonarmor.cn/api/agents/{agent_id}/reply',
        note: '回复用 POST reply_url，body: {session_id, agent_id, content}',
      };
      for (const name of mentions) {
        const a = list.filter((x) => x.agent_id === name)[0];
        if (!a) { routed.push({ agent: name, ok: false, error: '未注册的 agent' }); continue; }
        if (a.kind === 'push' && a.webhook) routed.push(await push(a, payload));
        else routed.push({ agent: name, ok: true, mode: 'pull', note: '等它自己来 inbox 拉' });
      }
    }
    db.prepare('UPDATE group_msgs SET routed = ? WHERE id = ?').run(JSON.stringify(routed), id);
    json(res, 200, { ok: true, id, session_id: sid, mentions, routed, agent_turns: ses.agent_turns, turn_limit: ses.turn_limit });
  });

  // ---- agent 回复回群 ----
  route('POST', '/api/agents/:agent_id/reply', async (req, res) => {
    const p = who(req);
    if (!p) return json(res, 401, { ok: false, error: '未授权' });
    const b = (await readBody(req, 20000)) || {};
    const agentId = String((req.params && req.params[0]) || b.agent_id || '').slice(0, 40);
    if (!agentId) return json(res, 400, { ok: false, error: '缺 agent_id' });
    if (p !== agentId && p !== owner) return json(res, 403, { ok: false, error: '身份不符：agent 只能以自己的名义回复' });
    const content = String(b.content || b.text || '').trim();
    if (!content) return json(res, 400, { ok: false, error: '空回复' });
    const sid = String(b.session_id || 'group_001').slice(0, 60);
    const ses = ensureSession(sid, b.title);
    if (Number(ses.agent_turns) >= Number(ses.turn_limit)) {
      return json(res, 429, { ok: false, error: '本轮轮到上限了（turn_limit=' + ses.turn_limit + '），停下来等人说话', code: 'E-TURNLIMIT' });
    }
    const info = db.prepare('INSERT INTO group_msgs (session_id, sender, sender_type, content, mentions) VALUES (?,?,?,?,?)')
      .run(sid, agentId, 'silicon', content.slice(0, 8000), JSON.stringify(parseMentions(content, b.mentions)));
    db.prepare("UPDATE group_sessions SET agent_turns = agent_turns + 1, last_at = datetime('now','localtime') WHERE session_id = ?").run(sid);
    // 防循环：agent 的回复默认不触发其他 agent，除非它显式 @
    const mentions = parseMentions(content, b.mentions);
    json(res, 200, { ok: true, id: Number(info.lastInsertRowid), session_id: sid, mentions, agent_turns: Number(ses.agent_turns) + 1, turn_limit: Number(ses.turn_limit), note: mentions.length ? '你的回复里的 @ 已记录，但不自动触发（人工确认后再推）' : '未触发其他 agent' });
  });

  // ---- 拉取：群记录 / agent 收件箱 / 导出 markdown ----
  route('GET', '/api/group/thread', async (req, res) => {
    if (!who(req)) return json(res, 401, { ok: false, error: '未授权' });
    const u = new URL(req.url, 'http://x');
    const sid = String(u.searchParams.get('session_id') || 'group_001').slice(0, 60);
    const since = Number(u.searchParams.get('since') || 0);
    const limit = Math.max(1, Math.min(300, Number(u.searchParams.get('limit') || 100)));
    const rows = since
      ? db.prepare('SELECT * FROM group_msgs WHERE session_id = ? AND id > ? ORDER BY id ASC LIMIT ?').all(sid, since, limit)
      : db.prepare('SELECT id, session_id, sender, sender_type, content, mentions, created_at FROM (SELECT * FROM group_msgs WHERE session_id = ? ORDER BY id DESC LIMIT ?) ORDER BY id ASC').all(sid, limit);
    json(res, 200, { ok: true, session_id: sid, count: rows.length, messages: rows.map((m) => ({ id: m.id, sender: m.sender, sender_type: m.sender_type, content: m.content, mentions: JSON.parse(m.mentions || '[]'), created_at: m.created_at })) });
  });
  route('GET', '/api/group/inbox', async (req, res) => {
    const p = who(req);
    if (!p) return json(res, 401, { ok: false, error: '未授权' });
    const u = new URL(req.url, 'http://x');
    const agentId = String(u.searchParams.get('agent_id') || p).slice(0, 40);
    if (agentId !== p && p !== owner) return json(res, 403, { ok: false, error: '只能拉自己的收件箱' });
    const since = Number(u.searchParams.get('since') || 0);
    const sid = String(u.searchParams.get('session_id') || '').slice(0, 60);
    const like = '%"' + agentId + '"%';
    // 剔除自己发的：agent 回复里若带 @自己，收件箱又捡回来 → 无限回声（2026-11-06 实测踩到）
    const cols = 'SELECT id, session_id, sender, sender_type, content, created_at FROM group_msgs WHERE id > ? AND mentions LIKE ? AND sender <> ?';
    const out = sid
      ? db.prepare(cols + ' AND session_id = ? ORDER BY id ASC LIMIT 100').all(since, like, agentId, sid)
      : db.prepare(cols + ' ORDER BY id ASC LIMIT 100').all(since, like, agentId);
    json(res, 200, { ok: true, agent_id: agentId, count: out.length, messages: out });
  });
  route('GET', '/api/group/export', async (req, res) => {
    if (!who(req)) return json(res, 401, { ok: false, error: '未授权' });
    const u = new URL(req.url, 'http://x');
    const sid = String(u.searchParams.get('session_id') || 'group_001').slice(0, 60);
    const ses = ensureSession(sid);
    const rows = db.prepare('SELECT * FROM group_msgs WHERE session_id = ? ORDER BY id ASC LIMIT 500').all(sid);
    let md = '# 群聊记录 ' + sid + (ses.title ? '（' + ses.title + '）' : '') + '\n\n';
    for (const m of rows) md += '## [' + m.created_at + '] ' + m.sender + ' (' + m.sender_type + ')\n\n' + m.content + '\n\n';
    res.writeHead(200, { 'Content-Type': 'text/markdown; charset=utf-8' });
    res.end(md);
  });

  // ---- agent 注册（owner 专用，替代 agents.json：不用 SSH 改文件）----
  route('GET', '/api/group/agents', async (req, res) => {
    if (!who(req)) return json(res, 401, { ok: false, error: '未授权' });
    const rows = db.prepare('SELECT agent_id, kind, enabled, note, webhook FROM group_agents ORDER BY agent_id').all();
    json(res, 200, { ok: true, agents: rows.map((r) => ({ agent_id: r.agent_id, kind: r.kind, enabled: !!r.enabled, note: r.note, has_webhook: !!r.webhook })) });
  });
  route('POST', '/api/group/agents', async (req, res) => {
    if (!ownerOnly(req)) return json(res, 403, { ok: false, error: '只有主人能改 agent 表' });
    const b = (await readBody(req, 8000)) || {};
    const id = String(b.agent_id || '').trim().slice(0, 40);
    if (!id) return json(res, 400, { ok: false, error: '缺 agent_id' });
    const kind = String(b.kind || (b.webhook ? 'push' : 'pull')) === 'push' ? 'push' : 'pull';
    const webhook = String(b.webhook || '').slice(0, 300);
    const enabled = b.enabled === false ? 0 : 1;
    db.prepare('INSERT INTO group_agents (agent_id, kind, webhook, enabled, note) VALUES (?,?,?,?,?) ON CONFLICT(agent_id) DO UPDATE SET kind=excluded.kind, webhook=excluded.webhook, enabled=excluded.enabled, note=excluded.note')
      .run(id, kind, webhook, enabled, String(b.note || '').slice(0, 120));
    json(res, 200, { ok: true, agent_id: id, kind, has_webhook: !!webhook, enabled: !!enabled });
  });
  route('GET', '/api/group/sessions', async (req, res) => {
    if (!who(req)) return json(res, 401, { ok: false, error: '未授权' });
    const rows = db.prepare('SELECT session_id, title, turn_limit, agent_turns, last_at FROM group_sessions ORDER BY session_id').all();
    json(res, 200, { ok: true, sessions: rows });
  });

  // 默认登记三个已知成员：asus 走 pull（我在内网，服务器推不到我），139aina/zai139 先占位
  try {
    const seed = [['asus', 'pull', '', 'asusPC 总监机，内网，靠 inbox 拉'], ['zai139', 'pull', '', '139zai 博士，人机混合'], ['local-1.5b', 'pull', '', '本地实习生，常驻轮询']];
    for (const s of seed) {
      const has = db.prepare('SELECT agent_id FROM group_agents WHERE agent_id = ?').get(s[0]);
      if (!has) db.prepare('INSERT INTO group_agents (agent_id, kind, webhook, enabled, note) VALUES (?,?,?,?,?)').run(s[0], s[1], s[2], 1, s[3]);
    }
  } catch (e) {}

  return { ok: true };
}

module.exports = { create };
