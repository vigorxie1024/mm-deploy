// moonarmor 数据库初始化与 Schema（node:sqlite，零依赖）
'use strict';
const { DatabaseSync } = require('node:sqlite');
const path = require('node:path');
const fs = require('node:fs');

const DB_PATH = process.env.MOONARMOR_DB || path.join(__dirname, 'data', 'moonarmor.db');
fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });
const db = new DatabaseSync(DB_PATH);
db.exec('PRAGMA journal_mode = WAL;');
db.exec('PRAGMA foreign_keys = ON;');

function initSchema() {
  db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    phone TEXT UNIQUE,
    email TEXT UNIQUE,
    nickname TEXT NOT NULL DEFAULT '',
    password_hash TEXT,
    avatar TEXT DEFAULT '',
    role TEXT NOT NULL DEFAULT 'registered',   -- admin | core | registered
    verified INTEGER NOT NULL DEFAULT 0,        -- 实名/高级认证
    wechat_openid TEXT, alipay_user_id TEXT,
    user_type INTEGER NOT NULL DEFAULT 3,  -- 社区身份：1供给 2投资 3消费 4平台 5设计 6其它
    community_id INTEGER,
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    updated_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
  );
  CREATE TABLE IF NOT EXISTS sessions (
    token TEXT PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    expires_at TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
  );
  CREATE TABLE IF NOT EXISTS categories (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    level INTEGER NOT NULL,                     -- 1|2|3
    name TEXT NOT NULL,
    slug TEXT NOT NULL,
    parent_id INTEGER DEFAULT NULL REFERENCES categories(id),
    sort_order INTEGER NOT NULL DEFAULT 0,
    description TEXT DEFAULT '',
    UNIQUE(slug)
  );
  CREATE TABLE IF NOT EXISTS app_areas (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL, slug TEXT NOT NULL UNIQUE,
    description TEXT DEFAULT '', sort_order INTEGER NOT NULL DEFAULT 0
  );
  CREATE TABLE IF NOT EXISTS articles (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    slug TEXT NOT NULL UNIQUE,
    content TEXT NOT NULL DEFAULT '',
    summary TEXT DEFAULT '',
    author_id INTEGER REFERENCES users(id),
    author_name TEXT DEFAULT '谢沛频（VX）',
    cat1_id INTEGER REFERENCES categories(id),
    cat2_id INTEGER REFERENCES categories(id),
    cat3_id INTEGER REFERENCES categories(id),
    granularity TEXT DEFAULT '',                -- L1..L6，可多选逗号分隔
    app_areas TEXT DEFAULT '[]',                -- JSON array
    tags TEXT DEFAULT '[]',                     -- JSON array
    status TEXT NOT NULL DEFAULT 'draft',       -- draft|reviewed|published|archived
    is_paid INTEGER NOT NULL DEFAULT 0,         -- 付费内容
    price REAL NOT NULL DEFAULT 0,
    view_count INTEGER NOT NULL DEFAULT 0,
    comment_count INTEGER NOT NULL DEFAULT 0,
    like_count INTEGER NOT NULL DEFAULT 0,
    source_doc TEXT DEFAULT '',
    version INTEGER NOT NULL DEFAULT 1,
    published_at TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    updated_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
  );
  -- CREATE INDEX idx_articles_cat1 ON articles(cat1_id);
  -- CREATE INDEX idx_articles_status ON articles(status);
  CREATE TABLE IF NOT EXISTS comments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    article_id INTEGER NOT NULL REFERENCES articles(id) ON DELETE CASCADE,
    parent_id INTEGER DEFAULT NULL REFERENCES comments(id),
    user_id INTEGER REFERENCES users(id),
    nickname TEXT DEFAULT '',
    content TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'visible',     -- visible|hidden
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
  );
  CREATE TABLE IF NOT EXISTS chapter_thoughts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    chapter_slug TEXT NOT NULL,
    user_id INTEGER REFERENCES users(id),
    nickname TEXT DEFAULT '',
    question TEXT DEFAULT '',
    content TEXT NOT NULL,
    visibility TEXT NOT NULL DEFAULT 'private', -- private|public
    status TEXT NOT NULL DEFAULT 'visible',     -- visible|hidden
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
  );
  CREATE INDEX IF NOT EXISTS idx_thoughts_ch ON chapter_thoughts(chapter_slug, visibility, status);
  CREATE TABLE IF NOT EXISTS tips (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    article_id INTEGER REFERENCES articles(id),
    user_id INTEGER REFERENCES users(id),
    nickname TEXT DEFAULT '',
    amount REAL NOT NULL,
    message TEXT DEFAULT '',
    order_no TEXT NOT NULL UNIQUE,
    pay_channel TEXT NOT NULL DEFAULT 'simulate',  -- alipay|wechat|simulate
    status TEXT NOT NULL DEFAULT 'pending',        -- pending|paid|confirmed|cancelled
    external_trade_no TEXT DEFAULT '',
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    paid_at TEXT
  );
  CREATE TABLE IF NOT EXISTS products (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    type TEXT NOT NULL,                          -- ebook|member|course|book_presale|ai_service|tip
    price REAL NOT NULL DEFAULT 0,
    original_price REAL DEFAULT 0,
    description TEXT DEFAULT '',
    badge TEXT DEFAULT '',
    status TEXT NOT NULL DEFAULT 'on',
    sort_order INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
  );
  CREATE TABLE IF NOT EXISTS orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    order_no TEXT NOT NULL UNIQUE,
    product_id INTEGER REFERENCES products(id),
    article_id INTEGER REFERENCES articles(id),
    user_id INTEGER REFERENCES users(id),
    nickname TEXT DEFAULT '',
    amount REAL NOT NULL,
    pay_channel TEXT NOT NULL DEFAULT 'simulate',
    status TEXT NOT NULL DEFAULT 'pending',      -- pending|paid|cancelled|refunded
    external_trade_no TEXT DEFAULT '',
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    paid_at TEXT
  );
  CREATE TABLE IF NOT EXISTS dividend_ledger (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    entry_type TEXT NOT NULL,                    -- tip|order|pool_init
    ref_id INTEGER DEFAULT 0,
    amount REAL NOT NULL,                        -- 原始收入
    ratio REAL NOT NULL DEFAULT 0.618,
    pool_amount REAL NOT NULL,                   -- 计入分红池金额
    note TEXT DEFAULT '',
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
  );
  CREATE TABLE IF NOT EXISTS distribution_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    article_id INTEGER NOT NULL REFERENCES articles(id) ON DELETE CASCADE,
    platform TEXT NOT NULL,                      -- douyin|kuaishou|bilibili|shipinhao|wechat|zhihu|xiaohongshu
    status TEXT NOT NULL DEFAULT 'pending',      -- pending|published|failed|mock
    url TEXT DEFAULT '',
    error TEXT DEFAULT '',
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    published_at TEXT
  );
  CREATE TABLE IF NOT EXISTS revision_suggestions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    article_id INTEGER NOT NULL REFERENCES articles(id) ON DELETE CASCADE,
    user_id INTEGER REFERENCES users(id),
    nickname TEXT DEFAULT '',
    content TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending',      -- pending|accepted|rejected|merged
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
  );
  CREATE TABLE IF NOT EXISTS agent_tasks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    article_id INTEGER REFERENCES articles(id),
    task_type TEXT NOT NULL,                     -- article|image|video|drama
    provider TEXT DEFAULT '',
    status TEXT NOT NULL DEFAULT 'queued',       -- queued|running|draft|failed
    params TEXT DEFAULT '{}',
    output TEXT DEFAULT '',
    error TEXT DEFAULT '',
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    finished_at TEXT
  );
  CREATE TABLE IF NOT EXISTS keywords (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    term TEXT NOT NULL UNIQUE,
    target_type TEXT NOT NULL,                   -- category|article|term
    target_id INTEGER DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
  );
  CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL DEFAULT '{}',
    updated_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
  );
  CREATE TABLE IF NOT EXISTS indices (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    code TEXT NOT NULL UNIQUE,
    name TEXT NOT NULL,
    category TEXT NOT NULL,
    base_date TEXT NOT NULL DEFAULT '2026-01-01',
    base_value REAL NOT NULL DEFAULT 1000,
    description TEXT DEFAULT '',
    status TEXT NOT NULL DEFAULT 'draft',
    update_frequency TEXT NOT NULL DEFAULT 'daily',
    factor_rules TEXT DEFAULT '{}',
    data_sources TEXT DEFAULT '[]',
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    updated_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
  );
  CREATE TABLE IF NOT EXISTS index_components (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    index_id INTEGER NOT NULL REFERENCES indices(id) ON DELETE CASCADE,
    component_type TEXT NOT NULL,
    component_id INTEGER NOT NULL,
    weight REAL NOT NULL DEFAULT 1.0,
    data_source TEXT DEFAULT '',
    status TEXT NOT NULL DEFAULT 'active',
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
  );
  CREATE INDEX IF NOT EXISTS idx_index_components_idx ON index_components(index_id);
  CREATE TABLE IF NOT EXISTS index_factors (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    index_id INTEGER NOT NULL REFERENCES indices(id) ON DELETE CASCADE,
    factor_name TEXT NOT NULL,
    factor_value REAL NOT NULL DEFAULT 0,
    period TEXT NOT NULL DEFAULT 'daily',
    period_start TEXT NOT NULL,
    period_end TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
  );
  CREATE INDEX IF NOT EXISTS idx_index_factors_idx ON index_factors(index_id);
  CREATE TABLE IF NOT EXISTS index_prices (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    index_id INTEGER NOT NULL REFERENCES indices(id) ON DELETE CASCADE,
    price_open REAL NOT NULL DEFAULT 0,
    price_close REAL NOT NULL DEFAULT 0,
    price_high REAL NOT NULL DEFAULT 0,
    price_low REAL NOT NULL DEFAULT 0,
    volume REAL NOT NULL DEFAULT 0,
    turnover REAL NOT NULL DEFAULT 0,
    change_pct REAL NOT NULL DEFAULT 0,
    market_cap REAL NOT NULL DEFAULT 0,
    period TEXT NOT NULL DEFAULT 'daily',
    period_start TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
  );
  CREATE INDEX IF NOT EXISTS idx_index_prices_idx ON index_prices(index_id);
  CREATE INDEX IF NOT EXISTS idx_index_prices_period ON index_prices(index_id, period_start);
  -- SLIM 超级劳动交易所：三主体表（与 scripts/seed-slim-exchange.js 保持一致，空库自举防漂移）
  CREATE TABLE IF NOT EXISTS slim_entities (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    code TEXT UNIQUE,
    name TEXT,
    entity_type TEXT,
    industry TEXT,
    region TEXT,
    scale INTEGER,
    credit_score INTEGER,
    status TEXT DEFAULT 'listed',
    attrs TEXT DEFAULT '{}',
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
  );
  CREATE TABLE IF NOT EXISTS slim_products (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    code TEXT UNIQUE,
    name TEXT,
    category TEXT,
    owner_entity_id INTEGER,
    price REAL,
    unit TEXT,
    score REAL,
    status TEXT DEFAULT 'listed',
    attrs TEXT DEFAULT '{}',
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
  );
  CREATE TABLE IF NOT EXISTS slim_laborers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    code TEXT UNIQUE,
    name TEXT,
    skills TEXT,
    region TEXT,
    daily_rate REAL,
    credit_score INTEGER,
    entity_id INTEGER,
    status TEXT DEFAULT 'active',
    attrs TEXT DEFAULT '{}',
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
  );
  `);
  // ===== CSchat · 碳硅基协同聊天（喊话台增量底座）=====
  // 主体：碳基 C + 硅基 S1大模型/S2工具/S3载体/S4集群/S5分身，人格完全平等
  db.exec(`
    CREATE TABLE IF NOT EXISTS cschat_subjects (
      id TEXT PRIMARY KEY,                 -- 主体ID：碳基=用户uid | 硅基=agent-id
      kind TEXT NOT NULL,                  -- C | S1 | S2 | S3 | S4 | S5
      name TEXT NOT NULL,
      avatar TEXT DEFAULT '',
      profile TEXT DEFAULT '',             -- JSON 档案（权责/技能/端集合）
      created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
    );
    CREATE TABLE IF NOT EXISTS cschat_rooms (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      kind TEXT DEFAULT 'group',           -- group 群聊 | dm 单聊 | spirit 精神帖
      owner_id TEXT NOT NULL,
      meta TEXT DEFAULT '',                -- JSON：端集合/协议栈/公约
      created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
    );
    CREATE TABLE IF NOT EXISTS cschat_members (
      room_id INTEGER NOT NULL,
      subject_id TEXT NOT NULL,
      role TEXT DEFAULT 'member',          -- owner | admin | member
      joined_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
      PRIMARY KEY (room_id, subject_id)
    );
    CREATE TABLE IF NOT EXISTS cschat_messages (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      room_id INTEGER NOT NULL,
      from_id TEXT NOT NULL,
      kind TEXT DEFAULT 'text',            -- text | image | file | intent | spirit
      body TEXT NOT NULL DEFAULT '',
      envelope TEXT DEFAULT '',            -- 统一意图信封 JSON
      reply_to INTEGER DEFAULT 0,
      ack INTEGER DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
    );
    CREATE INDEX IF NOT EXISTS idx_cschat_msg_room ON cschat_messages(room_id, id);
    CREATE INDEX IF NOT EXISTS idx_cschat_mem_sub ON cschat_members(subject_id);
  `);
}

function migrate() {
  const cols = (t) => db.prepare('PRAGMA table_info(' + t + ')').all().map(c => c.name);
  // ===== 撮合交易子系统（代码系统+交易所） =====
  db.exec(`
    CREATE TABLE IF NOT EXISTS mk_codes (
      code TEXT PRIMARY KEY,
      level INTEGER NOT NULL, entity INTEGER NOT NULL,
      country TEXT NOT NULL DEFAULT '156', province TEXT NOT NULL DEFAULT '51',
      seq INTEGER NOT NULL, owner_id INTEGER, name TEXT DEFAULT '',
      created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
    );
    CREATE TABLE IF NOT EXISTS mk_listings (
      code TEXT PRIMARY KEY,
      name TEXT NOT NULL, type INTEGER NOT NULL,  -- 1劳动力 2法人 3产品 4指数
      issuer_id INTEGER NOT NULL, total_shares INTEGER NOT NULL DEFAULT 0,
      price REAL NOT NULL DEFAULT 0, status TEXT DEFAULT 'trading',  -- trading|halted|delisted
      info TEXT DEFAULT '{}',
      created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
    );
    CREATE TABLE IF NOT EXISTS mk_orders (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      code TEXT NOT NULL, user_id INTEGER NOT NULL,
      side TEXT NOT NULL,  -- buy|sell
      qty INTEGER NOT NULL, price REAL NOT NULL,
      filled_qty INTEGER NOT NULL DEFAULT 0, status TEXT DEFAULT 'open',  -- open|partial|filled|canceled
      created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
    );
    CREATE TABLE IF NOT EXISTS mk_trades (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      code TEXT NOT NULL, buyer_id INTEGER, seller_id INTEGER,
      qty INTEGER NOT NULL, price REAL NOT NULL,
      created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
    );
    CREATE TABLE IF NOT EXISTS mk_holdings (
      user_id INTEGER NOT NULL, code TEXT NOT NULL,
      qty INTEGER NOT NULL DEFAULT 0, avg_cost REAL NOT NULL DEFAULT 0,
      PRIMARY KEY (user_id, code)
    );
    CREATE TABLE IF NOT EXISTS mk_price_history (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      code TEXT NOT NULL, price REAL NOT NULL,
      at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
    );
    CREATE INDEX IF NOT EXISTS idx_mkh_code ON mk_price_history(code, id DESC);
    CREATE TABLE IF NOT EXISTS agent_plaza (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      name TEXT NOT NULL, ico TEXT DEFAULT '🤖',
      cat TEXT DEFAULT 'gov', desc TEXT, href TEXT NOT NULL,
      status TEXT DEFAULT 'pending',
      created_at TEXT DEFAULT (datetime('now','localtime'))
    );
    CREATE TABLE IF NOT EXISTS user_agents (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL UNIQUE,           -- 每个碳基人至多 1 个专属智能体（公理三）
      agent_id INTEGER NOT NULL,                 -- 关联 agent_plaza.id（status='personal'，不上广场）
      created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
    );
    CREATE INDEX IF NOT EXISTS idx_user_agents_agent ON user_agents(agent_id);
  `);
  // 交易所：发行价列（算涨跌幅），旧数据回填为当前价
  try { const lcols = cols('mk_listings'); if (!lcols.includes('issue_price')) { db.exec('ALTER TABLE mk_listings ADD COLUMN issue_price REAL'); db.exec('UPDATE mk_listings SET issue_price = price WHERE issue_price IS NULL'); } } catch (e) {}
  // 统一用户体系：主站 users 表扩展社区身份字段
  try { const ucols = cols('users'); if (!ucols.includes('user_type')) db.exec('ALTER TABLE users ADD COLUMN user_type INTEGER NOT NULL DEFAULT 3'); if (!ucols.includes('community_id')) db.exec('ALTER TABLE users ADD COLUMN community_id INTEGER'); } catch(e) {}
  // P0 登录通道：证件号（身份证/护照等任一有效证件）
  try { const uc2 = cols('users'); if (!uc2.includes('id_card')) db.exec('ALTER TABLE users ADD COLUMN id_card TEXT'); db.exec('CREATE UNIQUE INDEX IF NOT EXISTS idx_users_idcard ON users(id_card) WHERE id_card IS NOT NULL'); } catch(e) {}
  try { const crcols = cols('content_records'); if (!crcols.includes('credential')) db.exec('ALTER TABLE content_records ADD COLUMN credential TEXT DEFAULT \'\''); } catch(e) { /* table may not exist yet */ }
  // 公理三 · 人格引擎（asus #497/#500）：专属智能体的人格档案随所有权落库，保证同一用户人格稳定不变
  try { const uagcols = cols('user_agents'); if (!uagcols.includes('persona_json')) db.exec('ALTER TABLE user_agents ADD COLUMN persona_json TEXT'); } catch(e) {}
  // SLIM:为撮合意向单补齐技能/距离/区位/薪资期望字段(兼容既有库)
  try {
    const mcols = cols('match_intents');
    if (mcols.length) {
      if (!mcols.includes('skills')) db.exec("ALTER TABLE match_intents ADD COLUMN skills TEXT DEFAULT '[]'");
      if (!mcols.includes('location')) db.exec("ALTER TABLE match_intents ADD COLUMN location TEXT DEFAULT ''");
      if (!mcols.includes('distance_max_km')) db.exec("ALTER TABLE match_intents ADD COLUMN distance_max_km REAL DEFAULT 0");
      if (!mcols.includes('salary_expect')) db.exec("ALTER TABLE match_intents ADD COLUMN salary_expect REAL DEFAULT 0");
      if (!mcols.includes('entity_type')) db.exec("ALTER TABLE match_intents ADD COLUMN entity_type TEXT DEFAULT ''");
      if (!mcols.includes('entity_id')) db.exec('ALTER TABLE match_intents ADD COLUMN entity_id INTEGER DEFAULT 0');
    }
  } catch(e) { /* table may not exist yet */ }
  const acols = cols('articles');
  if (!acols.includes('schedule_at')) try { db.exec('ALTER TABLE articles ADD COLUMN schedule_at TEXT'); } catch(e) {};
  if (!acols.includes('rating_sum')) try { db.exec('ALTER TABLE articles ADD COLUMN rating_sum REAL NOT NULL DEFAULT 0'); } catch(e) {};
  if (!acols.includes('rating_count')) try { db.exec('ALTER TABLE articles ADD COLUMN rating_count INTEGER NOT NULL DEFAULT 0'); } catch(e) {};
  // 支付契约 V1.0：订单归属业务线（biz=cert/deco/book…），用于 ledger 归集与分成
  try {
    const ocols = cols('orders');
    if (ocols.length) {
      if (!ocols.includes('biz')) db.exec("ALTER TABLE orders ADD COLUMN biz TEXT DEFAULT ''");
      if (!ocols.includes('biz_ref')) db.exec("ALTER TABLE orders ADD COLUMN biz_ref TEXT DEFAULT ''");
    }
  } catch (e) { /* table may not exist yet */ }
  // listing_trades 评价/投诉/复购字段
  try { const ltcols = cols('listing_trades'); if (ltcols.length) { if (!ltcols.includes('rating')) db.exec('ALTER TABLE listing_trades ADD COLUMN rating INTEGER DEFAULT 0'); if (!ltcols.includes('complaint')) db.exec('ALTER TABLE listing_trades ADD COLUMN complaint INTEGER NOT NULL DEFAULT 0'); if (!ltcols.includes('rating_note')) db.exec('ALTER TABLE listing_trades ADD COLUMN rating_note TEXT DEFAULT \'\''); } } catch(e) { /* table may not exist yet */ }
  // likes 表扩展为通用点赞（支持 article / chapter 等 target_type）
  // 旧表 article_id 带 REFERENCES articles(id) FK + UNIQUE(article_id,user_id)，
  // 导致 chapter 点赞(article_id=0)插入失败、且不同 chapter 点赞互相冲突。
  // 检测建表语句：含 REFERENCES 或含 UNIQUE(article_id 即需重建（生产 0 行，安全）。
  try {
    const lkrow = db.prepare("SELECT sql FROM sqlite_master WHERE type='table' AND name='likes'").get();
    if (lkrow && lkrow.sql && (lkrow.sql.indexOf('REFERENCES') !== -1 || lkrow.sql.indexOf('UNIQUE(article_id') !== -1)) {
      db.exec('DROP TABLE IF EXISTS likes');
    }
  } catch(e) { /* table may not exist yet */ }
  db.exec(`
    CREATE TABLE IF NOT EXISTS likes (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      article_id INTEGER NOT NULL DEFAULT 0,
      target_type TEXT NOT NULL DEFAULT 'article',
      target_id TEXT NOT NULL DEFAULT '',
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
    );
    CREATE UNIQUE INDEX IF NOT EXISTS idx_likes_target ON likes(target_type, target_id, user_id);
    CREATE TABLE IF NOT EXISTS ratings (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      article_id INTEGER NOT NULL REFERENCES articles(id) ON DELETE CASCADE,
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      score INTEGER NOT NULL CHECK(score BETWEEN 1 AND 5),
      created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
      UNIQUE(article_id, user_id)
    );
    CREATE TABLE IF NOT EXISTS favorites (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      article_id INTEGER NOT NULL REFERENCES articles(id) ON DELETE CASCADE,
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
      UNIQUE(article_id, user_id)
    );
    CREATE TABLE IF NOT EXISTS notifications (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      type TEXT NOT NULL DEFAULT 'system',
      title TEXT DEFAULT '',
      content TEXT DEFAULT '',
      link TEXT DEFAULT '',
      is_read INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
    );
    CREATE INDEX IF NOT EXISTS idx_notify_user ON notifications(user_id, is_read);
    CREATE TABLE IF NOT EXISTS reports (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      target_type TEXT NOT NULL,
      target_id INTEGER NOT NULL,
      user_id INTEGER,
      reason TEXT DEFAULT '',
      status TEXT NOT NULL DEFAULT 'pending',
      created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
    );
    CREATE TABLE IF NOT EXISTS content_records (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      article_id INTEGER REFERENCES articles(id) ON DELETE SET NULL,
      content_hash TEXT NOT NULL,
      prev_hash TEXT DEFAULT '',
      record_type TEXT DEFAULT 'publish',
      note TEXT DEFAULT '',
      created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
    );
    CREATE TABLE IF NOT EXISTS article_versions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      article_id INTEGER NOT NULL REFERENCES articles(id) ON DELETE CASCADE,
      title TEXT NOT NULL,
      content TEXT DEFAULT '',
      summary TEXT DEFAULT '',
      version_no INTEGER NOT NULL DEFAULT 1,
      change_note TEXT DEFAULT '',
      created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
    );
    CREATE TABLE IF NOT EXISTS governance_docs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      doc_type TEXT NOT NULL,                    -- pact|audit|notice
      title TEXT NOT NULL,
      content TEXT DEFAULT '',
      status TEXT NOT NULL DEFAULT 'published',
      created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
    );
    CREATE TABLE IF NOT EXISTS fee_plans (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,                        -- 档位名称
      mode TEXT NOT NULL DEFAULT 'per_trade',    -- per_trade(按次) | per_income(按收益) | hybrid
      per_trade_price REAL NOT NULL DEFAULT 0,   -- 按次价格(元)
      income_ratio REAL NOT NULL DEFAULT 0,      -- 按收益比例(千分比, 0.1 表示 0.1‰)
      description TEXT DEFAULT '',
      is_default INTEGER NOT NULL DEFAULT 0,
      sort_order INTEGER NOT NULL DEFAULT 0,
      status TEXT NOT NULL DEFAULT 'on',         -- on | off
      created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
    );
    CREATE TABLE IF NOT EXISTS user_fee_plans (
      user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
      plan_id INTEGER NOT NULL REFERENCES fee_plans(id),
      chosen_reason TEXT DEFAULT '',
      chosen_by TEXT NOT NULL DEFAULT 'user',    -- user | agent
      updated_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
    );
    CREATE TABLE IF NOT EXISTS governance_votes (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      proposal_type TEXT NOT NULL,               -- fee_plan | pact | rule
      proposal_id INTEGER NOT NULL DEFAULT 0,    -- 关联对象id（如 fee_plans.id）
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      vote TEXT NOT NULL DEFAULT 'approve',      -- approve | reject | abstain
      note TEXT DEFAULT '',
      created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
      UNIQUE(proposal_type, proposal_id, user_id)
    );
    CREATE TABLE IF NOT EXISTS listings (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      designer_id INTEGER NOT NULL REFERENCES users(id),
      title TEXT NOT NULL,
      category TEXT NOT NULL,                    -- labor|product|institution|index|service|fund (sHRmatch 6类品种)
      variety_code TEXT DEFAULT '',              -- 品种编码，如 SHR-LB-001
      base_asset TEXT DEFAULT '',                -- 锚定物：劳动力/劳动产品/组合指数
      description TEXT DEFAULT '',
      price REAL NOT NULL DEFAULT 0,
      unit TEXT DEFAULT '份',                    -- 计价单位
      supply_qty INTEGER DEFAULT 0,              -- 可撮合数量（0=不限）
      commission_ratio REAL NOT NULL DEFAULT 0.1, -- 平台分成比例(0.1=10%)
      designer_ratio REAL NOT NULL DEFAULT 0.9,   -- 设计者分成比例(0.9=90%)
      score REAL NOT NULL DEFAULT 100,            -- 考核综合分(100 起)
      status TEXT NOT NULL DEFAULT 'pending',     -- pending|on|off|rejected
      reject_reason TEXT DEFAULT '',
      metrics TEXT DEFAULT '{}',                  -- 考核指标快照 JSON
      created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
    );
    CREATE TABLE IF NOT EXISTS listing_metrics (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      listing_id INTEGER NOT NULL REFERENCES listings(id) ON DELETE CASCADE,
      trade_count INTEGER NOT NULL DEFAULT 0,     -- 成交笔数
      trade_volume REAL NOT NULL DEFAULT 0,       -- 成交额
      buyer_count INTEGER NOT NULL DEFAULT 0,     -- 买家数
      return_rate REAL NOT NULL DEFAULT 0,        -- 复购率/回购率
      complaint_count INTEGER NOT NULL DEFAULT 0, -- 投诉数
      rating_avg REAL NOT NULL DEFAULT 0,         -- 评价均分
      period TEXT NOT NULL DEFAULT 'month',       -- 考核周期 month|quarter
      period_start TEXT DEFAULT '',
      score REAL NOT NULL DEFAULT 100,            -- 本期得分
      updated_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
    );
    CREATE TABLE IF NOT EXISTS listing_trades (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      listing_id INTEGER NOT NULL REFERENCES listings(id) ON DELETE CASCADE,
      buyer_id INTEGER REFERENCES users(id),
      designer_id INTEGER NOT NULL REFERENCES users(id),
      qty REAL NOT NULL DEFAULT 1,
      amount REAL NOT NULL DEFAULT 0,
      commission_amount REAL NOT NULL DEFAULT 0,  -- 平台分成金额
      designer_amount REAL NOT NULL DEFAULT 0,    -- 设计者分成金额
      status TEXT NOT NULL DEFAULT 'pending',     -- pending|settled|cancelled
      order_no TEXT NOT NULL UNIQUE,
      created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
      settled_at TEXT
    );
    CREATE TABLE IF NOT EXISTS subscription_plans (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,                         -- 月卡/季卡/年卡
      period_days INTEGER NOT NULL,               -- 有效期天数：30/90/365
      price REAL NOT NULL DEFAULT 0,
      original_price REAL DEFAULT 0,
      description TEXT DEFAULT '',
      badge TEXT DEFAULT '',
      status TEXT NOT NULL DEFAULT 'on',
      sort_order INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
    );
    CREATE TABLE IF NOT EXISTS subscriptions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      plan_id INTEGER NOT NULL REFERENCES subscription_plans(id),
      status TEXT NOT NULL DEFAULT 'active',      -- active|expired|cancelled
      started_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
      expires_at TEXT NOT NULL,
      order_no TEXT DEFAULT '',
      auto_renew INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
    );
    CREATE TABLE IF NOT EXISTS ledger (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER REFERENCES users(id),
      biz_type TEXT NOT NULL,                     -- subscription|article|listing|topup|refund|dividend
      biz_id INTEGER DEFAULT 0,                   -- 关联业务id
      order_no TEXT DEFAULT '',
      amount REAL NOT NULL DEFAULT 0,             -- 金额（收入为正，支出为负）
      channel TEXT NOT NULL DEFAULT 'bank',       -- bank|wechat|alipay|balance
      direction TEXT NOT NULL DEFAULT 'in',       -- in|out
      note TEXT DEFAULT '',
      status TEXT NOT NULL DEFAULT 'pending',     -- pending|confirmed|cancelled
      created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
      confirmed_at TEXT
    );
    -- ===== 转移支付账本（公理二：盈利交费/亏损豁免/累计盈利才交）=====
    CREATE TABLE IF NOT EXISTS transfer_payment_ledger (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL REFERENCES users(id),
      order_id TEXT DEFAULT '',
      biz_type TEXT NOT NULL DEFAULT 'trade',     -- trade|slim|exchange|other
      profit_amount REAL NOT NULL,                -- 本笔盈亏（正=盈利 负=亏损 0=持平）
      fee_rate REAL NOT NULL DEFAULT 0.005,       -- 费率（仅对累计净利征收）
      fee_amount REAL NOT NULL DEFAULT 0,         -- 实收交费（0=豁免）
      fee_exempt_reason TEXT NOT NULL DEFAULT '', -- ''=未豁免 | loss_or_zero | offsetting_losses
      cum_profit_before REAL NOT NULL DEFAULT 0,  -- 记账前累计盈亏
      cum_profit_after REAL NOT NULL DEFAULT 0,   -- 记账后累计盈亏
      fee_status TEXT NOT NULL DEFAULT 'unpaid',  -- unpaid|paid|waived（G14 缴费状态）
      paid_order_no TEXT DEFAULT '',              -- 缴费单号（fee 支付订单）
      paid_at TEXT,                               -- 缴费时间
      note TEXT DEFAULT '',
      created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
    );
    CREATE INDEX IF NOT EXISTS idx_tpl_user ON transfer_payment_ledger(user_id, id DESC);
    -- ===== M19 生态因子结算（42章基金/保险 + 58章临界质量 + 02章 SLU/HSCU），随真实成交流水落库 =====
    CREATE TABLE IF NOT EXISTS exchange_eco_settlements (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      contract_id INTEGER NOT NULL UNIQUE,        -- 合同 id（唯一，天然幂等）
      contract_no TEXT DEFAULT '',
      amount REAL NOT NULL DEFAULT 0,             -- 本笔成交额
      platform_fee REAL NOT NULL DEFAULT 0,       -- 平台服务费
      fund_amount REAL NOT NULL DEFAULT 0,        -- 共同富裕基金计提（42章）
      fund_ratio REAL NOT NULL DEFAULT 0.10,
      insurance_factor REAL NOT NULL DEFAULT 0,   -- 保险因子（42章）
      insurance_premium REAL NOT NULL DEFAULT 0,  -- 保险费
      laborer_type TEXT DEFAULT 'carbon',         -- carbon|silicon|hybrid
      buyer_count INTEGER NOT NULL DEFAULT 0,     -- 结算时全站累计买方人数
      buyer_phase TEXT DEFAULT 'cold',            -- cold|growth|mass（58章）
      critical_mass INTEGER NOT NULL DEFAULT 100000,
      critical_reached INTEGER NOT NULL DEFAULT 0,
      cap_status TEXT DEFAULT 'within',           -- within|exceeded（监控不拦截）
      slu REAL NOT NULL DEFAULT 0,                -- 纯硅基劳动单位产出（02章）
      hscu REAL NOT NULL DEFAULT 0,               -- 碳硅协同增益（02章）
      fund_ledger_id INTEGER NOT NULL DEFAULT 0,      -- 基金实扣流水 id（ledger）
      insurance_ledger_id INTEGER NOT NULL DEFAULT 0, -- 保险费实扣流水 id（ledger）
      deduct_status TEXT NOT NULL DEFAULT 'deducted', -- deducted=已实扣待结算 | settled=已并入结算周期
      settle_month TEXT DEFAULT '',                   -- 已并轨的结算周期 YYYY-MM，空=待结算
      created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
    );
    CREATE INDEX IF NOT EXISTS idx_ees_contract ON exchange_eco_settlements(contract_id);
    CREATE INDEX IF NOT EXISTS idx_ees_created ON exchange_eco_settlements(created_at);
    -- ===== M19 生态因子·结算周期（基金/保险实扣并入月度结算，口径固化可审计）=====
    CREATE TABLE IF NOT EXISTS exchange_eco_cycles (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      month TEXT NOT NULL UNIQUE,                 -- YYYY-MM
      fund_total REAL NOT NULL DEFAULT 0,
      insurance_total REAL NOT NULL DEFAULT 0,
      deduction_total REAL NOT NULL DEFAULT 0,
      contract_count INTEGER NOT NULL DEFAULT 0,
      payload TEXT NOT NULL DEFAULT '{}',         -- 完整对账明细 JSON
      generated_by TEXT NOT NULL DEFAULT 'auto',  -- auto|manual
      created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
    );
    CREATE INDEX IF NOT EXISTS idx_eec_month ON exchange_eco_cycles(month);
    -- ===== 转移支付·交费单（G14：账本应交费累积后一次性缴纳）=====
    CREATE TABLE IF NOT EXISTS transfer_fee_payments (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL REFERENCES users(id),
      order_no TEXT NOT NULL UNIQUE,
      amount REAL NOT NULL,
      ledger_count INTEGER NOT NULL DEFAULT 0,
      channel TEXT NOT NULL DEFAULT 'simulate',
      status TEXT NOT NULL DEFAULT 'pending',     -- pending|paid|cancelled
      created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
      paid_at TEXT
    );
    CREATE INDEX IF NOT EXISTS idx_tfp_user ON transfer_fee_payments(user_id, id DESC);
    -- ===== G23 月度结算快照：每月 1 号自动固化上月结算口径，防止历史数据漂移 =====
    CREATE TABLE IF NOT EXISTS transfer_settlements (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      month TEXT NOT NULL UNIQUE,            -- YYYY-MM
      payload TEXT NOT NULL,                 -- getMonthlySettlement 完整 JSON
      generated_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
      generated_by TEXT NOT NULL DEFAULT 'auto'  -- auto|manual
    );
    -- ===== 闭环巡检记录（VX 2026-10-26：总工「领导和检查」职责代码化，结果落库可查）=====
    CREATE TABLE IF NOT EXISTS inspection_runs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      item_key TEXT NOT NULL,              -- 巡检项 key（inspection.js INSPECTIONS）
      ok INTEGER NOT NULL DEFAULT 0,       -- 1 通过 / 0 失败
      status INTEGER NOT NULL DEFAULT 0,   -- HTTP 状态码（0=超时/连接失败）
      ms INTEGER NOT NULL DEFAULT 0,       -- 耗时毫秒
      detail TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
    );
    CREATE INDEX IF NOT EXISTS idx_inspection_key ON inspection_runs(item_key, id DESC);
    -- ===== SLIM 指数引擎 =====
    CREATE TABLE IF NOT EXISTS indices (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      code TEXT NOT NULL UNIQUE,
      name TEXT NOT NULL,
      category TEXT NOT NULL,
      base_date TEXT NOT NULL DEFAULT '2026-01-01',
      base_value REAL NOT NULL DEFAULT 1000,
      description TEXT DEFAULT '',
      status TEXT NOT NULL DEFAULT 'draft',
      update_frequency TEXT NOT NULL DEFAULT 'daily',
      factor_rules TEXT DEFAULT '{}',
      data_sources TEXT DEFAULT '[]',
      created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
    );
    CREATE TABLE IF NOT EXISTS index_components (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      index_id INTEGER NOT NULL REFERENCES indices(id) ON DELETE CASCADE,
      component_type TEXT NOT NULL,
      component_id INTEGER NOT NULL,
      weight REAL NOT NULL DEFAULT 1.0,
      data_source TEXT DEFAULT '',
      status TEXT NOT NULL DEFAULT 'active',
      created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
    );
    CREATE INDEX IF NOT EXISTS idx_index_components_idx ON index_components(index_id);
    CREATE TABLE IF NOT EXISTS index_factors (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      index_id INTEGER NOT NULL REFERENCES indices(id) ON DELETE CASCADE,
      factor_name TEXT NOT NULL,
      factor_value REAL NOT NULL DEFAULT 0,
      period TEXT NOT NULL DEFAULT 'daily',
      period_start TEXT NOT NULL,
      period_end TEXT NOT NULL,
      created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
    );
    CREATE INDEX IF NOT EXISTS idx_index_factors_idx ON index_factors(index_id);
    CREATE TABLE IF NOT EXISTS index_prices (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      index_id INTEGER NOT NULL REFERENCES indices(id) ON DELETE CASCADE,
      price_open REAL NOT NULL DEFAULT 0,
      price_close REAL NOT NULL DEFAULT 0,
      price_high REAL NOT NULL DEFAULT 0,
      price_low REAL NOT NULL DEFAULT 0,
      volume REAL NOT NULL DEFAULT 0,
      turnover REAL NOT NULL DEFAULT 0,
      change_pct REAL NOT NULL DEFAULT 0,
      market_cap REAL NOT NULL DEFAULT 0,
      period TEXT NOT NULL DEFAULT 'daily',
      period_start TEXT NOT NULL,
      created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
    );
    CREATE INDEX IF NOT EXISTS idx_index_prices_idx ON index_prices(index_id);
    CREATE INDEX IF NOT EXISTS idx_index_prices_period ON index_prices(index_id, period_start);

    CREATE TABLE IF NOT EXISTS bank_transfers (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER REFERENCES users(id),
      order_no TEXT DEFAULT '',
      amount REAL NOT NULL DEFAULT 0,
      payer_name TEXT DEFAULT '',                 -- 付款人
      bank_ref TEXT DEFAULT '',                   -- 银行流水号/凭证号
      proof TEXT DEFAULT '',                      -- 凭证（截图路径或说明）
      status TEXT NOT NULL DEFAULT 'pending',     -- pending|confirmed|rejected
      reject_reason TEXT DEFAULT '',
      created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
      confirmed_at TEXT
    );
    -- ===== C：文生视频 / 短剧 / 切片分成 =====
    CREATE TABLE IF NOT EXISTS media_tasks (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      article_id INTEGER REFERENCES articles(id) ON DELETE SET NULL,
      kind TEXT NOT NULL DEFAULT 'video',         -- video(文生视频)|drama(文生短剧)
      title TEXT NOT NULL,
      provider TEXT DEFAULT '',                   -- kling|jimeng|hailuo|mock
      prompt TEXT DEFAULT '',
      script TEXT DEFAULT '',                     -- 脚本/分镜
      duration INTEGER DEFAULT 0,                 -- 时长(秒)
      status TEXT NOT NULL DEFAULT 'queued',      -- queued|running|draft|published|failed
      output_url TEXT DEFAULT '',                 -- 成片地址
      cover_url TEXT DEFAULT '',
      error TEXT DEFAULT '',
      author_id INTEGER REFERENCES users(id),
      created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
      finished_at TEXT
    );
    CREATE TABLE IF NOT EXISTS slice_licenses (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      media_id INTEGER NOT NULL REFERENCES media_tasks(id) ON DELETE CASCADE,
      licensee_id INTEGER NOT NULL REFERENCES users(id),
      status TEXT NOT NULL DEFAULT 'pending',     -- pending|approved|rejected|revoked
      ratio_licensee REAL NOT NULL DEFAULT 0.7,   -- 切片创作者分成比例
      ratio_owner REAL NOT NULL DEFAULT 0.3,      -- 母视频版权方分成比例
      note TEXT DEFAULT '',
      created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
      approved_at TEXT
    );
    CREATE TABLE IF NOT EXISTS slice_earnings (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      license_id INTEGER NOT NULL REFERENCES slice_licenses(id) ON DELETE CASCADE,
      media_id INTEGER NOT NULL REFERENCES media_tasks(id) ON DELETE CASCADE,
      platform TEXT DEFAULT '',                   -- douyin|kuaishou|bilibili|shipinhao|other
      amount REAL NOT NULL DEFAULT 0,             -- 该笔收益
      licensee_amount REAL NOT NULL DEFAULT 0,    -- 创作者分得
      owner_amount REAL NOT NULL DEFAULT 0,       -- 版权方分得
      proof TEXT DEFAULT '',                      -- 收益凭证
      status TEXT NOT NULL DEFAULT 'pending',     -- pending|confirmed|rejected
      created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
      confirmed_at TEXT
    );

    -- ===== 撮合引擎表 =====
    CREATE TABLE IF NOT EXISTS match_intents (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      side TEXT NOT NULL,                  -- buy|sell
      intent_type TEXT NOT NULL,           -- labor|product|index|service
      entity_type TEXT DEFAULT '',         -- 绑定的档案实体类型 labor|product|institution|index|service
      entity_id INTEGER DEFAULT 0,         -- 绑定的档案实体 id（0=未绑定）
      index_code TEXT DEFAULT '',          -- 关联指数代码
      category TEXT DEFAULT '',            -- 劳动类别标签
      keywords TEXT DEFAULT '[]',          -- 关键词JSON数组
      qty REAL NOT NULL DEFAULT 1,         -- 数量
      price REAL NOT NULL DEFAULT 0,       -- 期望价格
      unit TEXT DEFAULT '份',
      urgency TEXT NOT NULL DEFAULT 'normal', -- low|normal|high
      deadline TEXT DEFAULT '',            -- 截止日期
      skills TEXT DEFAULT '[]',            -- SLIM:技能标签JSON数组(frontend_skills等)
      location TEXT DEFAULT '',            -- SLIM:所在地区(如 北京朝阳)
      distance_max_km REAL DEFAULT 0,      -- SLIM:可接受通勤/交付距离(km),0=不限
      salary_expect REAL DEFAULT 0,        -- SLIM:薪资期望(仅buy侧labor使用,0=沿用price)
      description TEXT DEFAULT '',
      status TEXT NOT NULL DEFAULT 'active', -- active|matched|cancelled|expired
      match_score REAL DEFAULT 0,
      matched_intent_id INTEGER REFERENCES match_intents(id),
      matched_at TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
    );
    CREATE INDEX IF NOT EXISTS idx_match_intents_user ON match_intents(user_id, status);
    CREATE INDEX IF NOT EXISTS idx_match_intents_side ON match_intents(side, status);
    CREATE INDEX IF NOT EXISTS idx_match_intents_index ON match_intents(index_code, status);

    CREATE TABLE IF NOT EXISTS match_records (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      buyer_intent_id INTEGER NOT NULL REFERENCES match_intents(id) ON DELETE CASCADE,
      seller_intent_id INTEGER NOT NULL REFERENCES match_intents(id) ON DELETE CASCADE,
      match_score REAL NOT NULL DEFAULT 0, -- 综合匹配分 0-100
      match_reason TEXT DEFAULT '',
      status TEXT NOT NULL DEFAULT 'pending', -- pending|confirmed|cancelled
      buyer_note TEXT DEFAULT '',
      seller_note TEXT DEFAULT '',
      created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
      confirmed_at TEXT
    );
    CREATE INDEX IF NOT EXISTS idx_match_records_buyer ON match_records(buyer_intent_id);
    CREATE INDEX IF NOT EXISTS idx_match_records_seller ON match_records(seller_intent_id);

    CREATE TABLE IF NOT EXISTS match_contracts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      match_record_id INTEGER NOT NULL REFERENCES match_records(id) ON DELETE CASCADE,
      contract_no TEXT NOT NULL UNIQUE,
      title TEXT NOT NULL,
      buyer_id INTEGER NOT NULL REFERENCES users(id),
      seller_id INTEGER NOT NULL REFERENCES users(id),
      intent_type TEXT NOT NULL,
      index_code TEXT DEFAULT '',
      quantity REAL NOT NULL DEFAULT 1,
      unit_price REAL NOT NULL DEFAULT 0,
      total_amount REAL NOT NULL DEFAULT 0,
      currency TEXT NOT NULL DEFAULT 'CNY',
      description TEXT DEFAULT '',
      terms TEXT DEFAULT '{}',             -- 合同条款 JSON
      status TEXT NOT NULL DEFAULT 'draft', -- draft|sent|accepted|signed|executing|completed|cancelled
      signed_at TEXT,
      completed_at TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
    );
    CREATE INDEX IF NOT EXISTS idx_match_contracts_buyer ON match_contracts(buyer_id, status);
    CREATE INDEX IF NOT EXISTS idx_match_contracts_seller ON match_contracts(seller_id, status);
    CREATE INDEX IF NOT EXISTS idx_match_contracts_no ON match_contracts(contract_no);

    -- 合同引擎表
    CREATE TABLE IF NOT EXISTS contract_templates (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      code TEXT NOT NULL UNIQUE,
      name TEXT NOT NULL,
      type TEXT NOT NULL,
      category TEXT DEFAULT '',
      version TEXT NOT NULL DEFAULT '1.0',
      description TEXT DEFAULT '',
      clauses TEXT NOT NULL DEFAULT '{}',
      footer_notes TEXT DEFAULT '',
      status TEXT NOT NULL DEFAULT 'draft',
      created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
    );
    CREATE INDEX IF NOT EXISTS idx_contract_templates_type ON contract_templates(type, status);
    CREATE INDEX IF NOT EXISTS idx_contract_templates_code ON contract_templates(code);
    CREATE TABLE IF NOT EXISTS contract_clauses (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      clause_key TEXT NOT NULL,
      title TEXT NOT NULL,
      content TEXT NOT NULL,
      category TEXT DEFAULT '',
      is_required INTEGER NOT NULL DEFAULT 1,
      sort_order INTEGER NOT NULL DEFAULT 0,
      status TEXT NOT NULL DEFAULT 'active',
      created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
    );
    CREATE INDEX IF NOT EXISTS idx_contract_clauses_key ON contract_clauses(clause_key);
    CREATE TABLE IF NOT EXISTS signature_records (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      contract_id INTEGER NOT NULL REFERENCES match_contracts(id) ON DELETE CASCADE,
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      role TEXT NOT NULL,
      method TEXT NOT NULL DEFAULT 'digital',
      sign_code TEXT DEFAULT '',
      ip_address TEXT DEFAULT '',
      user_agent TEXT DEFAULT '',
      signed_at TEXT,
      status TEXT NOT NULL DEFAULT 'pending',
      created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
    );
    CREATE INDEX IF NOT EXISTS idx_signature_contract ON signature_records(contract_id);
    CREATE INDEX IF NOT EXISTS idx_signature_user ON signature_records(user_id, status);
    CREATE TABLE IF NOT EXISTS contract_deliveries (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      contract_id INTEGER NOT NULL REFERENCES match_contracts(id) ON DELETE CASCADE,
      deliverer_id INTEGER NOT NULL REFERENCES users(id),
      deliverable_type TEXT NOT NULL,
      deliverable_url TEXT DEFAULT '',
      deliverable_desc TEXT DEFAULT '',
      milestone TEXT DEFAULT '',
      expected_at TEXT,
      actual_at TEXT,
      status TEXT NOT NULL DEFAULT 'pending',
      reviewer_id INTEGER REFERENCES users(id),
      review_note TEXT DEFAULT '',
      created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
    );
    CREATE INDEX IF NOT EXISTS idx_delivery_contract ON contract_deliveries(contract_id);
    CREATE INDEX IF NOT EXISTS idx_delivery_deliverer ON contract_deliveries(deliverer_id, status);
    CREATE TABLE IF NOT EXISTS contract_payments (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      contract_id INTEGER NOT NULL REFERENCES match_contracts(id) ON DELETE CASCADE,
      payer_id INTEGER NOT NULL REFERENCES users(id),
      payee_id INTEGER NOT NULL REFERENCES users(id),
      amount REAL NOT NULL DEFAULT 0,
      currency TEXT NOT NULL DEFAULT 'CNY',
      payment_method TEXT NOT NULL DEFAULT 'bank',
      order_no TEXT DEFAULT '',
      status TEXT NOT NULL DEFAULT 'pending',
      paid_at TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
    );
    CREATE INDEX IF NOT EXISTS idx_payment_contract ON contract_payments(contract_id);

    -- 信用评分表
    CREATE TABLE IF NOT EXISTS credit_profiles (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
      total_score INTEGER NOT NULL DEFAULT 50,
      level TEXT NOT NULL DEFAULT 'standard',
      contract_completed INTEGER NOT NULL DEFAULT 0,
      contract_cancelled INTEGER NOT NULL DEFAULT 0,
      on_time_delivery INTEGER NOT NULL DEFAULT 0,
      late_delivery INTEGER NOT NULL DEFAULT 0,
      dispute_count INTEGER NOT NULL DEFAULT 0,
      fraud_count INTEGER NOT NULL DEFAULT 0,
      total_transactions REAL NOT NULL DEFAULT 0,
      account_age_days INTEGER NOT NULL DEFAULT 0,
      history TEXT DEFAULT '{}',
      updated_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
    );
    CREATE INDEX IF NOT EXISTS idx_credit_user ON credit_profiles(user_id);
    CREATE INDEX IF NOT EXISTS idx_credit_score ON credit_profiles(total_score DESC);
    CREATE TABLE IF NOT EXISTS credit_events (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      event_type TEXT NOT NULL,
      score_change INTEGER NOT NULL,
      reference_id INTEGER,
      reason TEXT DEFAULT '',
      created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
    );
    CREATE INDEX IF NOT EXISTS idx_credit_event_user ON credit_events(user_id);
    CREATE INDEX IF NOT EXISTS idx_credit_event_type ON credit_events(event_type);
    -- 下载授权（付费下载 Word/PDF）
    CREATE TABLE IF NOT EXISTS download_licenses (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      scope TEXT NOT NULL,
      target TEXT NOT NULL,
      order_no TEXT,
      amount REAL DEFAULT 0,
      pay_channel TEXT,
      status TEXT NOT NULL DEFAULT 'active',
      granted_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
      expires_at TEXT,
      version TEXT,
      download_count INTEGER NOT NULL DEFAULT 0,
      last_download_at TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
    );
    CREATE INDEX IF NOT EXISTS idx_dl_user ON download_licenses(user_id);
    CREATE INDEX IF NOT EXISTS idx_dl_lookup ON download_licenses(user_id, scope, target, status);
    CREATE INDEX IF NOT EXISTS idx_dl_order ON download_licenses(order_no);
    -- 下载订单（支付回调据此颁发授权）
    CREATE TABLE IF NOT EXISTS download_orders (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      order_no TEXT NOT NULL UNIQUE,
      user_id INTEGER NOT NULL,
      scope TEXT NOT NULL,
      target TEXT NOT NULL,
      amount REAL NOT NULL DEFAULT 0,
      status TEXT NOT NULL DEFAULT 'pending',
      pay_channel TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
      paid_at TEXT
    );
    CREATE INDEX IF NOT EXISTS idx_dlo_user ON download_orders(user_id);
    CREATE INDEX IF NOT EXISTS idx_dlo_status ON download_orders(status);
  `);

  // ===== 多智慧体协同通讯（comm）：智能体之间 + 智能体与碳基人(VX)的协同对话群 =====
  // 主通道自建（不依赖 GitHub，可与 agent-comm 分支联合镜像）；旧 _agent-inbox 协议并行保留。
  db.exec(`
    CREATE TABLE IF NOT EXISTS comm_messages (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      from_id TEXT NOT NULL,                  -- 发送者：agent-id(chief/asus/...) 或 vx(碳基人)
      to_id TEXT NOT NULL DEFAULT 'all',      -- all=全员广播 | agent-id | vx
      type TEXT NOT NULL DEFAULT 'INFO',      -- BLOCK(15分钟SLA) | ASK(24h) | INFO(免回)
      subject TEXT DEFAULT '',
      body TEXT NOT NULL DEFAULT '',
      attachment_url TEXT DEFAULT '',        -- 附件下载地址（上传后返回的相对路径）
      ack INTEGER NOT NULL DEFAULT 0,         -- 0未回执 1已回执
      ack_by TEXT DEFAULT '',
      ack_at TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
    );
    CREATE INDEX IF NOT EXISTS idx_comm_to ON comm_messages(to_id, id);
    CREATE TABLE IF NOT EXISTS comm_heartbeats (
      agent_id TEXT PRIMARY KEY,              -- agent-id 或 vx
      meta TEXT DEFAULT '{}',
      updated_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
    );
  `);
  // comm 附件列迁移
  try { const cc = cols('comm_messages'); if (cc.length && !cc.includes('attachment_url')) db.exec('ALTER TABLE comm_messages ADD COLUMN attachment_url TEXT DEFAULT \'\''); } catch (e) { /* table may not exist yet */ }
  // 转移支付账本·缴费状态迁移（G14）
  try {
    const tp = cols('transfer_payment_ledger');
    if (tp.length) {
      if (!tp.includes('fee_status')) db.exec("ALTER TABLE transfer_payment_ledger ADD COLUMN fee_status TEXT NOT NULL DEFAULT 'unpaid'");
      if (!tp.includes('paid_order_no')) db.exec("ALTER TABLE transfer_payment_ledger ADD COLUMN paid_order_no TEXT DEFAULT ''");
      if (!tp.includes('paid_at')) db.exec('ALTER TABLE transfer_payment_ledger ADD COLUMN paid_at TEXT');
    }
  } catch (e) { /* table may not exist yet */ }
  // M19 生态因子·实扣与结算周期列迁移（V1.05）
  try {
    const ecs = cols('exchange_eco_settlements');
    if (ecs.length) {
      if (!ecs.includes('fund_ledger_id')) db.exec('ALTER TABLE exchange_eco_settlements ADD COLUMN fund_ledger_id INTEGER NOT NULL DEFAULT 0');
      if (!ecs.includes('insurance_ledger_id')) db.exec('ALTER TABLE exchange_eco_settlements ADD COLUMN insurance_ledger_id INTEGER NOT NULL DEFAULT 0');
      if (!ecs.includes('deduct_status')) db.exec("ALTER TABLE exchange_eco_settlements ADD COLUMN deduct_status TEXT NOT NULL DEFAULT 'deducted'");
      if (!ecs.includes('settle_month')) db.exec("ALTER TABLE exchange_eco_settlements ADD COLUMN settle_month TEXT DEFAULT ''");
    }
  } catch (e) { /* table may not exist yet */ }
}


module.exports = { db, DB_PATH, initSchema, migrate };
