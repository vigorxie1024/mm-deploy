#!/bin/bash
# auto-update.sh v3 —— 120 秒级拉取式自更新
# 教训（2026-11-05 实测）：jsDelivr 对 @main 分支有最长 12 小时缓存，且 ?ts 查询串不进缓存键。
#   v2 先取 jsDelivr → 拿到过期版本号 → 可能把生产「降级」成旧代码，还会因为 version.txt 被写成旧值而永久卡死。
# v3 修正：
#   1) 版本号与 manifest 一律先取 api.github.com（新鲜、匿名 60 次/小时，120 秒一轮够用），jsDelivr 仅作兜底；
#   2) 版本一致性校验：manifest.version 必须等于探测到的版本号，否则本轮跳过（防止版本号与载荷错配）；
#   3) 防降级：新版本号在字典序上必须大于当前版本号，否则拒绝执行（版本号是 ISO 时间戳，字典序即时间序）。
set -u
T=/www/wwwroot/moonarmor
DEP=$T/.deploy
LOG=$DEP/auto-update.log
VERF=$DEP/version.txt
API=https://api.github.com/repos/vigorxie1024/mm-deploy/contents/prod-manifest
JSD=https://cdn.jsdelivr.net/gh/vigorxie1024/mm-deploy@main/prod-manifest
say(){ echo "[$(date '+%F %T')] $*" >> "$LOG"; }

mkdir -p "$DEP"

# ① 版本号：api 优先，jsDelivr 兜底
RV=$(curl -fsSL --max-time 10 -H "Accept: application/vnd.github.raw" "$API/ver.txt?ref=main" 2>/dev/null | tr -d '\r\n ')
[ -z "$RV" ] && RV=$(curl -fsSL --max-time 8 "$JSD/ver.txt?$(date +%s)" 2>/dev/null | tr -d '\r\n ')
[ -z "$RV" ] && { say "取 ver.txt 失败（本轮跳过）"; exit 0; }
LV=$(cat "$VERF" 2>/dev/null || echo none)
[ "$RV" = "$LV" ] && exit 0

# ② 防降级
if [ "$LV" != "none" ]; then
  if [[ ! "$RV" > "$LV" ]]; then
    say "拒绝降级：当前 $LV，远端 $RV（远端更旧，可能是镜像缓存，本轮跳过）"
    exit 0
  fi
fi
say "发现新版本：$LV → $RV"

# ③ manifest：api 优先，jsDelivr 兜底
MJ=$(curl -fsSL --max-time 20 -H "Accept: application/vnd.github.raw" "$API/version.json?ref=main" 2>/dev/null)
[ -z "$MJ" ] && MJ=$(curl -fsSL --max-time 15 "$JSD/version.json?$(date +%s)" 2>/dev/null)
[ -z "$MJ" ] && { say "取 version.json 失败，本轮跳过"; exit 0; }

# ④ manifest 与版本号必须一致
MV=$(printf '%s' "$MJ" | python3 -c 'import sys,json;print(json.load(sys.stdin).get("version",""))' 2>/dev/null)
if [ -z "$MV" ] || [ "$MV" != "$RV" ]; then
  say "版本错配：ver.txt=$RV，manifest=$MV（本轮跳过）"
  exit 0
fi

B=$DEP/bak-$(date +%s); mkdir -p "$B"
printf '%s' "$MJ" | python3 -c '
import sys,json
j=json.load(sys.stdin)
for f in j.get("files",[]):
    print(f["file"]+"|"+f["obj"]+"|"+f["sha"])
' > /tmp/au.list 2>/dev/null || { say "解析 manifest 失败"; exit 0; }

fail=0
while IFS='|' read -r local obj sha; do
  [ -z "$local" ] && continue
  ok=0
  curl -fsSL --max-time 60 -H "Accept: application/vnd.github.raw" "$API/$obj?ref=main" -o /tmp/au.gz 2>/dev/null && ok=1
  [ "$ok" = "0" ] && curl -fsSL --max-time 30 "$JSD/$obj?$(date +%s)" -o /tmp/au.gz 2>/dev/null && ok=1
  [ "$ok" = "0" ] && { say "取件失败 $local"; fail=1; break; }

  case "$local" in *.js) TMP=/tmp/au-check.js ;; *.html) TMP=/tmp/au-check.html ;; *.sh) TMP=/tmp/au-check.sh ;; *) TMP=/tmp/au-check.bin ;; esac
  gunzip -cf /tmp/au.gz > "$TMP" 2>/dev/null || { say "解压失败 $local"; fail=1; break; }
  got=$(sha256sum "$TMP" | cut -d' ' -f1)
  [ "$got" != "$sha" ] && { say "sha 不符 $local（期望 $sha 实际 $got）"; fail=1; break; }
  case "$local" in *.js) node --check "$TMP" 2>/dev/null || { say "语法失败 $local"; fail=1; break; } ;; esac
  [ -f "$T/$local" ] && cp -a "$T/$local" "$B/$(echo $local | tr '/' '_')"
  mkdir -p "$(dirname "$T/$local")"
  install -m 644 "$TMP" "$T/$local" || { say "写入失败 $local"; fail=1; break; }
  [ "$local" = ".deploy/auto-update.sh" ] && chmod +x "$T/$local"
  say "已更新 $local"
done < /tmp/au.list

rollback(){
  say "开始回滚"
  for f in "$B"/*; do [ -f "$f" ] || continue
    rel=$(basename "$f" | tr '_' '/'); cp -a "$f" "$T/$rel" 2>/dev/null; done
  systemctl restart moonarmor 2>/dev/null; sleep 2
  say "回滚完成："$(systemctl is-active moonarmor 2>/dev/null)
}
[ "$fail" != "0" ] && { rollback; exit 2; }

systemctl restart moonarmor || { rollback; exit 3; }
sleep 3
ST=$(systemctl is-active moonarmor 2>/dev/null)
[ "$ST" != "active" ] && { say "服务未起来 $ST"; rollback; exit 4; }

# ⑤ 冒烟：必须能拿到登录页与 401 鉴权
H=$(curl -fsS --max-time 10 -o /dev/null -w '%{http_code}' https://moonarmor.cn/ 2>/dev/null)
C=$(curl -fsS --max-time 10 -o /dev/null -w '%{http_code}' https://moonarmor.cn/api/cell/state 2>/dev/null)
if [ "$H" != "200" ]; then say "冒烟失败：首页 HTTP $H"; rollback; exit 5; fi
[ "$C" = "401" ] || say "警告：/api/cell/state 期望 401，实际 $C（不致命）"

echo "$RV" > "$VERF"
say "更新成功：版本 $RV，服务 active，首页 $H，鉴权 $C"
