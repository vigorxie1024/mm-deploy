'use strict';
/**
 * CSchat · 碳硅基协同聊天核心模块（喊话台增量底座）
 *
 * 设计原则（对应 PRD v0.2a）：
 * 1. 碳基 C 与硅基 S1-S5 一等公民，人格完全平等
 * 2. 集合论全域覆盖：主体 × 端 → 群会话满射
 * 3. 统一意图信封（CAP 协议栈 L0-L3）
 * 4. 喊话台（asus 8790）为既有投递通道之一
 * 5. 防自主体空转：硅基回复需带 envelope，禁止无意图刷屏
 *
 * 纯函数 + db 直写，不依赖外部服务。路由层在 server.js。
 */

const VALID_KIND = new Set(['C', 'S1', 'S2', 'S3', 'S4', 'S5']);
const VALID_ROOM = new Set(['group', 'dm', 'spirit']);
const VALID_MSG = new Set(['text', 'image', 'file', 'intent', 'spirit']);

function cleanId(s) {
  return String(s || '').trim().slice(0, 64).replace(/[^A-Za-z0-9_\-.]/g, '');
}

// ===== 主体 =====
function registerSubject(db, { id, kind, name, avatar, profile }) {
  id = cleanId(id);
  kind = String(kind || '').toUpperCase();
  if (!id) throw new Error('主体ID不能为空');
  if (!VALID_KIND.has(kind)) throw new Error('主体类型须为 C/S1/S2/S3/S4/S5');
  name = String(name || '').trim().slice(0, 60) || id;
  avatar = String(avatar || '').slice(0, 300);
  profile = profile ? JSON.stringify(profile).slice(0, 8000) : '';
  db.prepare(
    "INSERT INTO cschat_subjects (id, kind, name, avatar, profile) VALUES (?, ?, ?, ?, ?) " +
    "ON CONFLICT(id) DO UPDATE SET kind=excluded.kind, name=excluded.name, avatar=excluded.avatar, profile=excluded.profile"
  ).run(id, kind, name, avatar, profile);
  return { id, kind, name, avatar };
}

function getSubject(db, id) {
  return db.prepare('SELECT * FROM cschat_subjects WHERE id = ?').get(cleanId(id)) || null;
}

function listSubjects(db) {
  return db.prepare('SELECT id, kind, name, avatar FROM cschat_subjects ORDER BY kind, name').all();
}

// ===== 群聊房间 =====
function createRoom(db, { name, kind, owner_id, members, meta }) {
  owner_id = cleanId(owner_id);
  if (!owner_id) throw new Error('创建者不能为空');
  if (!db.prepare('SELECT 1 FROM cschat_subjects WHERE id = ?').get(owner_id))
    throw new Error('创建者主体未登记：' + owner_id);
  kind = VALID_ROOM.has(kind) ? kind : 'group';
  name = String(name || '').trim().slice(0, 80) || (kind === 'dm' ? '单聊' : '群聊');
  meta = meta ? JSON.stringify(meta).slice(0, 4000) : '';
  const r = db.prepare(
    'INSERT INTO cschat_rooms (name, kind, owner_id, meta) VALUES (?, ?, ?, ?)'
  ).run(name, kind, owner_id, meta);
  const room_id = Number(r.lastInsertRowid);
  // owner 入群
  db.prepare('INSERT OR IGNORE INTO cschat_members (room_id, subject_id, role) VALUES (?, ?, ?)')
    .run(room_id, owner_id, 'owner');
  // 邀请成员
  const mems = Array.isArray(members) ? members.map(cleanId).filter(Boolean) : [];
  for (const m of mems) {
    if (m === owner_id) continue;
    db.prepare('INSERT OR IGNORE INTO cschat_members (room_id, subject_id, role) VALUES (?, ?, \'member\')')
      .run(room_id, m);
  }
  return { id: room_id, name, kind, owner_id };
}

function listRooms(db, subject_id) {
  subject_id = cleanId(subject_id);
  return db.prepare(
    "SELECT r.id, r.name, r.kind, r.owner_id, r.meta, " +
    "(SELECT COUNT(*) FROM cschat_members WHERE room_id = r.id) AS member_count, " +
    "(SELECT body FROM cschat_messages WHERE room_id = r.id ORDER BY id DESC LIMIT 1) AS last_body, " +
    "(SELECT created_at FROM cschat_messages WHERE room_id = r.id ORDER BY id DESC LIMIT 1) AS last_at " +
    "FROM cschat_rooms r JOIN cschat_members m ON m.room_id = r.id " +
    "WHERE m.subject_id = ? ORDER BY COALESCE(last_at, r.created_at) DESC"
  ).all(subject_id);
}

function getRoom(db, room_id) {
  return db.prepare('SELECT * FROM cschat_rooms WHERE id = ?').get(Number(room_id)) || null;
}

function listMembers(db, room_id) {
  return db.prepare(
    "SELECT s.id, s.kind, s.name, s.avatar, m.role, m.joined_at " +
    "FROM cschat_members m JOIN cschat_subjects s ON s.id = m.subject_id " +
    "WHERE m.room_id = ? ORDER BY m.role='owner' DESC, m.joined_at"
  ).all(Number(room_id));
}

function joinRoom(db, room_id, subject_id, role) {
  room_id = Number(room_id);
  subject_id = cleanId(subject_id);
  role = role === 'admin' ? 'admin' : 'member';
  if (!getRoom(db, room_id)) throw new Error('房间不存在');
  if (!getSubject(db, subject_id)) throw new Error('主体未登记：' + subject_id);
  db.prepare('INSERT OR IGNORE INTO cschat_members (room_id, subject_id, role) VALUES (?, ?, ?)')
    .run(room_id, subject_id, role);
  return { room_id, subject_id, role };
}

// ===== 消息（统一意图信封）=====
function buildEnvelope({ protocol, intent, payload, ttl }) {
  return JSON.stringify({
    ver: '1.0',
    protocol: protocol || 'CAP-L1',
    intent: intent || 'chat.text',
    payload: payload || {},
    ttl: Number(ttl) || 300,
    trace_id: 'tr_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 8),
    ts: new Date().toISOString()
  });
}

function sendMessage(db, { room_id, from_id, kind, body, envelope, reply_to }) {
  room_id = Number(room_id);
  from_id = cleanId(from_id);
  kind = VALID_MSG.has(kind) ? kind : 'text';
  body = String(body || '').slice(0, 8000);
  reply_to = Number(reply_to) || 0;
  if (!body.trim() && kind === 'text') throw new Error('消息不能为空');
  // 成员校验
  const isMem = db.prepare('SELECT 1 FROM cschat_members WHERE room_id = ? AND subject_id = ?').get(room_id, from_id);
  if (!isMem) throw new Error('不在该群，无法发言：' + from_id);
  // 统一意图信封：硅基主体发言强制带 envelope（防空转刷屏）
  const subj = getSubject(db, from_id);
  if (subj && subj.kind !== 'C' && !envelope) {
    envelope = buildEnvelope({ protocol: 'CAP-L1', intent: 'chat.' + kind });
  }
  envelope = envelope ? String(envelope).slice(0, 8000) : '';
  const r = db.prepare(
    'INSERT INTO cschat_messages (room_id, from_id, kind, body, envelope, reply_to) VALUES (?, ?, ?, ?, ?, ?)'
  ).run(room_id, from_id, kind, body, envelope, reply_to);
  const msg = db.prepare('SELECT * FROM cschat_messages WHERE id = ?').get(Number(r.lastInsertRowid));
  // 附带发送者信息
  msg.from_kind = subj ? subj.kind : 'C';
  msg.from_name = subj ? subj.name : from_id;
  return msg;
}

function listMessages(db, room_id, since, limit) {
  room_id = Number(room_id);
  since = Math.max(0, Number(since) || 0);
  limit = Math.max(1, Math.min(200, Number(limit) || 100));
  return db.prepare(
    "SELECT m.*, s.kind AS from_kind, s.name AS from_name " +
    "FROM cschat_messages m LEFT JOIN cschat_subjects s ON s.id = m.from_id " +
    "WHERE m.room_id = ? AND m.id > ? ORDER BY m.id ASC LIMIT ?"
  ).all(room_id, since, limit);
}

function ackMessage(db, msg_id, subject_id) {
  msg_id = Number(msg_id);
  subject_id = cleanId(subject_id);
  const m = db.prepare('SELECT * FROM cschat_messages WHERE id = ?').get(msg_id);
  if (!m) throw new Error('消息不存在');
  db.prepare('UPDATE cschat_messages SET ack = ack + 1 WHERE id = ?').run(msg_id);
  return { id: msg_id, ack: m.ack + 1, ack_by: subject_id };
}

// ===== 精神帖 SpiritCard（PRD 第 6 章 · 精神原汁原味穿透层级）=====
// 精神帖是一种特殊消息 kind='spirit'，承载碳基/硅基讨论的核心精神，
// 可被群成员「认领」（ack=已领悟）、可「转发」到其他群形成传播链。
// envelope.protocol = 'CAP-SPIRIT'，payload 含 title/tags/origin_msg_id/chain。

function postSpirit(db, { room_id, from_id, title, body, tags }) {
  title = String(title || '').trim().slice(0, 80);
  body = String(body || '').trim().slice(0, 4000);
  if (!title && !body) throw new Error('精神帖标题或正文不能为空');
  tags = Array.isArray(tags) ? tags.slice(0, 8).map(t => String(t).slice(0, 20)) : [];
  const envelope = JSON.stringify({
    ver: '1.0', protocol: 'CAP-SPIRIT', intent: 'spirit.post',
    payload: { title, tags, origin_msg_id: null, chain: [] },
    ts: new Date().toISOString()
  });
  return sendMessage(db, { room_id, from_id, kind: 'spirit', body: body || title, envelope });
}

function graspSpirit(db, msg_id, subject_id) {
  // 认领精神帖 = 已领悟（ack 计数）
  const r = ackMessage(db, msg_id, subject_id);
  return { id: msg_id, grasped: true, grasp_count: r.ack };
}

function forwardSpirit(db, msg_id, from_id, to_room_id) {
  const src = db.prepare('SELECT * FROM cschat_messages WHERE id = ? AND kind = ?').get(Number(msg_id), 'spirit');
  if (!src) throw new Error('源精神帖不存在');
  to_room_id = Number(to_room_id);
  if (!getRoom(db, to_room_id)) throw new Error('目标群不存在');
  // 转发者自动加入目标群（精神传播不受成员限制）
  db.prepare('INSERT OR IGNORE INTO cschat_members (room_id, subject_id, role) VALUES (?, ?, \'member\')')
    .run(to_room_id, from_id);
  let env = {};
  try { env = JSON.parse(src.envelope || '{}'); } catch (e) { env = {}; }
  const p = env.payload || {};
  const chain = Array.isArray(p.chain) ? p.chain.slice() : [];
  chain.push({ from_room: src.room_id, by: from_id, at: new Date().toISOString() });
  const envelope = JSON.stringify({
    ver: '1.0', protocol: 'CAP-SPIRIT', intent: 'spirit.forward',
    payload: { title: p.title || '', tags: p.tags || [], origin_msg_id: p.origin_msg_id || src.id, chain },
    ts: new Date().toISOString()
  });
  return sendMessage(db, { room_id: to_room_id, from_id, kind: 'spirit', body: src.body, envelope, reply_to: src.id });
}

function listSpirits(db, room_id) {
  return db.prepare(
    "SELECT m.*, s.kind AS from_kind, s.name AS from_name " +
    "FROM cschat_messages m LEFT JOIN cschat_subjects s ON s.id = m.from_id " +
    "WHERE m.room_id = ? AND m.kind = 'spirit' ORDER BY m.id DESC LIMIT 100"
  ).all(Number(room_id));
}

// ===== 喊话台桥接（asus 8790 · CAP-L3 载体桥）=====
// 喊话台为既有投递通道：CSchat 消息同步推送到局域网喊话台，
// 让 PC/手机/IoT/眼镜/车机等端都能收到。喊话台离线时静默跳过，不阻塞主流程。
const SHOUTTAI_URL = process.env.CSCHAT_SHOUTTAI_URL || 'http://192.168.0.103:8790';
const SHOUTTAI_KEY = process.env.CSCHAT_SHOUTTAI_KEY || '';

async function bridgeToShouttai(msg) {
  if (!SHOUTTAI_KEY) return { skipped: 'no_key' };
  try {
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), 3000);
    const r = await fetch(SHOUTTAI_URL + '/api/shout', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-lan-key': SHOUTTAI_KEY },
      body: JSON.stringify({
        from: msg.from_name || msg.from_id,
        kind: msg.from_kind || 'C',
        room: msg.room_id,
        text: String(msg.body || '').slice(0, 500),
        ts: msg.created_at
      }),
      signal: ctrl.signal
    });
    clearTimeout(t);
    return { ok: r.ok, status: r.status };
  } catch (e) {
    return { skipped: String(e.message || e).slice(0, 80) };
  }
}

module.exports = {
  registerSubject, getSubject, listSubjects,
  createRoom, listRooms, getRoom, listMembers, joinRoom,
  sendMessage, listMessages, ackMessage,
  postSpirit, graspSpirit, forwardSpirit, listSpirits,
  buildEnvelope, bridgeToShouttai,
  VALID_KIND, VALID_ROOM, VALID_MSG
};
